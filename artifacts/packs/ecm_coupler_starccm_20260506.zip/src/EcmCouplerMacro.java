import star.common.*;
import star.base.neo.*;
import star.base.report.*;

import java.io.*;
import java.nio.*;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * EcmCouplerMacro — per-timestep ECM coupling for STAR-CCM+ 21.02.
 *
 * USAGE
 * -----
 * 1. Open your .sim file in STAR-CCM+.
 * 2. In the tree, manually create a ScalarGlobalParameter named "ecmQdot_W_m3"
 *    and set the jellyRoll region's energy source to reference it (see README).
 * 3. Tools > Macros > Run Macro > select EcmCouplerMacro.java (or the compiled jar).
 * 4. The macro drives the solver loop; DO NOT press the Run button separately.
 *
 * The macro writes ecm_in.bin, calls the external ECM (Python), reads ecm_out.bin,
 * applies under-relaxation, and updates ecmQdot_W_m3 before the next solver step.
 *
 * CONFIGURATION
 * -------------
 * Edit the constants in the CONFIG block below before running.
 *
 * BINARY PROTOCOL
 * ---------------
 * Matches docs/IO_FORMAT.md in the OpenFOAM ECM repository (v2 header, lumped mode).
 * The same Python ECM backend (ecm/ecm_coupler.py) works unchanged.
 */
public class EcmCouplerMacro extends StarMacro {

    // =========================================================================
    // CONFIG — edit these before running
    // =========================================================================

    /** Name of the coupled battery region in the STAR-CCM+ tree. */
    private static final String REGION_NAME    = "jellyRoll";

    /** Name of the ScalarGlobalParameter that drives the energy source. */
    private static final String QPARAM_NAME    = "ecmQdot_W_m3";

    /** Path to ecm_in.bin written by this macro (relative to working dir). */
    private static final String ECM_IN_FILE    = "ecm/ecm_in.bin";

    /** Path to ecm_out.bin written by the Python ECM (relative to working dir). */
    private static final String ECM_OUT_FILE   = "ecm/ecm_out.bin";

    /** Shell command to invoke the ECM.  Must block until ecm_out.bin is ready. */
    private static final String ECM_COMMAND    = "python ecm/ecm_coupler.py";

    /** Under-relaxation factor (0 < alpha <= 1).  Start conservative (0.5-0.8). */
    private static final double ALPHA          = 0.7;

    /** Number of timesteps to run.  Set to match your simulation end time / deltaT. */
    private static final int    N_STEPS        = 100;

    /** Max wall-clock seconds to wait for ecm_out.bin to appear. */
    private static final int    ECM_TIMEOUT_S  = 60;

    // =========================================================================
    // MAIN ENTRY POINT
    // =========================================================================

    @Override
    public void execute() {
        Simulation sim = getActiveSimulation();

        // --- startup diagnostics ---
        String cwd = new File(".").getAbsolutePath();
        sim.println("[ECM] ==== ECM COUPLER STARTUP ====");
        sim.println("[ECM] Java CWD: " + cwd);
        sim.println("[ECM] OS: " + System.getProperty("os.name") + " " + System.getProperty("os.version"));
        sim.println("[ECM] Java: " + System.getProperty("java.version"));
        sim.println("[ECM] ECM_COMMAND: " + ECM_COMMAND);
        sim.println("[ECM] ECM_IN_FILE: " + ECM_IN_FILE + "  (abs: " + new File(ECM_IN_FILE).getAbsolutePath() + ")");
        sim.println("[ECM] ECM_OUT_FILE: " + ECM_OUT_FILE + "  (abs: " + new File(ECM_OUT_FILE).getAbsolutePath() + ")");

        // check script exists
        String scriptPath = ECM_COMMAND.split("\\s+")[ECM_COMMAND.split("\\s+").length - 1];
        File scriptFile = new File(scriptPath);
        sim.println("[ECM] Script '" + scriptPath + "' exists=" + scriptFile.exists()
                + "  abs=" + scriptFile.getAbsolutePath());
        if (scriptFile.getParentFile() != null) {
            File scriptDir = scriptFile.getParentFile();
            sim.println("[ECM] Script dir contents: " + java.util.Arrays.toString(scriptDir.list()));
        }

        // --- locate coupled region ---
        Region region;
        try {
            region = sim.getRegionManager().getRegion(REGION_NAME);
        } catch (Exception e) {
            sim.println("[ECM] ERROR: region '" + REGION_NAME + "' not found. Aborting.");
            return;
        }
        sim.println("[ECM] Coupled region: " + region.getPresentationName());

        // --- create or reuse VolumeAverageReport for Temperature ---
        VolumeAverageReport tReport = getOrCreateTReport(sim, region);
        sim.println("[ECM] T report ready: " + tReport.getPresentationName());

        // --- locate the heat-source parameter ---
        ScalarGlobalParameter qParam = getOrCreateQParam(sim);
        sim.println("[ECM] Heat-source parameter: " + qParam.getPresentationName());

        // --- create ecm/ output directory if needed ---
        new File("ecm").mkdirs();

        // open persistent debug log
        PrintWriter debugLog = null;
        try {
            debugLog = new PrintWriter(new FileWriter("ecm/ecm_debug.log", true));
            debugLog.println("=== ECM DEBUG LOG  " + new java.util.Date() + " ===");
            debugLog.println("CWD: " + cwd);
            debugLog.println("Command: " + ECM_COMMAND);
            debugLog.flush();
        } catch (IOException e) {
            sim.println("[ECM] WARN: could not open ecm/ecm_debug.log: " + e.getMessage());
        }

        // --- coupling loop ---
        SimulationIterator iter = sim.getSimulationIterator();
        double qVolPrev = 0.0;
        long   stepId   = 0;

        for (int step = 0; step < N_STEPS; step++) {

            // 1. Advance solver one timestep
            iter.step(1);
            stepId++;

            // 2. Read volume-average T and simulation time
            double tEff    = tReport.getValue();
            double simTime = getSimTime(sim);
            double deltaT  = getDeltaT(sim);

            sim.println(String.format("[ECM] step=%d  t=%.4f s  T_eff=%.4f K", step, simTime, tEff));

            // 3. Write ecm_in.bin
            try {
                EcmBinaryIO.writeLumpedInput(ECM_IN_FILE, stepId, tEff, simTime, deltaT);
                sim.println("[ECM] ecm_in.bin written OK  (" + new File(ECM_IN_FILE).length() + " bytes)");
            } catch (IOException e) {
                sim.println("[ECM] ERROR writing ecm_in.bin: " + e.getMessage());
                break;
            }

            // 4. Run ECM process (blocks until completion) — output routed via sim.println
            int exitCode = runProcess(sim, debugLog, ECM_COMMAND);
            if (exitCode != 0) {
                sim.println("[ECM] WARNING: ECM exited with code " + exitCode + ". Keeping previous qVol.");
                qParam.getQuantity().setValue(qVolPrev);
                continue;
            }

            // 5. Wait for ecm_out.bin (should already exist after process exits)
            if (!waitForFile(ECM_OUT_FILE, ECM_TIMEOUT_S)) {
                sim.println("[ECM] WARNING: ecm_out.bin not found within timeout. Keeping previous qVol.");
                qParam.getQuantity().setValue(qVolPrev);
                continue;
            }

            // 6. Read qVol from ecm_out.bin
            double qVolNew;
            try {
                qVolNew = EcmBinaryIO.readLumpedOutput(ECM_OUT_FILE, stepId);
            } catch (IOException e) {
                sim.println("[ECM] ERROR reading ecm_out.bin: " + e.getMessage());
                qParam.getQuantity().setValue(qVolPrev);
                continue;
            }

            if (Double.isNaN(qVolNew)) {
                sim.println("[ECM] WARNING: stepId mismatch in ECM output. Keeping previous qVol.");
                qParam.getQuantity().setValue(qVolPrev);
                continue;
            }

            // 7. Under-relaxation
            double qVol = ALPHA * qVolNew + (1.0 - ALPHA) * qVolPrev;
            qVolPrev = qVol;

            sim.println(String.format("[ECM] qVol_new=%.2f  qVol_relaxed=%.2f  W/m3", qVolNew, qVol));

            // 8. Push to solver via global parameter
            qParam.getQuantity().setValue(qVol);
        }

        sim.println("[ECM] Coupling loop complete.");
        if (debugLog != null) {
            debugLog.println("=== LOOP COMPLETE ===");
            debugLog.close();
        }
    }

    // =========================================================================
    // HELPERS
    // =========================================================================

    private VolumeAverageReport getOrCreateTReport(Simulation sim, Region region) {
        // Reuse if already exists (e.g. macro re-run)
        try {
            return (VolumeAverageReport) sim.getReportManager().getReport("ECM_T_avg");
        } catch (Exception ignored) {}

        VolumeAverageReport r = sim.getReportManager().createReport(VolumeAverageReport.class);
        r.setPresentationName("ECM_T_avg");
        r.setFieldFunction(
            sim.getFieldFunctionManager().getFunction("Temperature"));
        r.getParts().setObjects(region);
        return r;
    }

    private ScalarGlobalParameter getOrCreateQParam(Simulation sim) {
        try {
            return (ScalarGlobalParameter) sim.get(GlobalParameterManager.class)
                .getObject(QPARAM_NAME);
        } catch (Exception ignored) {}

        ScalarGlobalParameter p = (ScalarGlobalParameter) sim.get(GlobalParameterManager.class)
            .createGlobalParameter(ScalarGlobalParameter.class, QPARAM_NAME);
        p.getQuantity().setValue(0.0);
        return p;
    }

    private double getSimTime(Simulation sim) {
        // Works for transient (unsteady) simulations
        try {
            return sim.getSimulationIterator().getCurrentTimeLevel();
        } catch (Exception e) {
            return 0.0;
        }
    }

    private double getDeltaT(Simulation sim) {
        try {
            SpecifiedTimestepUnsteadySolver solver = (SpecifiedTimestepUnsteadySolver) sim.getSolverManager()
                .getSolver(ImplicitUnsteadySolver.class);
            return solver.getTimeStep().getValue();
        } catch (Exception e) {
            return 1.0; // fallback if not unsteady
        }
    }

    private int runProcess(Simulation sim, PrintWriter debugLog, String command) {
        String[] args = command.split("\\s+");
        sim.println("[ECM] Launching: " + java.util.Arrays.toString(args));
        sim.println("[ECM] Process CWD: " + new File(".").getAbsolutePath());
        if (debugLog != null) {
            debugLog.println("--- runProcess: " + java.util.Arrays.toString(args));
            debugLog.println("    CWD: " + new File(".").getAbsolutePath());
            debugLog.flush();
        }

        try {
            ProcessBuilder pb = new ProcessBuilder(args);
            pb.redirectErrorStream(true); // merge stderr into stdout
            // NOTE: pb.directory() is intentionally NOT set here so STAR-CCM+'s
            // working directory is used.  Its absolute path is logged above.
            Process p = pb.start();

            // Drain output synchronously into a list, then log everything after join
            final java.util.List<String> outputLines = new java.util.ArrayList<>();
            Thread drain = new Thread(() -> {
                try (BufferedReader br = new BufferedReader(
                        new InputStreamReader(p.getInputStream()))) {
                    String line;
                    while ((line = br.readLine()) != null) {
                        synchronized (outputLines) { outputLines.add(line); }
                    }
                } catch (IOException ignored) {}
            });
            drain.start();

            int exitCode = p.waitFor();
            drain.join(5000); // wait up to 5 s for drain to finish

            // Log all captured output via sim.println so it appears in STAR-CCM+ Output window
            synchronized (outputLines) {
                if (outputLines.isEmpty()) {
                    sim.println("[ECM-py] (no output)");
                }
                for (String line : outputLines) {
                    sim.println("[ECM-py] " + line);
                    if (debugLog != null) {
                        debugLog.println("[ECM-py] " + line);
                    }
                }
            }
            if (debugLog != null) {
                debugLog.println("    exitCode=" + exitCode);
                debugLog.flush();
            }
            sim.println("[ECM] Process exit code: " + exitCode);
            return exitCode;
        } catch (Exception e) {
            sim.println("[ECM] FATAL: Process launch failed: " + e.getMessage());
            if (debugLog != null) {
                debugLog.println("FATAL launch: " + e.getMessage());
                debugLog.flush();
            }
            return -1;
        }
    }

    private boolean waitForFile(String path, int timeoutSeconds) {
        File f = new File(path);
        long deadline = System.currentTimeMillis() + timeoutSeconds * 1000L;
        while (System.currentTimeMillis() < deadline) {
            if (f.exists() && f.length() > 0) return true;
            try { Thread.sleep(50); } catch (InterruptedException ignored) {}
        }
        return false;
    }

    // =========================================================================
    // EcmBinaryIO — binary protocol implementation (merged from EcmBinaryIO.java)
    //
    // Header layout (v1 base = 44 bytes, v2 adds 8-byte stepId = 52 bytes total):
    //   char[8]  magic     "ECMIOv1\0"
    //   uint32   fileType  1=input, 2=output
    //   uint32   version   1
    //   uint32   N         number of coupled records
    //   double   time      simulation time [s]
    //   double   deltaT    timestep size [s]
    //   uint32   keyMode   0=globalCellId
    //   uint32   nInputs   0 for lumped (no extra electrical inputs)
    //   uint64   stepId    transaction ID (v2 extension)
    //
    // Each record:
    //   int32    key       cell/element id
    //   double   value     T [K] for input, qVol [W/m3] for output
    //
    // All values are little-endian.
    // =========================================================================

    private static class EcmBinaryIO {

        private static final byte[] MAGIC           = {'E','C','M','I','O','v','1','\0'};
        private static final int    FILE_TYPE_IN    = 1;
        private static final int    FILE_TYPE_OUT   = 2;
        private static final int    VERSION         = 1;
        private static final int    KEY_MODE_GLOBAL = 0;

        private static final int HEADER_V1_BYTES = 44;
        private static final int STEP_ID_BYTES   = 8;
        private static final int RECORD_BYTES    = 12;

        static void writeLumpedInput(String path, long stepId,
                double tEff, double time, double deltaT) throws IOException {

            int totalBytes = HEADER_V1_BYTES + STEP_ID_BYTES + RECORD_BYTES;
            ByteBuffer buf = ByteBuffer.allocate(totalBytes);
            buf.order(ByteOrder.LITTLE_ENDIAN);

            buf.put(MAGIC);
            buf.putInt(FILE_TYPE_IN);
            buf.putInt(VERSION);
            buf.putInt(1); // N = 1 record
            buf.putDouble(time);
            buf.putDouble(deltaT);
            buf.putInt(KEY_MODE_GLOBAL);
            buf.putInt(0); // nInputs = 0
            buf.putLong(stepId);
            buf.putInt(0);       // key = 0
            buf.putDouble(tEff);

            atomicWrite(path, buf.array());
        }

        static double readLumpedOutput(String path, long expectedStepId) throws IOException {
            byte[] data = Files.readAllBytes(Paths.get(path));
            ByteBuffer buf = ByteBuffer.wrap(data);
            buf.order(ByteOrder.LITTLE_ENDIAN);

            buf.position(8);      // skip magic
            buf.getInt();         // fileType
            buf.getInt();         // version
            int n = buf.getInt(); // N
            buf.getDouble();      // time
            buf.getDouble();      // deltaT
            buf.getInt();         // keyMode
            int nInputs = buf.getInt();
            long echoedStepId = buf.getLong();

            if (echoedStepId != expectedStepId) {
                return Double.NaN;
            }

            // skip any echoed electrical input records
            for (int i = 0; i < nInputs; i++) {
                int nameLen = buf.getInt();
                buf.position(buf.position() + nameLen + 8);
            }

            buf.getInt(); // key
            return buf.getDouble();
        }

        private static void atomicWrite(String path, byte[] data) throws IOException {
            String tmp = path + ".tmp";
            Files.write(Paths.get(tmp), data);
            Files.move(Paths.get(tmp), Paths.get(path), StandardCopyOption.REPLACE_EXISTING);
        }
    }
}

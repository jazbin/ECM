ECM Coupler for STAR-CCM+
=========================
Validated against NCA 18650/2170 cell, 3600 s discharge. T RMSE < 0.33 deg C.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 0 — PREREQUISITES
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Your STAR-CCM+ simulation MUST be:
  - Transient (Implicit Unsteady solver enabled)
  - Energy equation active for the battery region
  - Battery region meshed and physics assigned

Python 3.9+ must be installed and on your PATH.
  Install from https://python.org — tick "Add Python to PATH".

Run setup.bat ONCE to install Python packages and verify the setup:
  > setup.bat


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 1 — PLACE FILES NEXT TO YOUR .sim FILE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The working directory for STAR-CCM+ is always the folder containing
the .sim file. The macro uses relative paths so everything must be
placed here:

  MySimulation/
  ├── MyBattery.sim
  ├── EcmCouplerMacro.jar
  ├── setup.bat
  ├── README.txt            (this file)
  └── ecm/
      ├── ecm_coupler.py
      ├── ecm_io.py
      ├── mock_ecm_backend.py
      ├── mock_model.py
      ├── params.csv
      └── electrical_inputs_from_validation.csv

If you place ecm/ anywhere else, the macro will not find it.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 2 — ONE-TIME WIRING INSIDE STAR-CCM+
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Do this ONCE. It saves into the .sim file permanently.

  A. Create the heat-source Global Parameter
     -----------------------------------------
     Tools > Parameters > New Parameter > Scalar
       Name:   ecmQdot_W_m3        <-- exact spelling, case-sensitive
       Value:  0
       Units:  W/m^3

  B. Create a Field Function that reads the parameter
     --------------------------------------------------
     Tools > Field Functions > New Scalar Field Function
       Name:       ecmQdot_field
       Definition: $ecmQdot_W_m3   <-- dollar sign + parameter name

  C. Apply the field function to the battery region's heat source
     -------------------------------------------------------------
     Regions > [your battery region] > Physics Values
       Volumetric Heat Source
         Method:   Field Function
         Function: ecmQdot_field

     If "Volumetric Heat Source" is not visible, the energy equation
     is not enabled for that region. Enable it first under:
       Physics > Continua > [continuum] > Models > Energy

  D. Save the .sim file.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 3 — FIND YOUR REGION NAME
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

The macro needs the exact name of your battery region as it appears
in the STAR-CCM+ tree (case-sensitive, including spaces).

  In STAR-CCM+: expand Regions in the simulation tree.
  The name shown there is what you need.

  Examples:
    Tree shows "jellyRoll"        -> REGION_NAME = "jellyRoll"
    Tree shows "Battery Region"   -> REGION_NAME = "Battery Region"
    Tree shows "ActiveMaterial"   -> REGION_NAME = "ActiveMaterial"

If your region is already named "jellyRoll", no change is needed.
If not, see STEP 4 to change REGION_NAME.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 4 — CONFIGURE THE MACRO (if needed)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Open src\EcmCouplerMacro.java in any text editor.
Edit the CONFIG block at the top:

  REGION_NAME   "jellyRoll"
    -> Change to your battery region name (see STEP 3).

  N_STEPS       100
    -> Set to: end_time_seconds / delta_T_seconds
       Example: 3600 s / 0.1 s = 36000

  ALPHA         0.7
    -> Under-relaxation. 1.0 = no relaxation. 0.5 = conservative.
       Lower values smooth the heat source but slow convergence.

  ECM_COMMAND   "python3 ecm/ecm_coupler.py"
    -> Change "python3" to "python" on Windows, or use the full path:
       "C:/Python312/python.exe ecm/ecm_coupler.py"

After editing, rebuild the JAR:
  bash build.sh
  copy dist\EcmCouplerMacro.jar to this folder.

See README.md (full guide) for rebuild instructions.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 5 — SET UP THE CURRENT PROFILE
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Edit ecm\electrical_inputs_from_validation.csv with your discharge
or charge current profile. Format (two columns, NO QUOTES):

  time,current_A
  0,0
  10,5.05
  3590,5.05
  3600,0

Rules:
  - Headers must be bare text with no quote characters.
  - time is in seconds; current_A is in amperes.
  - Positive current = discharge.
  - File must span the full simulation time (0 to end).
  - At least two rows required.

WARNING: If headers are quoted ("time","current_A") the ECM
         cannot read the column names and current will be 0.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 STEP 6 — RUN
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1. Open MyBattery.sim in STAR-CCM+.
  2. Verify the wiring from STEP 2 is present.
  3. Tools > Macros > Run Macro > select EcmCouplerMacro.jar
  4. The macro starts immediately. Watch the output panel for [ECM] lines.

  !! DO NOT press the Run button !!
  The macro controls the solver loop. Running both simultaneously
  corrupts the solution.

Expected output in the STAR-CCM+ console:

  [ECM] Coupled region: jellyRoll
  [ECM] T report ready: ECM_T_avg
  [ECM] Heat-source parameter: ecmQdot_W_m3
  [ECM] step=0  t=0.1000 s  T_eff=298.1500 K
  [ECM-py] ECM step t=0.10 I=5.05 A T=298.15 K Q=1.10 W SOC=1.000
  [ECM] qVol_new=45438.32  qVol_relaxed=31806.82  W/m3
  [ECM] step=1  t=0.2000 s  T_eff=298.1601 K
  ...
  [ECM] Coupling loop complete.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 BEFORE RE-RUNNING FROM TIME ZERO
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Delete these files to reset the ECM state:
  ecm\ecm_state.json
  ecm\ecm_in.bin        (optional)
  ecm\ecm_out.bin       (optional)

Or set environment variable ECM_STATE_RESET=1 before launching STAR.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 TROUBLESHOOTING
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SYMPTOM: "[ECM] ERROR: region 'jellyRoll' not found"
FIX:     Change REGION_NAME in src\EcmCouplerMacro.java to match
         the exact region name shown in the STAR-CCM+ tree.
         Rebuild the JAR, then reload the macro.

SYMPTOM: "[ECM] WARNING: ECM exited with code 1"
FIX:     Open a terminal in the .sim folder and run:
           python ecm\ecm_coupler.py --help
         Read the error. Most likely:
           - Python not on PATH -> use full path in ECM_COMMAND
           - Missing numpy/pandas -> pip install numpy pandas

SYMPTOM: Heat source stays at zero; temperature does not rise
FIX (check in order):
  1. Volumetric Heat Source must be set to Field Function (not Constant).
  2. Field function definition must be "$ecmQdot_W_m3" (no quotes, $ prefix).
  3. ecm\electrical_inputs_from_validation.csv must have UNQUOTED headers.
  4. ECM_COMMAND must point to a working Python installation.

SYMPTOM: "stepId mismatch" warnings
FIX:     Delete ecm\ecm_in.bin, ecm\ecm_out.bin, ecm\ecm_state.json
         before re-running. Stale files from a previous run cause this.

SYMPTOM: Temperature oscillates or diverges
FIX:     Reduce ALPHA (e.g. 0.7 -> 0.5) and/or reduce deltaT.


━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 ECM PARAMETERS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ecm\params.csv contains the electrochemical lookup table.
Default: NCA chemistry, 5.05 Ah nominal capacity.

Columns: Q_Ah, T_degC, OCV_V, R0_Ohm, R1_Ohm, C1_F, R2_Ohm, C2_F, DUDT_V_per_K

To use a different cell: replace params.csv with matching column names.
No code changes required.

Full documentation: README.md in the starccm_plugin/ folder of the
ECM coupling repository.

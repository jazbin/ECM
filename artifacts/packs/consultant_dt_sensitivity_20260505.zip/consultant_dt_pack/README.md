# ECM–CFD Coupling: Timestep Sensitivity vs Lumped Validation

**Date:** 2026-05-05
**Subject:** Non-monotonic timestep sensitivity in a coupled 3D CFD + ECM battery simulation
**Prepared by:** Internal engineering team

---

## 1. Context and project overview

We are developing a coupled simulation framework for battery thermal management. The system couples:

- **OpenFOAM** (`chtMultiRegionSolidFoam`) — 3D conjugate heat transfer solver running on a
  discretised cylindrical 2170 battery cell geometry (jellyRoll + shell + cap regions)
- **An equivalent circuit model (ECM)** — a 2RC lumped electrochemical model that receives the
  volume-averaged jellyRoll temperature from OpenFOAM and returns a total heat generation rate Q [W]

The coupling is explicit (staggered): at each timestep, OpenFOAM advances the temperature field
by dt, passes the new volume-averaged T to the ECM, and the ECM returns Q which is applied as a
uniform volumetric source in the next step.

The ECM uses:
- A 2RC circuit with parameters interpolated from a 2D lookup table (SoC × temperature)
- Discrete-time exact exponential RC update (not forward Euler — the RC formula is analytically exact for constant-within-step current regardless of dt)
- Forward Euler for Coulomb counting (also exact for constant-within-step current)
- NCA chemistry, 5 Ah nominal capacity
- Heat generation: Q = Q_joule + Q_entropic = I²R₀ + |I|(|V_RC1| + |V_RC2|) − I·T·dU/dT

The outer wall boundary condition is a convective Newtonian cooling:
  Q_wall = h · A · (T_surface − T_ambient),  h = 110 W/m²K,  T_ambient = 298.15 K

The electrical current profile is read from a 1-second-resolution CSV (the same profile used to
generate the validation reference). Between CSV points the current is linearly interpolated.

---

## 2. The validation reference

The validation dataset is the output of a **0D (zero-dimensional) lumped ECM simulation**. This
reference model:

- Uses the identical ECM parameters, chemistry table, and current profile
- Has a single scalar cell temperature (no spatial dimension)
- Applies the same Newtonian cooling: dT/dt = (Q − h·A·(T − T_amb)) / (m·Cp)
- The timestep of the reference simulation is **unknown** to us (the CSV is at 1-second resolution)

The validation dataset covers 0–3600 s and records: time, T_cell [K], Q_cell [W], SOC, terminal
voltage. The discharge profile heats the cell from 25 °C to approximately 46 °C over the run.

---

## 3. The observed timestep sensitivity

We ran the 3D coupled simulation at four different CFD timesteps and computed RMSE and bias of the
volume-averaged jellyRoll temperature against the validation reference:

| CFD dt [s] | T RMSE [°C] | T bias [°C] | Q RMSE [W] | Run horizon [s] |
|---|---|---|---|---|
| 0.01 | 0.155 | +0.078 | ~0.010 | 0–1793 (partial) |
| 0.05 | ~0.120 | +0.050 | ~0.007 | 0–1793 |
| **0.20** | **0.028** | **−0.001** | **0.0016** | 0–2000 |
| 0.50 | ~0.30  | −0.20  | ~0.020 | 0–1793 |

**dt = 0.2 s is clearly the best**, with RMSE roughly 5× lower than dt = 0.01 s and 10× lower
than dt = 0.5 s. This is non-monotonic: finer timesteps give worse results, not better.

The attached plots show this clearly:

- **`dt_sensitivity_4way_dt001_005_02_05.png`** — four-panel figure:
  - Top-left: temperature overlay (all dt values + validation) — curves are close
  - Top-right: heat Q overlay — all dt values essentially identical to validation
  - Bottom-left: temperature error (T_CFD − T_validation) over time — reveals the drift
  - Bottom-right: cumulative energy error — mirrors temperature error
- **`temperature_overlay_dt001_dt005.png`** — dt=0.01 and dt=0.05 compared to validation;
  both nearly identical to each other, both slightly above validation toward end of run
- **`temperature_diff_dt001_dt005.png`** — the growing positive error for the two finer dt values
- **`heat_overlay_dt001_dt005.png`** — heat generation comparison (near-perfect agreement in Q)

---

## 4. Characterisation of the error

Several properties of the error are relevant:

**The heat Q is correct across all dt values.** The ECM returns nearly identical Q regardless of
dt (RMSE <0.01 W for all runs). This means the ECM integration is not the issue — the RC update
formula is dt-independent by construction.

**The temperature error is a growing drift, not oscillatory.** Starting near zero, the error grows
monotonically from ~0 to its peak by the end of the run. This suggests an accumulating offset in
the energy balance, not a frequency-sensitive numerical artifact.

**The error is sign-asymmetric around dt = 0.2:** finer dt → positive T bias, coarser dt →
negative T bias. dt = 0.2 sits at the zero-crossing.

**The finer-dt runs (0.01 and 0.05) agree closely with each other** but both deviate from
validation. This rules out pure integration noise and suggests convergence toward a physically
different result.

---

## 5. Our hypothesis

We believe the root cause is a **fundamental model discrepancy between 3D CFD and the 0D
reference**, and that the dt sensitivity is a manifestation of how numerical diffusion in the
implicit CFD solver interacts with this discrepancy.

### 5.1 The 3D vs 0D temperature mismatch

In the 0D reference model, the cell temperature is spatially uniform:
- The surface temperature equals the core temperature
- The convective heat loss is Q_wall = h·A·(T_cell − T_amb)
- The volume-average temperature IS the cell temperature

In the 3D CFD:
- Heat is generated uniformly in the jellyRoll interior
- Heat conducts radially and axially outward through the solid cell
- A radial temperature gradient develops: T_core > T_surface
- The convective BC acts on the surface temperature: Q_wall = h·A·(T_surface − T_amb)
- The volume-average temperature fed to the ECM is between T_core and T_surface

The consequence: for the same Q_GEN, the 3D model loses less heat through the wall
(because T_surface < T_volume_avg < T_core), so the volume-average temperature rises faster
than in the 0D reference. This creates a systematic positive bias when comparing
T_volume_avg_3D against T_cell_0D.

### 5.2 Why dt matters

At **finer dt** (e.g. 0.01 s), the 3D implicit solver accurately resolves the spatial temperature
gradient — the solution converges toward the true 3D solution, which has a meaningful
core-to-surface temperature difference. The volume average is noticeably higher than the 0D
reference → positive bias.

At **coarser dt** (e.g. 0.2 s), the implicit time-stepping introduces numerical diffusion in the
time direction. This effectively reduces the apparent spatial gradient in the volume-averaged
quantity — the 3D volume average numerically resembles a well-mixed temperature more closely.
The RMSE against the 0D reference is lower, but **this is a cancellation of errors**, not genuine
model accuracy.

At **very coarse dt** (e.g. 0.5 s), the numerical diffusion over-corrects and the solution
undershoots → negative bias.

### 5.3 Implication

**dt = 0.2 s is not the most physically accurate CFD timestep.** It is the timestep at which
numerical diffusion happens to cancel the 3D-vs-0D model discrepancy. Refining the mesh or the
timestep further would worsen the RMSE against the 0D reference, even though the CFD solution
itself becomes more accurate.

This is a classical sign of comparing an approximate model (0D) against a higher-fidelity model
(3D) without accounting for the structural difference between them.

---

## 6. Open questions for the consultant

We are looking for guidance on the following:

**Q1 — Is our hypothesis correct?**
Is the growing positive bias at fine dt consistent with a 3D spatial gradient effect? Are there
other explanations we should consider (e.g., coupling lag effects, current profile interpolation,
or numerical issues in the ECM state integration)?

**Q2 — Is there a principled correction?**
Is there a physically justified way to make the 3D volume-average temperature comparable to the
0D cell temperature? For example:
- Replacing T_volume_avg with a weighted combination of T_volume_avg and T_surface?
- Using an effective thermal resistance to correct for the internal gradient?
- Using the surface temperature directly as the ECM feedback temperature?

**Q3 — What is the right reference for a 3D model?**
If the 0D validation is structurally incompatible with 3D comparison, what reference should we use?
Options:
- Run the same ECM standalone (Python, no CFD) and compare ECM state directly — this would
  isolate ECM integration accuracy from the CFD spatial model
- Generate a 3D reference solution at very fine dt and compare all other dt values against it
- Accept the 0D reference as a practical benchmark with documented limitations

**Q4 — Is dt = 0.2 a reasonable operating point?**
Given the analysis, is it defensible to operate at dt = 0.2 s and report RMSE = 0.028 °C against
the 0D reference, while documenting that this is a best-practical-match rather than a convergence
guarantee? Are there circumstances under which finer dt would become necessary?

**Q5 — Does the ECM coupling interval matter independently?**
In our setup, the ECM is called at every CFD timestep (no subcycling). The electrical time
constants of the ECM (RC₁ ≈ 1.6 s, RC₂ ≈ 25 s) are both much larger than the CFD dt. Would
calling the ECM less frequently (e.g. every 1 s regardless of CFD dt) improve temporal consistency
with the 1-second validation reference while allowing finer CFD dt for the thermal field?

---

## 7. Summary

| Item | Value |
|---|---|
| Best operating dt | 0.2 s |
| Best T RMSE | 0.028 °C |
| Best Q RMSE | 0.0016 W |
| Suspected root cause | 3D spatial gradient vs 0D uniform T reference |
| ECM integration accuracy | Not in question — RC formula is exact for any dt |
| Code bugs contributing to this | None (two bugs fixed in distributed mode; lumped path unaffected) |
| Validation reference resolution | 1 second |
| Validation reference dt | Unknown |

The core problem is structural: we are comparing a spatially-resolved 3D model against a
spatially-degenerate 0D reference. The apparent "best" timestep is the one where numerical
diffusion compensates for this structural gap, which is not a satisfying engineering answer.
We would welcome guidance on the most rigorous path forward.

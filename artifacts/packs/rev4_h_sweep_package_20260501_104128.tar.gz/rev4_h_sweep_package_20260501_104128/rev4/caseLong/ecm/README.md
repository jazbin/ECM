Fresh runtime ECM state is written here by `./Allrun`.

This package intentionally ships without prior `ecm_state.json`, `last_good.bin`, or restart checkpoints.

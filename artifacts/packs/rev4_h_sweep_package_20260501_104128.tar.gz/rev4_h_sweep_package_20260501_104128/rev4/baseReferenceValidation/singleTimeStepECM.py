"""Thermal ECM model with precomputed table lookups.

I/O:
  - Inputs: parameter tables (AEP), cell properties, boundary/initial settings.
  - Outputs: single-timestep state update and derived signals.
"""

import math

import numpy as np
from scipy.interpolate import LinearNDInterpolator
from scipy.spatial import cKDTree

PARAM_NAMES = [
    "R0_Ohm",
    "R_Ohm_1",
    "R_Ohm_2",
    "C_F_1",
    "C_F_2",
    "E_OCV_dch_V",
    "E_OCV_ch_V",
    "gamma",
    "dUdT",
]


class ECMThermal:
    """Thermal ECM with precomputed table lookups and single-step advance."""

    def __init__(
        self,
        params_df,
        cellprops_df,
        T_amb=25.0,
        h=10.0,
        init_soc=1.0,
        init_T_cell=25.0,
        init_V_RC=None,
        init_H=0.0,
        lambda_Q=1.0,
        lambda_R=1.0,
        useEndFlags=False,
        V_max=4.2,
        V_min=2.5,
        T_max=70.0,
    ):
        # Store tables and physical constants needed for runtime lookups.
        self.params_df = params_df
        self.cp = float(cellprops_df["Cp_cell_J_K-1"].iloc[0])
        self.mass = float(cellprops_df["mass_g"].iloc[0]/1000.0)  # Convert grams to kilograms
        self.area = float(cellprops_df["Asurf_m2"].iloc[0])
        self.Q_NOM = float(cellprops_df["Qnom_Ah"].iloc[0])
        self.T_amb = float(T_amb)
        self.h = float(h)
        self.lambda_Q = float(lambda_Q)
        self.lambda_R = float(lambda_R)
        self.useEndFlags = bool(useEndFlags)
        self.V_max = float(V_max)
        self.V_min = float(V_min)
        self.T_max = float(T_max)
        self.init_T_cell = float(init_T_cell)
        self.init_V_RC = np.zeros(2) if init_V_RC is None else np.array(init_V_RC)
        self.init_H = float(init_H)

        # Map initial SOC to the closest table capacity.
        self.init_q_ah = float(
            params_df.loc[(params_df["SOC"] - init_soc).abs().idxmin(), "Q_Ah"]
        ) * self.lambda_Q

        # Build interpolators and a fallback nearest-neighbour lookup.
        self._points = params_df[["Q_Ah", "T_degC"]].to_numpy()
        self._tree = cKDTree(self._points)
        self._interpolators = {}
        for param in PARAM_NAMES:
            values = params_df[param].to_numpy()
            self._interpolators[param] = LinearNDInterpolator(
                self._points, values, fill_value=np.nan
            )

    @classmethod
    def from_csvs(cls, params_path, cellprops_path, **kwargs):
        """Create an ECM input instance from CSV inputs."""
        import pandas as pd

        params_df = pd.read_csv(params_path)
        cellprops_df = pd.read_csv(cellprops_path)
        return cls(params_df=params_df, cellprops_df=cellprops_df, **kwargs)

    def initial_state(self):
        """Return the initial state vector [V_RC1, V_RC2, Tcell, H]."""
        return np.hstack([self.init_V_RC, self.init_T_cell, self.init_H])

    def _lookup(self, q_ah, T_cell, param_name):
        # Interpolate table values, with a nearest fallback outside the hull.
        interp_func = self._interpolators[param_name]
        val = interp_func([q_ah, T_cell])
        val_arr = np.asarray(val)
        if np.isnan(val_arr).any():
            _, idx = self._tree.query([q_ah, T_cell])
            val = self.params_df[param_name].iloc[idx]
            return float(val)
        return float(val_arr.item())

    def _get_params(self, q_ah, T_cell):
        """Fetch interpolated ECM parameters for the current state."""
        # Apply capacity fade for table look-ups (Simscape SOC definition).
        q_ah_lookup = q_ah / self.lambda_Q if self.lambda_Q > 0.0 else q_ah
        return {
            "R0": self._lookup(q_ah_lookup, T_cell, "R0_Ohm") * self.lambda_R,
            "R1": self._lookup(q_ah_lookup, T_cell, "R_Ohm_1"),
            "R2": self._lookup(q_ah_lookup, T_cell, "R_Ohm_2"),
            "C1": self._lookup(q_ah_lookup, T_cell, "C_F_1"),
            "C2": self._lookup(q_ah_lookup, T_cell, "C_F_2"),
            "V_OCV_DCH": self._lookup(q_ah_lookup, T_cell, "E_OCV_dch_V"),
            "V_OCV_CH": self._lookup(q_ah_lookup, T_cell, "E_OCV_ch_V"),
            "GAMMA": self._lookup(q_ah_lookup, T_cell, "gamma"),
            "DUDT": self._lookup(q_ah_lookup, T_cell, "dUdT"),
        }

    def _voltage_heat_terms(self, V_RC, I, T_cell, R0, V_OCV):
        """Compute voltage and heat terms from state and parameters."""
        V_OP = (R0 * I) + V_RC[0] + V_RC[1]
        V_T = V_OCV + V_OP
        Q_IR = I * (V_T - V_OCV)
        Q_CONV = self.h * self.area * (T_cell - self.T_amb)
        return V_OP, V_T, Q_IR, Q_CONV

    def _resolve_current(self, load_value, V_T_prev, input_mode):
        if input_mode == "power":
            denom = V_T_prev if abs(V_T_prev) > 1e-6 else 1e-6
            return load_value / denom
        return load_value

    def compute_outputs(self, state, I, q_ah):
        """Compute voltages, heat terms, and parameters for a given state."""
        # Look up state-dependent parameters.
        V_RC = state[:2]
        T_cell = state[2]
        H = state[3]
        params = self._get_params(q_ah, T_cell)
        # Combine charge/discharge OCV via hysteresis state.
        V_OCV_AVG = 0.5 * (params["V_OCV_CH"] + params["V_OCV_DCH"])
        V_OCV = 0.5 * (1.0 + H) * params["V_OCV_CH"] + 0.5 * (1.0 - H) * params[
            "V_OCV_DCH"
        ]
        # Voltage and heat terms from the electrical state.
        V_OP, V_T, Q_IR, Q_CONV = self._voltage_heat_terms(
            V_RC, I, T_cell, params["R0"], V_OCV
        )
        # Heat terms: irreversible, hysteresis, and reversible.
        Q_HYS = I * (V_OCV - V_OCV_AVG)
        T_K = T_cell + 273.15
        Q_REV = I * T_K * params["DUDT"]
        Q_GEN = Q_IR + Q_HYS + Q_REV
	
        
        print (
            #V_RC.copy(),
            float(T_cell),
            #params["R0"],
            #params["R1"],
            #params["R2"],
            #params["C1"],
            #params["C2"],
            #params["V_OCV_DCH"],
            #params["V_OCV_CH"],
            #V_OCV_AVG,
            #V_OCV,
            #V_OP,
            #V_T,
            #Q_IR,
            #Q_HYS,
            #Q_REV,
            Q_GEN,
            #Q_CONV,
            #float(H),
        )
        

        return {
            "V_RC": V_RC.copy(),
            "T_CELL": float(T_cell),
            "R0": params["R0"],
            "R1": params["R1"],
            "R2": params["R2"],
            "C1": params["C1"],
            "C2": params["C2"],
            "V_OCV_DCH": params["V_OCV_DCH"],
            "V_OCV_CH": params["V_OCV_CH"],
            "V_OCV_AVG": V_OCV_AVG,
            "V_OCV": V_OCV,
            "V_OP": V_OP,
            "V_T": V_T,
            "Q_IR": Q_IR,
            "Q_HYS": Q_HYS,
            "Q_REV": Q_REV,
            "Q_GEN": Q_GEN,
            "Q_CONV": Q_CONV,
            "H": float(H),
        }

    def step(self, dt_s, I, q_ah, state):
        """Advance the model by one timestep and return new outputs."""
        V_RC = state[:2]
        T_cell = state[2]
        H = state[3]

        # Look up parameters for the current state.
        params = self._get_params(q_ah, T_cell)
        tau1 = params["R1"] * params["C1"]
        tau2 = params["R2"] * params["C2"]

        exp1 = math.exp(-dt_s / tau1) if tau1 > 0.0 else 0.0
        exp2 = math.exp(-dt_s / tau2) if tau2 > 0.0 else 0.0

        # Analytical RC update, explicit thermal update.
        V_RC_next = np.empty(2)
        V_RC_next[0] = V_RC[0] * exp1 + I * params["R1"] * (1.0 - exp1)
        V_RC_next[1] = V_RC[1] * exp2 + I * params["R2"] * (1.0 - exp2)

        # Update OCV and heat terms with hysteresis.
        V_OCV_AVG = 0.5 * (params["V_OCV_CH"] + params["V_OCV_DCH"])
        V_OCV = 0.5 * (1.0 + H) * params["V_OCV_CH"] + 0.5 * (1.0 - H) * params[
            "V_OCV_DCH"
        ]
        V_OP, _, Q_IR, Q_CONV = self._voltage_heat_terms(
            V_RC_next, I, T_cell, params["R0"], V_OCV
        )
        Q_HYS = I * (V_OCV - V_OCV_AVG)
        T_K = T_cell + 273.15
        Q_REV = I * T_K * params["DUDT"]
        Q_GEN = Q_IR + Q_HYS + Q_REV
        T_next = T_cell + (dt_s * (Q_GEN - Q_CONV) / (self.mass * self.cp))

        # Hysteresis state update with bounds.
        I_N = I / (3600.0 * self.Q_NOM) if self.Q_NOM > 0.0 else 0.0
        H_next = H + dt_s * params["GAMMA"] * abs(I_N) * (np.sign(I) - H)
        H_next = np.clip(H_next, -1.0, 1.0)

        state_next = np.array([V_RC_next[0], V_RC_next[1], T_next, H_next])
        Q_AH_next = q_ah + (I * dt_s / 3600.0)
        outputs = self.compute_outputs(state_next, I, Q_AH_next)
        return state_next, Q_AH_next, outputs

    def run_timeseries(self, t_s, load, input_mode="current"):
        """Step the model across a full time series and return results."""
        if len(t_s) == 0 or len(load) == 0:
            raise ValueError("t_s and load must be non-empty.")
        if len(t_s) != len(load):
            raise ValueError("t_s and load must have the same length.")
        if np.any(np.diff(t_s) < 0):
            raise ValueError("t_s must be monotonically non-decreasing.")
        n = len(t_s)
        state = self.initial_state()
        Q_AH = self.init_q_ah
        stop_idx = n
        soc_den = self.Q_NOM * self.lambda_Q if self.lambda_Q > 0.0 else self.Q_NOM

        V_RC_hist = np.zeros((n, 2))
        T_CELL_hist = np.zeros(n)
        SOC_hist = np.zeros(n)
        I_hist = np.zeros(n)
        V_OCV_hist = np.zeros(n)
        V_OCV_DCH_hist = np.zeros(n)
        V_OCV_CH_hist = np.zeros(n)
        V_OCV_AVG_hist = np.zeros(n)
        V_T_hist = np.zeros(n)
        V_OP_hist = np.zeros(n)
        Q_IR_hist = np.zeros(n)
        Q_HYS_hist = np.zeros(n)
        Q_REV_hist = np.zeros(n)
        Q_GEN_hist = np.zeros(n)
        Q_CONV_hist = np.zeros(n)
        Q_AH_hist = np.zeros(n)
        H_hist = np.zeros(n)

        # Capture initial outputs.
        outputs0 = self.compute_outputs(state, 0.0, Q_AH)
        I0 = self._resolve_current(load[0], outputs0["V_T"], input_mode)
        outputs = self.compute_outputs(state, I0, Q_AH)
        I_hist[0] = I0
        V_RC_hist[0] = outputs["V_RC"]
        T_CELL_hist[0] = outputs["T_CELL"]
        SOC_hist[0] = 1.0 + (Q_AH / soc_den) if soc_den != 0.0 else np.nan
        V_OCV_hist[0] = outputs["V_OCV"]
        V_OCV_DCH_hist[0] = outputs["V_OCV_DCH"]
        V_OCV_CH_hist[0] = outputs["V_OCV_CH"]
        V_OCV_AVG_hist[0] = outputs["V_OCV_AVG"]
        V_T_hist[0] = outputs["V_T"]
        V_OP_hist[0] = outputs["V_OP"]
        Q_IR_hist[0] = outputs["Q_IR"]
        Q_HYS_hist[0] = outputs["Q_HYS"]
        Q_REV_hist[0] = outputs["Q_REV"]
        Q_GEN_hist[0] = outputs["Q_GEN"]
        Q_CONV_hist[0] = outputs["Q_CONV"]
        Q_AH_hist[0] = Q_AH
        H_hist[0] = outputs["H"]
        if self.useEndFlags:
            if (
                outputs["V_T"] > self.V_max
                or outputs["V_T"] < self.V_min
                or outputs["T_CELL"] > self.T_max
            ):
                stop_idx = 1

        # Step through the profile using the previous current sample.
        for i in range(1, n):
            dt_s = t_s[i] - t_s[i - 1]
            I_step = self._resolve_current(load[i - 1], outputs["V_T"], input_mode)
            state, Q_AH, outputs = self.step(dt_s, I_step, Q_AH, state)
            I_hist[i] = I_step
            V_RC_hist[i] = outputs["V_RC"]
            T_CELL_hist[i] = outputs["T_CELL"]
            SOC_hist[i] = 1.0 + (Q_AH / soc_den) if soc_den != 0.0 else np.nan
            V_OCV_hist[i] = outputs["V_OCV"]
            V_OCV_DCH_hist[i] = outputs["V_OCV_DCH"]
            V_OCV_CH_hist[i] = outputs["V_OCV_CH"]
            V_OCV_AVG_hist[i] = outputs["V_OCV_AVG"]
            V_T_hist[i] = outputs["V_T"]
            V_OP_hist[i] = outputs["V_OP"]
            Q_IR_hist[i] = outputs["Q_IR"]
            Q_HYS_hist[i] = outputs["Q_HYS"]
            Q_REV_hist[i] = outputs["Q_REV"]
            Q_GEN_hist[i] = outputs["Q_GEN"]
            Q_CONV_hist[i] = outputs["Q_CONV"]
            Q_AH_hist[i] = Q_AH
            H_hist[i] = outputs["H"]
            if self.useEndFlags:
                if (
                    outputs["V_T"] > self.V_max
                    or outputs["V_T"] < self.V_min
                    or outputs["T_CELL"] > self.T_max
                ):
                    stop_idx = i + 1
                    break

        V_RC_hist = V_RC_hist[:stop_idx]
        T_CELL_hist = T_CELL_hist[:stop_idx]
        SOC_hist = SOC_hist[:stop_idx]
        I_hist = I_hist[:stop_idx]
        V_OCV_hist = V_OCV_hist[:stop_idx]
        V_OCV_DCH_hist = V_OCV_DCH_hist[:stop_idx]
        V_OCV_CH_hist = V_OCV_CH_hist[:stop_idx]
        V_OCV_AVG_hist = V_OCV_AVG_hist[:stop_idx]
        V_T_hist = V_T_hist[:stop_idx]
        V_OP_hist = V_OP_hist[:stop_idx]
        Q_IR_hist = Q_IR_hist[:stop_idx]
        Q_HYS_hist = Q_HYS_hist[:stop_idx]
        Q_REV_hist = Q_REV_hist[:stop_idx]
        Q_GEN_hist = Q_GEN_hist[:stop_idx]
        Q_CONV_hist = Q_CONV_hist[:stop_idx]
        Q_AH_hist = Q_AH_hist[:stop_idx]
        H_hist = H_hist[:stop_idx]

        results = {
            "I": I_hist,
            "LOAD": load[:stop_idx],
            "INPUT_MODE": input_mode,
            "V_RC": V_RC_hist,
            "T_CELL": T_CELL_hist,
            "SOC": SOC_hist,
            "V_OCV": V_OCV_hist,
            "V_OCV_DCH": V_OCV_DCH_hist,
            "V_OCV_CH": V_OCV_CH_hist,
            "V_OCV_AVG": V_OCV_AVG_hist,
            "V_OP": V_OP_hist,
            "V_T": V_T_hist,
            "Q_IR": Q_IR_hist,
            "Q_HYS": Q_HYS_hist,
            "Q_REV": Q_REV_hist,
            "Q_GEN": Q_GEN_hist,
            "Q_CONV": Q_CONV_hist,
            "Q_AH": Q_AH_hist,
            "H": H_hist,
            "STOP_INDEX": stop_idx,
        }

        return results

    def trim_time(self, t_s, results):
        """Trim time and result arrays to STOP_INDEX."""
        stop_idx = results.get("STOP_INDEX", len(t_s))
        t_s_trim = t_s[:stop_idx]
        results_trim = {k: v for k, v in results.items()}
        for key, value in results.items():
            if isinstance(value, np.ndarray) and value.shape[0] >= stop_idx:
                results_trim[key] = value[:stop_idx]
        return t_s_trim, results_trim

    def results_to_dataframe(self, results, t_s=None):
        """Convert results to a pandas DataFrame, optionally including time."""
        import pandas as pd

        data = {k: v for k, v in results.items() if isinstance(v, np.ndarray)}
        if t_s is not None:
            t_s_trim, data = self.trim_time(t_s, data)
            data["t_s"] = t_s_trim
        return pd.DataFrame(data)


"""Wrapper to run the ECM and plot results.

I/O:
  - Inputs: CSV files for ECM tables, validation data, and cell properties.
  - Outputs: result arrays passed to the plotting utility.
"""

import numpy as np
import pandas as pd
import yaml

from AE_ECM import ECMThermal
from AE_ECM_plot import plot_results


def extract_ecm_inputs(
    validation_df,
    time_col="t_ss",
    load_col="load",
    load_sign=1.0,
):
    """Extract ECM time-series inputs from a validation dataframe."""
    # Pull time and load with the chosen sign convention.
    t_s = validation_df[time_col].to_numpy()
    load = validation_df[load_col].to_numpy() * load_sign
    return t_s, load


def extract_exp_data(
    validation_df,
    V_exp_col="v_terminal",
    T_exp_col="T_cell_degC",
    Q_exp_col="Q_cell_W",
    Q_conv_exp_col="Q_ext_W",
    V_OCV_col="OCV",
):
    """Extract experimental channels for plotting."""
    # Keep experimental data separate from the ECM class.
    return {
        "V_EXP": validation_df[V_exp_col].to_numpy(),
        "T_EXP": validation_df[T_exp_col].to_numpy(),
        "Q_EXP": validation_df[Q_exp_col].to_numpy(),
        "Q_CONV_EXP": validation_df[Q_conv_exp_col].to_numpy(),
        "V_OCV": validation_df[V_OCV_col].to_numpy(),
    }


def main():
    """Load data, step the ECM in time, then plot results."""
    # Load parameter tables, boundary conditions, and validation inputs.
    with open(r"data/ecm_config.yaml", "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f) or {}

    cfg_model = dict(cfg)
    input_mode = (cfg_model.pop("input_mode", "current") or "current").lower()
    model = ECMThermal.from_csvs(
        params_path=r"data/cylindrical_params.csv",
        cellprops_path=r"data/cylindrical_cellprops.csv",
        **cfg_model,
    )
    validation_df = pd.read_csv(r"data/cylindrical_validation_WLTP.csv")

    # Extract inputs and run the time‑series simulation.
    t_s, load = extract_ecm_inputs(validation_df)
    exp_data = extract_exp_data(validation_df)
    
    print("Simulation starting...")
    
    results = model.run_timeseries(t_s, load, input_mode=input_mode)
    t_s, results = model.trim_time(t_s, results)
    
    for key in exp_data:
        exp_data[key] = exp_data[key][:len(t_s)]

    # Calculate error metrics outside the ECM class.
    if "V_EXP" in exp_data:
        err_v = results["V_T"] - exp_data["V_EXP"]
        running_rmse = np.sqrt(
            np.cumsum(err_v**2) / np.arange(1, len(exp_data["V_EXP"]) + 1)
        )
        results["ERR_V"] = err_v
        results["RUNNING_RMSE"] = running_rmse

    print("Simulation completed.")

    # Plot after simulation completes.
    #plot_results(t_s, results, exp_data)


if __name__ == "__main__":
    main()

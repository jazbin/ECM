"""Plotting utilities for ECM results.

I/O:
  - Inputs: time array, simulation results, experimental data.
  - Outputs: Matplotlib figures for visual comparison.
"""

import math

import matplotlib.pyplot as plt
import numpy as np


def _rgb_perm(base, idx):
    perms = [
        (base[0], base[1], base[2]),
        (base[0], base[2], base[1]),
        (base[1], base[0], base[2]),
        (base[1], base[2], base[0]),
        (base[2], base[0], base[1]),
        (base[2], base[1], base[0]),
    ]
    return perms[idx % len(perms)]


def plot_results(t_s, results, exp_data=None):
    """Render comparison and RMSE plots for voltage, temperature, and heat."""
    exp_data = exp_data or {}
    t_sec = t_s
    t_end = math.ceil(t_sec[-1])

    base = (0.7, 0.3, 0.3)
    py_color = _rgb_perm(base, 0)
    exp_color = _rgb_perm(base, 3)
    rmse_color = (0.0, 0.0, 0.0)

    fig, axs = plt.subplots(2, 3, figsize=(14, 8), sharex=True)

    # Voltage comparison.
    ax = axs[0, 0]
    ax.plot(t_sec, results["V_T"], color=py_color, label="Python")
    if "V_EXP" in exp_data:
        ax.plot(t_sec, exp_data["V_EXP"], color=exp_color, label="Simulink")
    ax.set_ylabel("Voltage (V)", fontweight="bold")
    ax.set_title("Terminal Voltage")
    ax.set_xlim(0, t_end)
    ax.legend()

    # Temperature comparison.
    ax = axs[0, 1]
    ax.plot(t_sec, results["T_CELL"], color=py_color, label="Python")
    if "T_EXP" in exp_data:
        ax.plot(t_sec, exp_data["T_EXP"], color=exp_color, label="Simulink")
    ax.set_ylabel("Temperature (°C)", fontweight="bold")
    ax.set_title("Temperature")
    ax.set_xlim(0, t_end)
    ax.legend()

    # Heat generation comparison.
    ax = axs[0, 2]
    ax.plot(t_sec, results["Q_GEN"], color=py_color, label="Python")
    if "Q_EXP" in exp_data:
        ax.plot(t_sec, exp_data["Q_EXP"], color=exp_color, label="Simulink")
    ax.set_ylabel("Heat gen (W)", fontweight="bold")
    ax.set_title("Total Heat Generation")
    ax.set_xlim(0, t_end)
    ax.legend()

    # Voltage RMSE.
    ax = axs[1, 0]
    if "ERR_V" in results:
        rmse_v = np.sqrt(
            np.cumsum(results["ERR_V"] ** 2) / np.arange(1, len(t_sec) + 1)
        )
        ax.plot(t_sec, rmse_v, color=rmse_color, label="RMSE")
    ax.set_xlabel("Time [s]", fontweight="bold")
    ax.set_ylabel("RMSE (V)", fontweight="bold")
    ax.set_xlim(0, t_end)

    # Temperature RMSE.
    ax = axs[1, 1]
    if "T_EXP" in exp_data:
        err_t = results["T_CELL"] - exp_data["T_EXP"]
        rmse_t = np.sqrt(np.cumsum(err_t**2) / np.arange(1, len(t_sec) + 1))
        ax.plot(t_sec, rmse_t, color=rmse_color, label="RMSE")
    ax.set_xlabel("Time [s]", fontweight="bold")
    ax.set_ylabel("RMSE (°C)", fontweight="bold")
    ax.set_xlim(0, t_end)

    # Heat generation RMSE.
    ax = axs[1, 2]
    if "Q_EXP" in exp_data:
        err_q = results["Q_GEN"] - exp_data["Q_EXP"]
        rmse_q = np.sqrt(np.cumsum(err_q**2) / np.arange(1, len(t_sec) + 1))
        ax.plot(t_sec, rmse_q, color=rmse_color, label="RMSE")
    ax.set_xlabel("Time [s]", fontweight="bold")
    ax.set_ylabel("RMSE (W)", fontweight="bold")
    ax.set_xlim(0, t_end)

    for ax in axs.flatten():
        ax.minorticks_on()
        ax.grid(True, which="both", linewidth=0.4, alpha=0.6)

    fig.tight_layout()

    plt.show()

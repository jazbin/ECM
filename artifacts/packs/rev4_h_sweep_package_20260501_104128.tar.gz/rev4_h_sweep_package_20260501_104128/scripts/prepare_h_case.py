#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
import shutil
from pathlib import Path


def replace_one(pattern: str, repl: str, text: str, path: Path) -> str:
    updated, count = re.subn(pattern, repl, text, count=1, flags=re.MULTILINE)
    if count != 1:
        raise RuntimeError(f"Expected one match for pattern {pattern!r} in {path}")
    return updated


def patch_text(path: Path, replacements: list[tuple[str, str]]) -> None:
    text = path.read_text(encoding="utf-8")
    for pattern, repl in replacements:
        text = replace_one(pattern, repl, text, path)
    path.write_text(text, encoding="utf-8")


def remove_time_dirs(case_dir: Path) -> None:
    for child in case_dir.iterdir():
        if child.is_dir() and re.fullmatch(r"\d+(?:\.\d+)?", child.name):
            shutil.rmtree(child)


def main() -> None:
    parser = argparse.ArgumentParser(description="Clone and patch an h-sweep case.")
    parser.add_argument("--base-case", required=True)
    parser.add_argument("--dest", required=True)
    parser.add_argument("--h", required=True, type=float)
    parser.add_argument("--end-time", required=True, type=float)
    parser.add_argument("--write-interval", required=True, type=float)
    args = parser.parse_args()

    base_case = Path(args.base_case).resolve()
    dest = Path(args.dest).resolve()

    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(base_case, dest)

    remove_time_dirs(dest)
    shutil.rmtree(dest / "logs", ignore_errors=True)
    shutil.rmtree(dest / "postProcessing", ignore_errors=True)
    shutil.rmtree(dest / "ecm", ignore_errors=True)
    (dest / "logs").mkdir(parents=True, exist_ok=True)
    (dest / "ecm").mkdir(parents=True, exist_ok=True)

    control_dict = dest / "system" / "controlDict"
    patch_text(
        control_dict,
        [
            (r"(^\s*endTime\s+)([^;]+);", rf"\g<1>{args.end_time:g};"),
            (r"(^\s*writeInterval\s+)([^;]+);", rf"\g<1>{args.write_interval:g};"),
        ],
    )

    for rel in ["initBCs/shell_rotated/T", "initBCs/cap_rotated/T"]:
        patch_text(
            dest / rel,
            [(r"(^\s*h\s+uniform\s+)([^;]+);", rf"\g<1>{args.h:g};")],
        )

    run_info = dest / "RUN_INFO.txt"
    run_info.write_text(
        "\n".join(
            [
                f"base_case={base_case}",
                f"h={args.h:g}",
                f"end_time={args.end_time:g}",
                f"write_interval={args.write_interval:g}",
                "heat_split_jellyroll=0.966",
                "heat_split_cap=0.033998",
            ]
        )
        + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    main()

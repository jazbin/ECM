#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


def parse_h(case_name: str) -> float:
    raw = case_name.removeprefix("case_h_").replace("p", ".")
    return float(raw)


def main() -> None:
    parser = argparse.ArgumentParser(description="Rank h-sweep runs by temperature fit.")
    parser.add_argument("--runs-root", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--output-md", required=True)
    args = parser.parse_args()

    runs_root = Path(args.runs_root).resolve()
    rows: list[dict[str, object]] = []

    for case_dir in sorted(runs_root.glob("case_h_*")):
        metrics_path = case_dir / "analysis" / "metrics.json"
        if not metrics_path.exists():
            continue
        payload = json.loads(metrics_path.read_text(encoding="utf-8"))
        row = {
            "case": case_dir.name,
            "h_w_m2k": parse_h(case_dir.name),
            "temp_rmse_c": payload["temp_rmse_c"],
            "temp_bias_c": payload["temp_bias_c"],
            "temp_end_error_c": payload["temp_end_error_c"],
            "heat_rmse_w": payload["heat_rmse_w"],
            "heat_bias_w": payload["heat_bias_w"],
            "heat_end_error_w": payload["heat_end_error_w"],
            "t_end_s": payload["t_end_s"],
        }
        rows.append(row)

    rows.sort(key=lambda r: (abs(float(r["temp_rmse_c"])), abs(float(r["temp_bias_c"])), abs(float(r["temp_end_error_c"]))))

    output_csv = Path(args.output_csv).resolve()
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    with output_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "case",
                "h_w_m2k",
                "temp_rmse_c",
                "temp_bias_c",
                "temp_end_error_c",
                "heat_rmse_w",
                "heat_bias_w",
                "heat_end_error_w",
                "t_end_s",
            ],
        )
        writer.writeheader()
        writer.writerows(rows)

    lines = [
        "# H Sweep Ranking",
        "",
        "| case | h [W/m^2/K] | temp RMSE [C] | temp bias [C] | temp end err [C] | heat RMSE [W] | heat bias [W] | heat end err [W] |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for row in rows:
        lines.append(
            "| {case} | {h_w_m2k:.3f} | {temp_rmse_c:.6f} | {temp_bias_c:.6f} | {temp_end_error_c:.6f} | {heat_rmse_w:.6f} | {heat_bias_w:.6f} | {heat_end_error_w:.6f} |".format(
                **row
            )
        )
    Path(args.output_md).resolve().write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

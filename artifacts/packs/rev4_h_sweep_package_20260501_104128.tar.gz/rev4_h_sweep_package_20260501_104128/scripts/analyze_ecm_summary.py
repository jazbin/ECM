#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def load_validation(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    t_s: list[float] = []
    q_w: list[float] = []
    t_c: list[float] = []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            t_s.append(float(row["t_ss"]))
            q_w.append(float(row["Q_cell_W"]))
            t_c.append(float(row["T_cell_K"]) - 273.15)
    return np.array(t_s), np.array(q_w), np.array(t_c)


def load_summary(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    t_s: list[float] = []
    q_w: list[float] = []
    t_c: list[float] = []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            t_s.append(float(row["time_s"]))
            q_w.append(float(row["Q_GEN_W"]))
            t_c.append(float(row["T_feedback_degC"]))
    return np.array(t_s), np.array(q_w), np.array(t_c)


def compute_metrics(t_s: np.ndarray, q_w: np.ndarray, t_c: np.ndarray, val_t: np.ndarray, val_q: np.ndarray, val_tc: np.ndarray) -> dict[str, float]:
    q_ref = np.interp(t_s, val_t, val_q)
    t_ref = np.interp(t_s, val_t, val_tc)
    dq = q_w - q_ref
    dt = t_c - t_ref
    return {
        "t_end_s": float(t_s[-1]),
        "n_points": int(t_s.size),
        "temp_rmse_c": float(np.sqrt(np.mean(dt**2))),
        "temp_bias_c": float(np.mean(dt)),
        "temp_end_error_c": float(dt[-1]),
        "heat_rmse_w": float(np.sqrt(np.mean(dq**2))),
        "heat_bias_w": float(np.mean(dq)),
        "heat_end_error_w": float(dq[-1]),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Plot ECM summary against validation.")
    parser.add_argument("--summary-csv", required=True)
    parser.add_argument("--validation-csv", required=True)
    parser.add_argument("--out-dir", required=True)
    parser.add_argument("--run-label", required=True)
    parser.add_argument("--tmax", type=float, default=None)
    args = parser.parse_args()

    summary_csv = Path(args.summary_csv).resolve()
    validation_csv = Path(args.validation_csv).resolve()
    out_dir = Path(args.out_dir).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)

    t_s, q_w, t_c = load_summary(summary_csv)
    val_t, val_q, val_tc = load_validation(validation_csv)

    tmax = args.tmax
    if tmax is None:
        tmax = min(float(t_s[-1]), float(val_t[-1]))

    s_mask = t_s <= tmax + 1.0e-12
    v_mask = val_t <= tmax + 1.0e-12
    t_s = t_s[s_mask]
    q_w = q_w[s_mask]
    t_c = t_c[s_mask]
    val_t = val_t[v_mask]
    val_q = val_q[v_mask]
    val_tc = val_tc[v_mask]

    metrics = compute_metrics(t_s, q_w, t_c, val_t, val_q, val_tc)

    q_ref = np.interp(t_s, val_t, val_q)
    t_ref = np.interp(t_s, val_t, val_tc)
    dq = q_w - q_ref
    dt = t_c - t_ref

    plt.style.use("seaborn-v0_8-whitegrid")

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(t_s, t_c, color="#005f73", linewidth=1.8, label=f"{args.run_label} T feedback")
    ax.plot(val_t, val_tc, color="#bb3e03", linewidth=1.8, linestyle="--", label="Validation T cell")
    ax.set_title("ECM Feedback Temperature vs Validation")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Temperature [C]")
    ax.set_xlim(0.0, tmax)
    ax.legend(frameon=True)
    fig.tight_layout()
    fig.savefig(out_dir / "temperature_overlay.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(t_s, q_w, color="#0a9396", linewidth=1.8, label=f"{args.run_label} Q_GEN")
    ax.plot(val_t, val_q, color="#ee9b00", linewidth=1.8, linestyle="--", label="Validation Q cell")
    ax.set_title("ECM Heat vs Validation")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Heat [W]")
    ax.set_xlim(0.0, tmax)
    ax.legend(frameon=True)
    fig.tight_layout()
    fig.savefig(out_dir / "heat_overlay.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(t_s, dt, color="#005f73", linewidth=1.8, label="T feedback - Validation")
    ax.axhline(0.0, color="#111111", linewidth=1.0, linestyle="--", alpha=0.85)
    ax.set_title("Temperature Difference")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Temperature Difference [C]")
    ax.set_xlim(0.0, tmax)
    ax.legend(frameon=True)
    fig.tight_layout()
    fig.savefig(out_dir / "temperature_diff.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(t_s, dq, color="#0a9396", linewidth=1.8, label="Q_GEN - Validation")
    ax.axhline(0.0, color="#111111", linewidth=1.0, linestyle="--", alpha=0.85)
    ax.set_title("Heat Difference")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Heat Difference [W]")
    ax.set_xlim(0.0, tmax)
    ax.legend(frameon=True)
    fig.tight_layout()
    fig.savefig(out_dir / "heat_diff.png", dpi=180)
    plt.close(fig)

    payload = {
        "run_label": args.run_label,
        "summary_csv": str(summary_csv),
        "validation_csv": str(validation_csv),
        **metrics,
    }
    (out_dir / "metrics.json").write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()

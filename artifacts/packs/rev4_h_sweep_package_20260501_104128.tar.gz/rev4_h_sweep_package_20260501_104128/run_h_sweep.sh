#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT_DIR"

if [ -f /opt/openfoam/etc/bashrc ]; then
    set +e
    set +u
    source /opt/openfoam/etc/bashrc
    set -u
    set -e
fi

export PYTHONUNBUFFERED=1

BASE_CASE="${BASE_CASE:-$ROOT_DIR/rev4/caseLong}"
VALIDATION_CSV="${VALIDATION_CSV:-$ROOT_DIR/projectConstraintsParameters/validationData.csv}"
END_TIME="${END_TIME:-2000}"
WRITE_INTERVAL="${WRITE_INTERVAL:-3000}"
H_VALUES="${H_VALUES:-10 12.5 15 17.5 20 25}"
RUN_TAG="${RUN_TAG:-$(date -u +%Y%m%d_%H%M%S)}"
RUN_ROOT="${RUN_ROOT:-$ROOT_DIR/runs/h_sweep_${RUN_TAG}}"
BUILD_FIRST="${BUILD_FIRST:-1}"

mkdir -p "$RUN_ROOT"

if [ "$BUILD_FIRST" = "1" ]; then
    ./Allwmake
fi

python3 - <<'PY'
import importlib
mods = ["numpy", "matplotlib"]
missing = [m for m in mods if importlib.util.find_spec(m) is None]
if missing:
    raise SystemExit(
        "Missing Python modules: " + ", ".join(missing) +
        ". Install with: python3 -m pip install -r requirements.txt"
    )
PY

echo "Run root: $RUN_ROOT"
echo "H values : $H_VALUES"
echo "End time : $END_TIME"

for h in $H_VALUES; do
    label="${h//./p}"
    case_dir="$RUN_ROOT/case_h_${label}"
    python3 "$ROOT_DIR/scripts/prepare_h_case.py" \
        --base-case "$BASE_CASE" \
        --dest "$case_dir" \
        --h "$h" \
        --end-time "$END_TIME" \
        --write-interval "$WRITE_INTERVAL"

    (
        cd "$case_dir"
        ./Allrun
    )

    python3 "$ROOT_DIR/scripts/analyze_ecm_summary.py" \
        --summary-csv "$case_dir/ecm/ecm_wrapper_summary.csv" \
        --validation-csv "$VALIDATION_CSV" \
        --out-dir "$case_dir/analysis" \
        --run-label "h=$h" \
        --tmax "$END_TIME"
done

python3 "$ROOT_DIR/scripts/rank_h_sweep.py" \
    --runs-root "$RUN_ROOT" \
    --output-csv "$RUN_ROOT/sweep_metrics.csv" \
    --output-md "$RUN_ROOT/sweep_ranking.md"

echo "Sweep complete: $RUN_ROOT"

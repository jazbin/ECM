# rev4 Remote H Sweep Package

This package contains the source-only `rev4` ECM-coupled CHT setup, the active `caseLong` base case, validation data, and scripts for an outer-convection `h` sensitivity sweep.

## Contents

- `rev4/`
  - `src/` OpenFOAM source code
  - `python/` ECM wrapper and backend files
  - `caseLong/` clean base case for `0 -> 2000 s` runs
  - `baseReferenceValidation/` reference generator files
- `projectConstraintsParameters/validationData.csv`
- `run_h_sweep.sh`
- `scripts/`

## Remote Prerequisites

- OpenFOAM v2506 available and sourceable
- `python3`
- Python packages:
  - `python3 -m pip install -r requirements.txt`

## Build

```bash
cd <package-root>
./Allwmake
```

## Run The Default Sweep

```bash
cd <package-root>
./run_h_sweep.sh
```

Defaults:

- `h` values: `10 12.5 15 17.5 20 25`
- run window: `0 -> 2000 s`
- write interval: `3000 s`
- fixed heat split:
  - jelly-roll `0.966`
  - cap `0.033998`

The sweep clones `rev4/caseLong` into `runs/h_sweep_<timestamp>/case_h_*`, runs each case, and analyzes the clean ECM summary output.

## Useful Overrides

```bash
H_VALUES="14 16 18" END_TIME=2000 WRITE_INTERVAL=3000 ./run_h_sweep.sh
```

You can also change the destination:

```bash
RUN_ROOT=/path/to/output ./run_h_sweep.sh
```

## Outputs Per Run

Each cloned run writes:

- `ecm/ecm_wrapper_summary.csv`
  - clean per-step ECM feedback and heat summary
  - includes detailed ECM parameters such as `R0`, `R1`, `R2`, `C1`, `C2`, `V_OCV`, `Q_IR`, `Q_REV`, and state variables
- `analysis/temperature_overlay.png`
- `analysis/heat_overlay.png`
- `analysis/temperature_diff.png`
- `analysis/heat_diff.png`
- `analysis/metrics.json`

The sweep root also gets:

- `sweep_metrics.csv`
- `sweep_ranking.md`

## Notes

- This package is source-only. It does not include prebuilt `bin/` or `lib/`.
- The case is configured so it does not write intermediate time directories during the base long run.
- The ECM wrapper summary CSV is the preferred source for validation plots, not the raw solver log.

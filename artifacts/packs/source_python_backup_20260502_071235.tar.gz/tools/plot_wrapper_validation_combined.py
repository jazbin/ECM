#!/usr/bin/env python3
"""Generate combined wrapper-vs-validation comparison with auto fire-step detection.

This script infers ECM firing cadence from wrapper step_id sequence and uses only
firing steps for heat comparison/error, so skipped zeros are filtered while real
zero heat on actual firing steps is retained.
"""

from __future__ import annotations

import argparse
import re
from collections import Counter
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from matplotlib.ticker import ScalarFormatter


RESP_RE = re.compile(
    r'"step_id"\s*:\s*(\d+).*?"time_s"\s*:\s*([\deE+\-.]+).*?"Q_GEN_W"\s*:\s*([\deE+\-.]+).*?"T_jellyroll_degC"\s*:\s*([\deE+\-.]+)',
    re.S,
)


@dataclass
class FireCadence:
    every: int
    phase: int


def parse_wrapper(log_path: Path) -> pd.DataFrame:
    text = log_path.read_text(errors="ignore")
    rows = []
    for m in RESP_RE.finditer(text):
        rows.append(
            (
                int(m.group(1)),
                float(m.group(2)),
                float(m.group(3)),
                float(m.group(4)),
            )
        )
    if not rows:
        raise RuntimeError(f"No wrapper response rows parsed: {log_path}")
    return (
        pd.DataFrame(rows, columns=["step_id", "time_s", "q_gen_w", "T_degC"])
        .sort_values("step_id")
        .drop_duplicates("step_id")
    )


def infer_fire_cadence(wrap: pd.DataFrame) -> FireCadence:
    steps = wrap["step_id"].to_numpy(dtype=int)
    all_diffs = np.diff(steps)
    all_diffs = all_diffs[all_diffs > 0]
    base_inc = Counter(all_diffs.tolist()).most_common(1)[0][0] if all_diffs.size else 1
    base_inc = int(max(1, base_inc))

    nz = wrap[np.abs(wrap["q_gen_w"]) > 0.0]["step_id"].to_numpy(dtype=int)
    if nz.size >= 3:
        diffs = np.diff(nz)
        diffs = diffs[diffs > 0]
        if diffs.size:
            # Convert raw step_id delta to cadence in "response rows".
            cadence_rows = np.clip(np.rint(diffs / float(base_inc)).astype(int), 1, None)
            every = Counter(cadence_rows.tolist()).most_common(1)[0][0]
        else:
            every = 1
    else:
        every = 1
    every = int(max(1, every))

    step_rows = np.clip(np.rint(steps / float(base_inc)).astype(int), 0, None)
    if nz.size:
        nz_rows = np.clip(np.rint(nz / float(base_inc)).astype(int), 0, None)
        phase = Counter((nz_rows % every).tolist()).most_common(1)[0][0]
    else:
        phase = int(step_rows[0] % every)
    return FireCadence(every=every, phase=int(phase))


def load_validation(val_path: Path) -> pd.DataFrame:
    val = pd.read_csv(val_path)
    if "t_ss" not in val.columns or "Q_cell_W" not in val.columns:
        raise RuntimeError("validationFull.csv must include t_ss and Q_cell_W")
    val = val.copy()
    val["time_sim_s"] = val["t_ss"] - 11.0
    if "T_cell_K" in val.columns:
        val["T_K"] = val["T_cell_K"]
    elif "T_cell_degC" in val.columns:
        val["T_K"] = val["T_cell_degC"] + 273.15
    else:
        raise RuntimeError("validationFull.csv must include T_cell_degC or T_cell_K")
    return val


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wrapper-log", default="/workspace/in/ecm_wrapper_diagnostic.log")
    parser.add_argument("--validation-csv", default="/workspace/in/validationFull.csv")
    parser.add_argument("--out-dir", default="/workspace/artifacts/plots")
    parser.add_argument("--latest-name", default="combined_normal_relative_comparison_latest.pdf")
    parser.add_argument(
        "--summary-latest-name", default="combined_normal_relative_summary_latest.csv"
    )
    parser.add_argument(
        "--rel-denom-eps",
        type=float,
        default=1e-6,
        help="Absolute floor for relative-error denominator.",
    )
    parser.add_argument(
        "--heat-rel-max-pct",
        type=float,
        default=25.0,
        help="Drop heat relative-error points with abs(error) above this threshold.",
    )
    args = parser.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    wrap = parse_wrapper(Path(args.wrapper_log))
    fire = infer_fire_cadence(wrap)
    step_diffs = np.diff(wrap["step_id"].to_numpy(dtype=int))
    step_diffs = step_diffs[step_diffs > 0]
    base_inc = Counter(step_diffs.tolist()).most_common(1)[0][0] if step_diffs.size else 1
    step_rows = np.clip(
        np.rint(wrap["step_id"].to_numpy(dtype=float) / float(max(1, base_inc))).astype(int),
        0,
        None,
    )
    wrap_heat = wrap[(step_rows % fire.every) == fire.phase].copy()
    wrap_heat = wrap_heat.sort_values("time_s")

    val = load_validation(Path(args.validation_csv))

    tmin = max(0.0, float(wrap["time_s"].min()))
    tmax = float(wrap["time_s"].max())
    val_clip = val[(val["time_sim_s"] >= tmin) & (val["time_sim_s"] <= tmax)].copy()
    if val_clip.empty:
        raise RuntimeError("No overlap between wrapper and validation after time alignment")
    val_clip = val_clip.sort_values("time_sim_s")

    w_t = wrap["time_s"].to_numpy()
    v_t = val_clip["time_sim_s"].to_numpy()
    v_T_interp = np.interp(w_t, v_t, val_clip["T_K"].to_numpy())
    w_T = wrap["T_degC"].to_numpy() + 273.15

    wh_t = wrap_heat["time_s"].to_numpy()
    wh_q = wrap_heat["q_gen_w"].to_numpy()
    vq_fire = np.interp(wh_t, v_t, val_clip["Q_cell_W"].to_numpy())

    # Symmetric denominator avoids blow-ups when either side is near zero.
    den_q = np.maximum.reduce([np.abs(vq_fire), np.abs(wh_q), np.full_like(wh_q, args.rel_denom_eps)])
    heat_rel_pct = 100.0 * (wh_q - vq_fire) / den_q
    heat_abs_pct = np.abs(heat_rel_pct)
    heat_keep = heat_abs_pct <= float(args.heat_rel_max_pct)
    wh_t_keep = wh_t[heat_keep]
    wh_q_keep = wh_q[heat_keep]
    heat_rel_keep = heat_rel_pct[heat_keep]
    heat_abs_keep = heat_abs_pct[heat_keep]

    den_T = np.maximum(np.abs(v_T_interp), args.rel_denom_eps)
    temp_rel_pct = 100.0 * (w_T - v_T_interp) / den_T
    temp_abs_pct = np.abs(temp_rel_pct)

    sns.set_theme(style="whitegrid", context="talk")
    fig, axs = plt.subplots(2, 2, figsize=(15, 10), sharex="col")

    ax = axs[0, 0]
    ax.scatter(
        val_clip["time_sim_s"],
        val_clip["Q_cell_W"],
        s=88,
        marker="x",
        c="#d62728",
        linewidths=2.2,
        label="Validation heat",
        zorder=2,
    )
    ax.scatter(
        wh_t_keep,
        wh_q_keep,
        s=120,
        marker="o",
        facecolors="none",
        edgecolors="#0057b8",
        linewidths=2.4,
        label=f"Wrapper heat (fire steps, |rel err|<={args.heat_rel_max_pct:.0f}%)",
        zorder=4,
    )
    ax.set_ylabel("Heat [W]")
    ax.set_title("Heat Comparison")
    ax.legend(frameon=False, loc="best")
    fh = ScalarFormatter(useOffset=False)
    fh.set_scientific(False)
    ax.yaxis.set_major_formatter(fh)

    ax = axs[0, 1]
    ax.scatter(wrap["time_s"], wrap["T_degC"] + 273.15, s=20, marker="s", c="#2ca02c", label="Wrapper T")
    ax.scatter(
        val_clip["time_sim_s"],
        val_clip["T_K"],
        s=24,
        marker="^",
        c="#ff7f0e",
        label="Validation T",
    )
    ax.set_ylabel("Temperature [K]")
    ax.set_title("Temperature Comparison")
    ax.legend(frameon=False, loc="best")
    ft = ScalarFormatter(useOffset=False)
    ft.set_scientific(False)
    ax.yaxis.set_major_formatter(ft)

    ax = axs[1, 0]
    ax.plot(
        wh_t_keep,
        heat_rel_keep,
        linestyle="-",
        linewidth=1.1,
        color="#d62728",
        alpha=0.7,
        label="Relative error [%]",
    )
    ax.set_xlabel("Simulation Time [s]")
    ax.set_ylabel("Heat Relative Error [%]")
    ax.set_title("Heat Relative Error (fire-step filtered)")
    ax.legend(frameon=False, loc="best")
    fe = ScalarFormatter(useOffset=False)
    fe.set_scientific(False)
    ax.yaxis.set_major_formatter(fe)

    ax = axs[1, 1]
    ax.plot(
        w_t,
        temp_rel_pct,
        linestyle="-",
        linewidth=1.0,
        color="#ff7f0e",
        alpha=0.7,
        label="Relative error [%]",
    )
    ax.set_xlabel("Simulation Time [s]")
    ax.set_ylabel("Temperature Relative Error [%] (K-based)")
    ax.set_title("Temperature Relative Error")
    ax.legend(frameon=False, loc="best")
    ft2 = ScalarFormatter(useOffset=False)
    ft2.set_scientific(False)
    ax.yaxis.set_major_formatter(ft2)

    for a in axs.ravel():
        a.grid(True, alpha=0.25)
        fx = ScalarFormatter(useOffset=False)
        fx.set_scientific(False)
        a.xaxis.set_major_formatter(fx)

    fig.suptitle(
        "Wrapper vs Validation: Normal and Relative Comparison (t_sim = t_ss - 11)",
        y=0.99,
    )
    fig.tight_layout()

    stamp = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
    out_pdf = out_dir / f"combined_normal_relative_comparison_fireFiltered_{stamp}.pdf"
    fig.savefig(out_pdf)

    latest_pdf = out_dir / args.latest_name
    latest_pdf.write_bytes(out_pdf.read_bytes())

    summary = {
        "fire_every_steps_inferred": int(fire.every),
        "fire_phase_inferred": int(fire.phase),
        "n_wrapper_points": int(len(wrap)),
        "n_wrapper_fire_points": int(len(wrap_heat)),
        "n_wrapper_fire_zero_q": int((np.abs(wrap_heat["q_gen_w"].to_numpy()) == 0.0).sum()),
        "heat_rel_max_pct_filter": float(args.heat_rel_max_pct),
        "n_heat_points_kept": int(heat_keep.sum()),
        "n_heat_points_dropped": int((~heat_keep).sum()),
        "heat_abs_pct_mean": float(np.mean(heat_abs_keep)) if heat_abs_keep.size else np.nan,
        "heat_abs_pct_p95": float(np.percentile(heat_abs_keep, 95)) if heat_abs_keep.size else np.nan,
        "temp_abs_pct_mean": float(np.mean(temp_abs_pct)),
        "temp_abs_pct_p95": float(np.percentile(temp_abs_pct, 95)),
    }
    summary_csv = out_dir / f"combined_normal_relative_summary_fireFiltered_{stamp}.csv"
    pd.DataFrame([summary]).to_csv(summary_csv, index=False)

    latest_sum = out_dir / args.summary_latest_name
    latest_sum.write_bytes(summary_csv.read_bytes())

    print(out_pdf)
    print(latest_pdf)
    print(summary_csv)
    print(summary)


if __name__ == "__main__":
    main()

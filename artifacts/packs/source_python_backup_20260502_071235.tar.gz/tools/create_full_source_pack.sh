#!/bin/bash
set -euo pipefail

repo_root="$(cd "$(dirname "$0")/.." && pwd)"
stamp="$(date -u +%Y%m%d_%H%M%S)"
pkg_name="openfoam-ecm-fullsource_${stamp}"
out_root="$repo_root/artifacts/packs"
pkg_root="$out_root/$pkg_name"

mkdir -p "$out_root"
rm -rf "$pkg_root"
mkdir -p "$pkg_root"

copy_file() {
  local src="$1"
  local dst="$pkg_root/$1"
  mkdir -p "$(dirname "$dst")"
  cp -a "$repo_root/$src" "$dst"
}

copy_dir() {
  local src="$1"
  mkdir -p "$(dirname "$pkg_root/$src")"
  cp -a "$repo_root/$src" "$pkg_root/$src"
}

# Build and runtime entry points
copy_file "Allwmake"
copy_file "build_portable.sh"
copy_file "README.md"
copy_file "PORTABLE_PACKAGE_README.md"
copy_file "LICENSE"

# Root ECM input tables
copy_file "cellprops.csv"
copy_file "params.csv"

# Full source and helpers
copy_dir "src"
# runtime ECM state directories are case-local; Python runtime lives in python/
copy_dir "python"
copy_dir "tools"
copy_dir "docs"
copy_dir "geometry"
copy_dir "deploy/lumped_nca_standalone"

# Include the active validation case from the reported run.
copy_dir "cases/validation_lumped_paramset_21p09x70p02"

# Drop machine-specific and transient outputs.
find "$pkg_root" -type d \( -name __pycache__ -o -name .git \) -prune -exec rm -rf {} +
find "$pkg_root/src" -type d -path '*/Make/linux*' -prune -exec rm -rf {} +
find "$pkg_root/src" -type f \( -name '*.o' -o -name '*.dep' \) -delete
find "$pkg_root/src" -type d -name lnInclude -prune -exec rm -rf {} +

case_dir="$pkg_root/cases/validation_lumped_paramset_21p09x70p02"
rm -rf "$case_dir/postProcessing" "$case_dir/VTK" "$case_dir/dynamicCode"
find "$case_dir" -maxdepth 1 -type d -name 'processor*' -exec rm -rf {} +
find "$case_dir" -maxdepth 1 -type f -name 'log.*' -delete
find "$case_dir/ecm" -maxdepth 1 -type f \
  \( -name 'ecm_state.json' -o -name 'ecm_last_good.bin' -o -name 'ecm_in.*' -o -name 'ecm_out.*' -o -name 'ecm_daemon.pid' -o -name 'ecm_daemon.sock' -o -name 'ecm_wrapper_diagnostic.log' \) \
  -delete || true
find "$case_dir/ecm" -maxdepth 1 -type s -delete || true

tarball="$out_root/${pkg_name}.tar.gz"
tar -czf "$tarball" -C "$out_root" "$pkg_name"

printf '%s\n%s\n' "$pkg_root" "$tarball"

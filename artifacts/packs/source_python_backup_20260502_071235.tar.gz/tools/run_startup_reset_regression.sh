#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CASE_DIR="${ROOT_DIR}/cases/validation_lumped_startup_regression"
LOG_DIR="${ROOT_DIR}/artifacts/logs"
STAMP="$(date -u +%Y%m%d_%H%M%S)"
LOG_FILE="${LOG_DIR}/startup_reset_regression_${STAMP}.log"

mkdir -p "${LOG_DIR}"

if [[ ! -d "${CASE_DIR}" ]]; then
    echo "Case not found: ${CASE_DIR}" >&2
    exit 1
fi

(
    cd "${CASE_DIR}"
    # Recreate stale-start condition for every run:
    # - latest time must be exactly 50 (not previously written continuation times)
    # - no exact restart checkpoint for time 50
    find . -maxdepth 1 -type d -regextype posix-extended -regex './[0-9]+(\.[0-9]+)?' \
        ! -name "0" ! -name "50" -exec rm -rf {} +
    rm -rf ecm/restartCheckpoints
    rm -f log.startup_regression
    chtMultiRegionSolidFoam > log.startup_regression 2>&1
)

cp "${CASE_DIR}/log.startup_regression" "${LOG_FILE}"

python3 - "${LOG_FILE}" <<'PY'
import re
import sys
from pathlib import Path

log_path = Path(sys.argv[1])
text = log_path.read_text()

if "Reset ecmQdot across the region to zero (no exact restart checkpoint)." not in text:
    raise SystemExit("FAIL: startup reset message not found")

match = re.search(
    r"Time =\s*50\.003125.*?EnergyDebug region jellyRoll time 50\.003125 .*?sourceSum ([^ ]+).*?Min/max T:([0-9eE+.\-]+) ([0-9eE+.\-]+)",
    text,
    re.S,
)
if not match:
    raise SystemExit("FAIL: could not parse first-step jellyRoll diagnostics")

source_sum = float(match.group(1))
t_min = float(match.group(2))
t_max = float(match.group(3))

if abs(source_sum) > 1e-9:
    raise SystemExit(f"FAIL: first-step sourceSum expected ~0, got {source_sum}")

if t_min < 297.0 or t_max > 299.0:
    raise SystemExit(f"FAIL: first-step T bounds unexpected: min={t_min}, max={t_max}")

print("PASS: startup reset regression check")
print(f"  sourceSum={source_sum}")
print(f"  minT={t_min}")
print(f"  maxT={t_max}")
PY

echo "log: ${LOG_FILE}"

#!/usr/bin/env python3
"""
Analytical sanity checks relating validation thermal behavior to boundary resistance.

This script is intentionally simple and self-contained:
- Reads caseSettings/validationData.csv
- Computes effective resistance R_eff(t) = (T - T_amb)/Q during discharge
- Computes what external h would be if R_eff were purely convective
- Computes an upper-bound temperature rise for a solid cylinder with a perfect
  fixed-temperature wall (Dirichlet) under uniform volumetric heating:
    dT_max = Q/(4*pi*k_rr*L)

Outputs a short Markdown report (and optional plots if matplotlib is available).
"""

from __future__ import annotations

import datetime as _dt
import math
from pathlib import Path

import numpy as np
import pandas as pd


def _now_tag() -> str:
    return _dt.datetime.now(_dt.timezone.utc).strftime("%Y%m%d_%H%M%S")


def main() -> int:
    repo = Path("/workspace")
    validation_csv = repo / "caseSettings" / "validationData.csv"
    if not validation_csv.is_file():
        raise FileNotFoundError(str(validation_csv))

    # Reference geometry/thermal values (must match docs/WEDGE_2170_BATTERY_CELL_THERMAL_PROPERTIES_REFERENCE.md)
    R_cell_m = 0.010545
    h_cell_m = 0.07002
    h_jroll_m = 0.06511
    t_can_m = 0.00023132
    krr_jroll_W_mK = 1.4
    k_can_W_mK = 16.0
    Rtherm_jroll_base_K_W = 0.0018
    Tamb_K = 298.15

    # External surface area of the cell (cylinder side + both ends)
    A_side = 2.0 * math.pi * R_cell_m * h_cell_m
    A_ends = 2.0 * math.pi * R_cell_m * R_cell_m
    A_tot = A_side + A_ends

    df = pd.read_csv(validation_csv)
    required_cols = {"t_ss", "load", "Q_cell_W", "T_cell_K"}
    missing = sorted(required_cols - set(df.columns))
    if missing:
        raise ValueError(f"validationData.csv missing columns: {missing}")

    # Focus on discharge segments where Q>0 and load<0 (sign convention in this dataset).
    mask = (df["load"] < 0) & (df["Q_cell_W"] > 1e-9) & (df["T_cell_K"] > 0)
    dfd = df.loc[mask, ["t_ss", "load", "Q_cell_W", "T_cell_K"]].copy()
    dfd["dT_K"] = dfd["T_cell_K"] - Tamb_K
    dfd["R_eff_K_W"] = dfd["dT_K"] / dfd["Q_cell_W"]
    dfd = dfd.replace([np.inf, -np.inf], np.nan).dropna()

    # Key timepoint (matches the user's discussion around ~1719 s)
    t_query = 1719.0
    idx = (dfd["t_ss"] - t_query).abs().idxmin()
    row_1719 = dfd.loc[idx]

    # Peak Q in discharge window
    i_maxq = dfd["Q_cell_W"].idxmax()
    row_maxq = dfd.loc[i_maxq]

    # Cooling-based effective resistance:
    # When load -> 0 and Q -> 0, dynamics approximately follow:
    #   C * dT/dt = -(T - Tamb)/R_eff
    # => R_eff = (T - Tamb)/(C * |dT/dt|)
    #
    # Use Cp_cell_J_K-1 from caseSettings/cellprops.csv (if present),
    # otherwise fall back to a conservative estimate from geometry/materials.
    Cp_cell_J_K = None
    cellprops_csv = repo / "caseSettings" / "cellprops.csv"
    if cellprops_csv.is_file():
        try:
            cpdf = pd.read_csv(cellprops_csv)
            if "Cp_cell_J_K-1" in cpdf.columns:
                Cp_cell_J_K = float(cpdf["Cp_cell_J_K-1"].iloc[0])
        except Exception:
            Cp_cell_J_K = None

    if Cp_cell_J_K is None:
        # Fallback: approximate jelly-roll capacity only
        R_jroll_m = R_cell_m - t_can_m
        V_jroll = math.pi * R_jroll_m * R_jroll_m * h_jroll_m
        rho_jroll = 2660.7
        Cp_jroll = 980.0
        Cp_cell_J_K = V_jroll * rho_jroll * Cp_jroll

    # Identify the final long zero-load segment (typically cooldown to end)
    late = df[df["t_ss"] > 3000].copy().reset_index(drop=True)
    load = late["load"].to_numpy()
    z = np.where(load == 0)[0]
    cool_row = None
    cool_slope = None
    if len(z):
        # contiguous runs
        runs = []
        start = int(z[0])
        prev = int(z[0])
        for i in map(int, z[1:]):
            if i == prev + 1:
                prev = i
            else:
                runs.append((start, prev))
                start = prev = i
        runs.append((start, prev))
        # pick last run with length >= 20
        cand = [r for r in runs if (r[1] - r[0] + 1) >= 20]
        if cand:
            s, e = cand[-1]
            seg = late.iloc[s : e + 1].copy()
            t0 = float(seg["t_ss"].iloc[0])
            # fit slope over first 30 seconds (or full segment if shorter)
            t_end = t0 + min(30.0, float(seg["t_ss"].iloc[-1] - t0))
            w = seg[seg["t_ss"] <= t_end]
            m, b = np.polyfit(w["t_ss"].to_numpy(), w["T_cell_K"].to_numpy(), 1)
            cool_slope = float(m)
            cool_row = {
                "t0_s": t0,
                "t1_s": float(w["t_ss"].iloc[-1]),
                "T0_K": float(seg["T_cell_K"].iloc[0]),
                "dT0_K": float(seg["T_cell_K"].iloc[0] - Tamb_K),
                "dTdt_K_s": cool_slope,
            }

    # If the entire effective resistance were purely external convection:
    #   R_ext = 1/(h*A) => h = 1/(R_ext*A)
    h_eff_1719 = 1.0 / (row_1719["R_eff_K_W"] * A_tot)
    h_eff_maxq = 1.0 / (row_maxq["R_eff_K_W"] * A_tot)

    # Dirichlet-wall bounds for uniform volumetric heating in a cylinder:
    #   dT_max = Q / (4*pi*k*L)   (centerline max above wall)
    #   dT_avg = Q / (8*pi*k*L)   (volume-average above wall)
    dTmax_bound_1719 = row_1719["Q_cell_W"] / (4.0 * math.pi * krr_jroll_W_mK * h_jroll_m)
    dTmax_bound_maxq = row_maxq["Q_cell_W"] / (4.0 * math.pi * krr_jroll_W_mK * h_jroll_m)
    dTavg_bound_1719 = row_1719["Q_cell_W"] / (8.0 * math.pi * krr_jroll_W_mK * h_jroll_m)
    dTavg_bound_maxq = row_maxq["Q_cell_W"] / (8.0 * math.pi * krr_jroll_W_mK * h_jroll_m)

    # Required krr for the Dirichlet bounds to allow the observed dT.
    # (i.e. make dTavg_bound == observed dT or dTmax_bound == observed dT)
    krr_req_max_1719 = row_1719["Q_cell_W"] / (4.0 * math.pi * h_jroll_m * row_1719["dT_K"])
    krr_req_max_maxq = row_maxq["Q_cell_W"] / (4.0 * math.pi * h_jroll_m * row_maxq["dT_K"])
    krr_req_avg_1719 = row_1719["Q_cell_W"] / (8.0 * math.pi * h_jroll_m * row_1719["dT_K"])
    krr_req_avg_maxq = row_maxq["Q_cell_W"] / (8.0 * math.pi * h_jroll_m * row_maxq["dT_K"])

    # Thin can conduction resistance estimate (radial) if heat rejected over the side area:
    #   R_can ~ t/(k*A_side)
    R_can_side = t_can_m / (k_can_W_mK * A_side)

    tag = _now_tag()
    out_dir = repo / "artifacts" / "reports"
    out_dir.mkdir(parents=True, exist_ok=True)
    md_path = out_dir / f"validation_bc_sanity_check_{tag}.md"

    def f(x: float) -> str:
        return f"{x:.6g}"

    md = []
    md.append("# Validation Thermal BC Sanity Check\n")
    md.append(f"- Input: `{validation_csv}`\n")
    md.append(f"- Assumed ambient: `Tamb = {Tamb_K} K`\n")
    md.append("\n## Geometry\n")
    md.append(f"- `R_cell = {R_cell_m} m`, `h_cell = {h_cell_m} m`\n")
    md.append(f"- External area: `A_side = {f(A_side)} m^2`, `A_ends = {f(A_ends)} m^2`, `A_tot = {f(A_tot)} m^2`\n")
    md.append("\n## Effective Resistance From Validation (Direct From CSV)\n")
    md.append("Defined as `R_eff(t) = (T_cell_K - Tamb)/Q_cell_W` during discharge (`load<0`, `Q>0`).\n\n")
    md.append(f"- Near `t≈{t_query} s`: `t={f(row_1719['t_ss'])} s`, `Q={f(row_1719['Q_cell_W'])} W`, `T={f(row_1719['T_cell_K'])} K`, `ΔT={f(row_1719['dT_K'])} K`, `R_eff={f(row_1719['R_eff_K_W'])} K/W`\n")
    md.append(f"- At max discharge `Q`: `t={f(row_maxq['t_ss'])} s`, `Q={f(row_maxq['Q_cell_W'])} W`, `T={f(row_maxq['T_cell_K'])} K`, `ΔT={f(row_maxq['dT_K'])} K`, `R_eff={f(row_maxq['R_eff_K_W'])} K/W`\n")
    md.append("\n## What h Would Be If R_eff Were Purely External Convection\n")
    md.append("Using `h = 1/(R_eff * A_tot)`.\n\n")
    md.append(f"- At `t≈{t_query} s`: `h_eff ≈ {f(h_eff_1719)} W/m^2/K`\n")
    md.append(f"- At max `Q`: `h_eff ≈ {f(h_eff_maxq)} W/m^2/K`\n")

    md.append("\n## Cooling-Rate Resistance Check (Model-Light)\n")
    md.append("When `load→0` and `Q_cell_W≈0`, the cooling segment can be used to estimate `R_eff` from the slope:\n\n")
    md.append("`R_eff = (T - Tamb)/(C_cell · |dT/dt|)`\n\n")
    md.append(f"- Using `C_cell = {f(Cp_cell_J_K)} J/K` (from `caseSettings/cellprops.csv` when available)\n")
    if cool_row is not None and cool_slope is not None:
        R_eff_cool = cool_row["dT0_K"] / (Cp_cell_J_K * abs(cool_row["dTdt_K_s"]))
        md.append(
            f"- Cooldown segment (last long zero-load run): `t=[{f(cool_row['t0_s'])}, {f(cool_row['t1_s'])}] s`, "
            f"`T0={f(cool_row['T0_K'])} K`, `ΔT0={f(cool_row['dT0_K'])} K`, `dT/dt≈{f(cool_row['dTdt_K_s'])} K/s` "
            f"→ `R_eff_cool≈{f(R_eff_cool)} K/W`\n"
        )
    else:
        md.append("- Could not locate a long `load==0` cooldown segment after `t>3000 s`.\n")
    md.append("\n## Dirichlet-Wall Upper Bound Check (Perfect Fixed Wall Temperature)\n")
    md.append("If the outer wall were a perfect fixed temperature sink and the jelly-roll were a solid cylinder with constant radial conductivity `krr`, uniform volumetric heating implies:\n\n")
    md.append("- Centerline maximum rise: `ΔT_max = Q/(4π krr L)`\n")
    md.append("- Volume-average rise: `ΔT_avg = Q/(8π krr L)`\n")
    md.append("where `L=h_jroll`.\n\n")
    md.append(f"- Using `krr_jroll={krr_jroll_W_mK} W/m/K`, `L={h_jroll_m} m`:\n")
    md.append(f"  - At `t≈{t_query} s`: `ΔT_max_bound ≈ {f(dTmax_bound_1719)} K`, `ΔT_avg_bound ≈ {f(dTavg_bound_1719)} K` vs observed `ΔT ≈ {f(row_1719['dT_K'])} K`\n")
    md.append(f"  - At max `Q`: `ΔT_max_bound ≈ {f(dTmax_bound_maxq)} K`, `ΔT_avg_bound ≈ {f(dTavg_bound_maxq)} K` vs observed `ΔT ≈ {f(row_maxq['dT_K'])} K`\n")
    md.append("\nEquivalent required `krr` for the bound to allow the observed `ΔT`:\n\n")
    md.append(f"- For `ΔT_max` to match observed:\n")
    md.append(f"  - At `t≈{t_query} s`: `krr_required_max ≈ {f(krr_req_max_1719)} W/m/K`\n")
    md.append(f"  - At max `Q`: `krr_required_max ≈ {f(krr_req_max_maxq)} W/m/K`\n")
    md.append(f"- For `ΔT_avg` to match observed (this is the relevant comparison if `T_cell_K` is a jelly-roll average):\n")
    md.append(f"  - At `t≈{t_query} s`: `krr_required_avg ≈ {f(krr_req_avg_1719)} W/m/K`\n")
    md.append(f"  - At max `Q`: `krr_required_avg ≈ {f(krr_req_avg_maxq)} W/m/K`\n")
    md.append("\n## Small-Resistance Sanity Checks\n")
    md.append(f"- Can side conduction (thin wall) estimate: `R_can_side ≈ t_can/(k_can*A_side) ≈ {f(R_can_side)} K/W`\n")
    md.append(f"- Base contact resistance (if applied as given): `Rtherm_jroll_base = {Rtherm_jroll_base_K_W} K/W` (at `Q=10 W` gives `ΔT≈0.018 K`)\n")
    md.append("\n## Interpretation\n")
    md.append("- The validation CSV itself implies a finite effective thermal resistance to ambient of ~`1.85–1.95 K/W` during high-load discharge.\n")
    md.append("- A perfect fixed-temperature outer wall is not automatically incompatible, but matching `ΔT≈12–21 K` with the provided `krr_jroll=1.4 W/m/K` is difficult: the Dirichlet-cylinder upper bound predicts substantially smaller `ΔT` at the same `Q`.\n")
    md.append("- Reconciling the validation rise likely requires one (or more) of:\n")
    md.append("  - a finite external convection resistance (h on outer wall),\n")
    md.append("  - a different temperature definition (`T_cell` representing a core sensor),\n")
    md.append("  - different effective radial conductivity/contact resistances than the values used in CFD.\n")

    md_path.write_text("".join(md), encoding="utf-8")

    # Optional plots
    try:
        import matplotlib.pyplot as plt  # type: ignore
    except Exception:
        return 0

    png_path = out_dir / f"validation_bc_sanity_check_{tag}.png"

    fig, ax1 = plt.subplots(figsize=(10, 5))
    ax1.plot(dfd["t_ss"], dfd["T_cell_K"], label="T_cell_K [K]", color="tab:red", linewidth=1.0)
    ax1.set_xlabel("t [s]")
    ax1.set_ylabel("T_cell_K [K]", color="tab:red")
    ax1.tick_params(axis="y", labelcolor="tab:red")
    ax1.grid(True, alpha=0.25)

    ax2 = ax1.twinx()
    ax2.plot(dfd["t_ss"], dfd["Q_cell_W"], label="Q_cell_W [W]", color="tab:blue", linewidth=1.0, alpha=0.85)
    ax2.set_ylabel("Q_cell_W [W]", color="tab:blue")
    ax2.tick_params(axis="y", labelcolor="tab:blue")

    fig.suptitle("Validation Discharge: T and Q")
    fig.tight_layout()
    fig.savefig(png_path, dpi=180)
    plt.close(fig)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

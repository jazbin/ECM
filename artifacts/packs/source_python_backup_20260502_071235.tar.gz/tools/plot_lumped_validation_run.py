#!/usr/bin/env python3
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def load_single_probe(path: Path) -> tuple[np.ndarray, np.ndarray]:
    rows = []
    with path.open() as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            rows.append((float(parts[0]), float(parts[1])))
    data = np.array(rows, dtype=float)
    return data[:, 0], data[:, 1]


def load_multi_probe(path: Path) -> tuple[np.ndarray, np.ndarray]:
    rows = []
    with path.open() as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            rows.append([float(x) for x in parts])
    data = np.array(rows, dtype=float)
    return data[:, 0], data[:, 1:]


def load_vol_average(path: Path) -> tuple[np.ndarray, np.ndarray]:
    rows = []
    with path.open() as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            rows.append((float(parts[0]), float(parts[1])))
    data = np.array(rows, dtype=float)
    return data[:, 0], data[:, 1]


def celsius(kelvin: np.ndarray) -> np.ndarray:
    return kelvin - 273.15


def main() -> None:
    parser = argparse.ArgumentParser(description="Plot lumpedValidation run histories.")
    parser.add_argument(
        "--case",
        default="/workspace/in/latest/lumpedValidation",
        help="Case directory containing postProcessing/",
    )
    parser.add_argument(
        "--stamp",
        default="20260430_081128",
        help="Output stamp for plot names.",
    )
    args = parser.parse_args()

    case_dir = Path(args.case).resolve()
    out_dir = Path("/workspace/artifacts/plots")
    out_dir.mkdir(parents=True, exist_ok=True)

    probe_t1 = case_dir / "postProcessing/probeT1/shell_rotated/0/T"
    probe_t6 = case_dir / "postProcessing/probeT6/cap_rotated/0/T"
    probe_mid = case_dir / "postProcessing/probeLocations/jellyRoll_rotated/0/T"
    mean_t = case_dir / "postProcessing/jellyRoll_rotated/jellyRollMeanT/0/volFieldValue_0.dat"

    t1_time, t1_vals = load_single_probe(probe_t1)
    t6_time, t6_vals = load_single_probe(probe_t6)
    mid_time, mid_vals = load_multi_probe(probe_mid)
    mean_time, mean_vals = load_vol_average(mean_t)

    probe_data = {
        "T1": celsius(t1_vals),
        "T2": celsius(mid_vals[:, 0]),
        "T3": celsius(mid_vals[:, 1]),
        "T4": celsius(mid_vals[:, 2]),
        "T5": celsius(mid_vals[:, 3]),
        "T6": celsius(t6_vals),
    }

    plt.style.use("seaborn-v0_8-whitegrid")

    fig, ax = plt.subplots(figsize=(11, 6))
    colors = ["#1b3a4b", "#c1121f", "#669bbc", "#f77f00", "#2a9d8f", "#6a4c93"]
    for (label, series), color in zip(probe_data.items(), colors):
        ax.plot(t1_time, series, label=label, linewidth=1.6, color=color)
    ax.set_title("lumpedValidation Validation-CSV Run: T1-T6")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Temperature [C]")
    ax.legend(ncol=3, frameon=True)
    ax.set_xlim(t1_time.min(), t1_time.max())
    fig.tight_layout()
    probes_png = out_dir / f"lumpedValidation_validation_csv_probes_{args.stamp}.png"
    fig.savefig(probes_png, dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5))
    for (label, series), color in zip(probe_data.items(), colors):
        ax.plot(t1_time, series - series[0], label=label, linewidth=1.6, color=color)
    ax.set_title("lumpedValidation Validation-CSV Run: Probe Rise Above Initial")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Delta T [C]")
    ax.legend(ncol=3, frameon=True)
    ax.set_xlim(t1_time.min(), t1_time.max())
    fig.tight_layout()
    rise_png = out_dir / f"lumpedValidation_validation_csv_deltaT_{args.stamp}.png"
    fig.savefig(rise_png, dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5))
    ax.plot(mean_time, celsius(mean_vals), linewidth=1.8, color="#003049", label="jellyRollMeanT")
    ax.set_title("lumpedValidation Validation-CSV Run: Jelly-Roll Mean Temperature")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Temperature [C]")
    ax.legend(frameon=True)
    ax.set_xlim(mean_time.min(), mean_time.max())
    fig.tight_layout()
    mean_png = out_dir / f"lumpedValidation_validation_csv_jellyRollMeanT_{args.stamp}.png"
    fig.savefig(mean_png, dpi=180)
    plt.close(fig)

    print(probes_png)
    print(rise_png)
    print(mean_png)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3

from __future__ import annotations

import csv
import math
import re
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages


T0_K = 298.15
BETA_K_PER_S = 0.065

FIELD_MAP = {
    "jellyRollMeanT": "jellyRoll_rotated",
    "shellMeanT": "shell_rotated",
    "capMeanT": "cap_rotated",
}

TIME_RE = re.compile(r"^Time = ([0-9.eE+-]+)$")
WRITE_RE = re.compile(r"^volFieldValue (\w+) write:$")
VALUE_RE = re.compile(r"volAverage\([^)]+\) of T = ([0-9.eE+-]+)")


def parse_mean_writes(log_path: Path, dt_label: str) -> pd.DataFrame:
    current_time = None
    pending_field = None
    records: dict[float, dict[str, float]] = {}

    with log_path.open() as handle:
        for raw_line in handle:
            line = raw_line.strip()

            time_match = TIME_RE.match(line)
            if time_match:
                current_time = float(time_match.group(1))
                continue

            write_match = WRITE_RE.match(line)
            if write_match:
                pending_field = write_match.group(1)
                continue

            if pending_field is None or current_time is None:
                continue

            value_match = VALUE_RE.search(line)
            if value_match and pending_field in FIELD_MAP:
                region = FIELD_MAP[pending_field]
                records.setdefault(current_time, {})[region] = float(value_match.group(1))
            pending_field = None

    rows = []
    for time_s in sorted(records):
        row = {"dt": dt_label, "time_s": time_s, "theory_K": T0_K + BETA_K_PER_S*time_s}
        row.update(records[time_s])
        rows.append(row)

    df = pd.DataFrame(rows)
    if df.empty:
        raise RuntimeError(f"No write-time means parsed from {log_path}")
    return df


def build_summary(data: pd.DataFrame) -> pd.DataFrame:
    final = data.sort_values("time_s").groupby("dt", as_index=False).tail(1).copy()
    for region in FIELD_MAP.values():
        final[f"{region}_err_K"] = final[region] - final["theory_K"]
    return final.sort_values("dt", key=lambda s: s.astype(float), ascending=False)


def write_csv(data: pd.DataFrame, summary: pd.DataFrame, out_dir: Path) -> tuple[Path, Path]:
    series_csv = out_dir / "wedge2170_exact_timestep_series.csv"
    summary_csv = out_dir / "wedge2170_exact_timestep_summary.csv"
    data.to_csv(series_csv, index=False, quoting=csv.QUOTE_MINIMAL)
    summary.to_csv(summary_csv, index=False, quoting=csv.QUOTE_MINIMAL)
    return series_csv, summary_csv


def add_summary_page(pdf: PdfPages, summary: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(11, 8.5))
    ax.axis("off")

    lines = [
        "wedge_2170 exact 3D manufactured-heating timestep comparison",
        "",
        f"Exact solution: T(t) = {T0_K:.2f} + {BETA_K_PER_S:.3f} t  [K]",
        "Mesh/regions: jellyRoll_rotated, shell_rotated, cap_rotated",
        "",
        "Final values at t = 250 s:",
        "",
    ]

    display = summary[
        [
            "dt",
            "theory_K",
            "jellyRoll_rotated",
            "jellyRoll_rotated_err_K",
            "shell_rotated",
            "shell_rotated_err_K",
            "cap_rotated",
            "cap_rotated_err_K",
        ]
    ].copy()

    display.columns = [
        "dt [s]",
        "theory [K]",
        "jellyRoll [K]",
        "jelly err [K]",
        "shell [K]",
        "shell err [K]",
        "cap [K]",
        "cap err [K]",
    ]
    display = display.round(5)

    ax.text(
        0.02,
        0.98,
        "\n".join(lines),
        va="top",
        ha="left",
        family="monospace",
        fontsize=12,
    )

    table = ax.table(
        cellText=display.values,
        colLabels=display.columns,
        loc="center",
        cellLoc="center",
        bbox=[0.02, 0.20, 0.96, 0.45],
    )
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1, 1.4)
    pdf.savefig(fig, bbox_inches="tight")
    plt.close(fig)


def add_temperature_page(pdf: PdfPages, data: pd.DataFrame) -> None:
    fig, axes = plt.subplots(3, 1, figsize=(11, 8.5), sharex=True)
    dts = ["1", "0.1", "0.05", "0.01"]
    colors = {"1": "#8c2d04", "0.1": "#d95f0e", "0.05": "#1b9e77", "0.01": "#1f78b4"}

    for ax, region in zip(axes, FIELD_MAP.values(), strict=True):
        theory = data[["time_s", "theory_K"]].drop_duplicates().sort_values("time_s")
        ax.plot(theory["time_s"], theory["theory_K"], color="black", lw=2, label="theory")
        for dt in dts:
            subset = data[data["dt"] == dt].sort_values("time_s")
            ax.plot(
                subset["time_s"],
                subset[region],
                marker="o",
                ms=3,
                lw=1.5,
                color=colors[dt],
                label=f"dt={dt} s",
            )
        ax.set_ylabel("T [K]")
        ax.set_title(region)
        ax.grid(True, alpha=0.3)

    axes[0].legend(ncol=5, fontsize=8, loc="best")
    axes[-1].set_xlabel("time [s]")
    fig.suptitle("Temperature history vs exact theory", fontsize=14)
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    pdf.savefig(fig)
    plt.close(fig)


def add_error_page(pdf: PdfPages, data: pd.DataFrame) -> None:
    fig, axes = plt.subplots(3, 1, figsize=(11, 8.5), sharex=True)
    dts = ["1", "0.1", "0.05", "0.01"]
    colors = {"1": "#8c2d04", "0.1": "#d95f0e", "0.05": "#1b9e77", "0.01": "#1f78b4"}

    for ax, region in zip(axes, FIELD_MAP.values(), strict=True):
        for dt in dts:
            subset = data[data["dt"] == dt].sort_values("time_s").copy()
            subset["err_K"] = subset[region] - subset["theory_K"]
            ax.plot(
                subset["time_s"],
                subset["err_K"],
                marker="o",
                ms=3,
                lw=1.5,
                color=colors[dt],
                label=f"dt={dt} s",
            )
        ax.axhline(0.0, color="black", lw=1)
        ax.set_ylabel("error [K]")
        ax.set_title(region)
        ax.grid(True, alpha=0.3)

    axes[0].legend(ncol=4, fontsize=8, loc="best")
    axes[-1].set_xlabel("time [s]")
    fig.suptitle("Simulation minus exact theory", fontsize=14)
    fig.tight_layout(rect=[0, 0, 1, 0.97])
    pdf.savefig(fig)
    plt.close(fig)


def main() -> None:
    logs = {
        "1": Path("/workspace/artifacts/runtime/wedge_2170_exact_uniform_rise_dt1_20260427_092645/logs/exact_uniform_rise_dt1_to250_20260427_092645.log"),
        "0.1": Path("/workspace/artifacts/runtime/wedge_2170_exact_uniform_rise_dt01_20260427_092104/logs/exact_uniform_rise_dt01_to250_20260427_092104.log"),
        "0.05": Path("/workspace/artifacts/runtime/wedge_2170_exact_uniform_rise_dt005_20260427_092645/logs/exact_uniform_rise_dt005_to250_20260427_092645.log"),
        "0.01": Path("/workspace/artifacts/runtime/wedge_2170_exact_uniform_rise_dt001_20260427_090952/logs/exact_uniform_rise_dt001_to500_20260427_090952.log"),
    }

    frames = [parse_mean_writes(path, dt) for dt, path in logs.items()]
    data = pd.concat(frames, ignore_index=True)
    data = data[data["time_s"] <= 250.0].copy()
    data["dt_num"] = data["dt"].astype(float)
    data = data.sort_values(["dt_num", "time_s"], ascending=[False, True])
    summary = build_summary(data)

    out_dir = Path("/workspace/artifacts/reports")
    out_dir.mkdir(parents=True, exist_ok=True)
    series_csv, summary_csv = write_csv(data, summary, out_dir)
    pdf_path = out_dir / "wedge2170_exact_timestep_comparison_20260427.pdf"

    with PdfPages(pdf_path) as pdf:
        add_summary_page(pdf, summary)
        add_temperature_page(pdf, data)
        add_error_page(pdf, data)

    print(series_csv)
    print(summary_csv)
    print(pdf_path)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
from __future__ import annotations

import argparse
import re
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


TIME_RE = re.compile(r"^Time = ([-+0-9.eE]+)$")
QSUM_RE = re.compile(r"Q_sum_check ([-+0-9.eE]+) W")
JR_RE = re.compile(
    r"EnergyDebug region jellyRoll time ([-+0-9.eE]+).*?TAvgBefore ([-+0-9.eE]+) TAvgAfter ([-+0-9.eE]+)"
)
MINMAX_RE = re.compile(r"Min/max T:([-+0-9.eE]+) ([-+0-9.eE]+)")


def parse_log(path: Path) -> pd.DataFrame:
    rows: list[dict[str, float]] = []
    current_time: float | None = None
    pending_jr: dict[str, float] | None = None

    for raw in path.read_text(encoding="utf-8", errors="replace").splitlines():
        m = TIME_RE.search(raw)
        if m:
            current_time = float(m.group(1))
            continue

        m = JR_RE.search(raw)
        if m:
            pending_jr = {
                "time": float(m.group(1)),
                "jr_tavg_before": float(m.group(2)),
                "jr_tavg_after": float(m.group(3)),
            }
            continue

        if pending_jr is not None:
            m = MINMAX_RE.search(raw)
            if m:
                pending_jr["jr_tmin"] = float(m.group(1))
                pending_jr["jr_tmax"] = float(m.group(2))
                rows.append(pending_jr)
                pending_jr = None
                continue

        m = QSUM_RE.search(raw)
        if m and current_time is not None:
            qsum = float(m.group(1))
            for row in reversed(rows):
                if abs(row["time"] - current_time) < 1.0e-12:
                    row["q_sum_w"] = qsum
                    break

    df = pd.DataFrame(rows)
    if df.empty:
        raise RuntimeError(f"No jellyRoll EnergyDebug rows parsed from {path}")
    return df.sort_values("time").reset_index(drop=True)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--full-log", required=True)
    ap.add_argument("--restart-log", required=True)
    ap.add_argument("--restart-time", type=float, required=True)
    ap.add_argument("--out-dir", required=True)
    args = ap.parse_args()

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    full = parse_log(Path(args.full_log))
    restart = parse_log(Path(args.restart_log))

    full = full[full["time"] >= args.restart_time].copy()
    restart = restart[restart["time"] >= args.restart_time].copy()

    merged = pd.merge(
        full,
        restart,
        on="time",
        suffixes=("_full", "_restart"),
        how="inner",
    )
    if merged.empty:
        raise RuntimeError("No overlapping restart-segment times found between full and restarted logs")

    fig, axes = plt.subplots(4, 1, figsize=(11, 12), sharex=True, constrained_layout=True)

    axes[0].plot(merged["time"], merged["q_sum_w_full"], label="Full", lw=1.8)
    axes[0].plot(merged["time"], merged["q_sum_w_restart"], label="Restarted", lw=1.2, ls="--")
    axes[0].set_ylabel("Q_sum [W]")
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(merged["time"], merged["jr_tavg_after_full"], label="Full", lw=1.8)
    axes[1].plot(merged["time"], merged["jr_tavg_after_restart"], label="Restarted", lw=1.2, ls="--")
    axes[1].set_ylabel("JellyRoll Tavg [K]")
    axes[1].grid(True, alpha=0.3)

    axes[2].plot(merged["time"], merged["jr_tmin_full"], label="Full Tmin", lw=1.6)
    axes[2].plot(merged["time"], merged["jr_tmin_restart"], label="Restart Tmin", lw=1.1, ls="--")
    axes[2].plot(merged["time"], merged["jr_tmax_full"], label="Full Tmax", lw=1.6)
    axes[2].plot(merged["time"], merged["jr_tmax_restart"], label="Restart Tmax", lw=1.1, ls="--")
    axes[2].set_ylabel("JellyRoll Tmin/Tmax [K]")
    axes[2].legend(ncol=2, fontsize=8)
    axes[2].grid(True, alpha=0.3)

    axes[3].plot(merged["time"], merged["q_sum_w_restart"] - merged["q_sum_w_full"], label="Q_sum delta", lw=1.6)
    axes[3].plot(
        merged["time"],
        merged["jr_tavg_after_restart"] - merged["jr_tavg_after_full"],
        label="Tavg delta",
        lw=1.6,
    )
    axes[3].set_ylabel("Restart - Full")
    axes[3].set_xlabel("Time [s]")
    axes[3].legend()
    axes[3].grid(True, alpha=0.3)

    fig.suptitle("WriteTime Restart Comparison")
    fig.savefig(out_dir / "write_time_restart_comparison.png", dpi=180)
    plt.close(fig)

    summary = pd.DataFrame(
        [
            {"metric": "max_abs_q_sum_delta_w", "value": (merged["q_sum_w_restart"] - merged["q_sum_w_full"]).abs().max()},
            {"metric": "max_abs_jr_tavg_delta_k", "value": (merged["jr_tavg_after_restart"] - merged["jr_tavg_after_full"]).abs().max()},
            {"metric": "max_abs_jr_tmin_delta_k", "value": (merged["jr_tmin_restart"] - merged["jr_tmin_full"]).abs().max()},
            {"metric": "max_abs_jr_tmax_delta_k", "value": (merged["jr_tmax_restart"] - merged["jr_tmax_full"]).abs().max()},
            {"metric": "n_overlap_points", "value": float(len(merged))},
        ]
    )
    summary.to_csv(out_dir / "write_time_restart_plot_summary.csv", index=False)


if __name__ == "__main__":
    main()

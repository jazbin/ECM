#!/usr/bin/env python3
import argparse
from pathlib import Path
from paraview.simple import OpenFOAMReader, Slice, Delete
from paraview import servermanager
import vtk

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", required=True)
    ap.add_argument("--region", required=True)
    ap.add_argument("--field", required=True)
    ap.add_argument("--time", required=True)
    ap.add_argument("--slice-count", type=int, default=5)
    ap.add_argument(
        "--skip-pvpython",
        action="store_true",
        help="Skip pvpython slice rendering; use raw axial slice instead.",
    )
    ap.add_argument("--normal", default="z")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--prefix", required=True)
    args = ap.parse_args()

    case_dir = Path(args.case)
    foam_path = case_dir / "foam.foam"
    if not foam_path.exists():
        foam_path.write_text("")

    reader = OpenFOAMReader(FileName=str(foam_path))
    region_name = args.region
    if "/" not in region_name:
        region_name = f"/{region_name}/internalMesh"
    reader.MeshRegions = [region_name]
    reader.CellArrays = [args.field]
    time_val = float(args.time)
    reader.UpdatePipeline(time_val)

    bounds = reader.GetDataInformation().GetBounds()
    xmin, xmax, ymin, ymax, zmin, zmax = bounds
    if zmax <= zmin:
        raise RuntimeError("Invalid bounds for slicing")

    center = [(xmin + xmax) * 0.5, (ymin + ymax) * 0.5, (zmin + zmax) * 0.5]

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    normal = args.normal.lower()
    for i in range(args.slice_count):
        frac = (i + 1) / (args.slice_count + 1)
        if normal == "x":
            pos = xmin + frac * (xmax - xmin)
            origin = [pos, center[1], center[2]]
            nvec = [1, 0, 0]
        elif normal == "y":
            pos = ymin + frac * (ymax - ymin)
            origin = [center[0], pos, center[2]]
            nvec = [0, 1, 0]
        else:
            pos = zmin + frac * (zmax - zmin)
            origin = [center[0], center[1], pos]
            nvec = [0, 0, 1]

        slc = Slice(Input=reader)
        slc.SliceType = "Plane"
        slc.SliceType.Origin = origin
        slc.SliceType.Normal = nvec
        slc.UpdatePipeline(time_val)

        poly = servermanager.Fetch(slc)
        if poly is None:
            raise RuntimeError("Slice fetch returned None (no data to render)")

        if isinstance(poly, vtk.vtkMultiBlockDataSet):
            it = poly.NewIterator()
            it.InitTraversal()
            found = None
            while not it.IsDoneWithTraversal():
                data = it.GetCurrentDataObject()
                if data and data.GetCellData() and data.GetCellData().HasArray(args.field):
                    found = data
                    break
                it.GoToNextItem()
            del it
            if found is None:
                raise RuntimeError("No slice block with target field found in multiblock data")
            poly = found
        Delete(slc)

        c2p = vtk.vtkCellDataToPointData()
        c2p.SetInputData(poly)
        c2p.PassCellDataOn()
        c2p.Update()
        poly = c2p.GetOutput()

        bounds = poly.GetBounds()
        xmin, xmax, ymin, ymax, zmin, zmax = bounds
        nx = 400
        ny = 400
        image = vtk.vtkImageData()
        image.SetDimensions(nx, ny, 1)
        image.SetSpacing((xmax - xmin) / (nx - 1), (ymax - ymin) / (ny - 1), 1.0)
        image.SetOrigin(xmin, ymin, 0.0)

        probe = vtk.vtkProbeFilter()
        probe.SetInputData(image)
        probe.SetSourceData(poly)
        probe.Update()

        out = probe.GetOutput()
        arr = out.GetPointData().GetArray(args.field)
        if arr is None:
            raise RuntimeError(f"Field not found in slice output: {args.field}")
        rng = arr.GetRange()

        lut = vtk.vtkLookupTable()
        lut.SetNumberOfTableValues(256)
        lut.SetRange(rng)
        lut.Build()

        map_colors = vtk.vtkImageMapToColors()
        map_colors.SetInputData(out)
        map_colors.SetLookupTable(lut)
        map_colors.Update()

        out_path = out_dir / f"{args.prefix}_T_slice_{normal}{i+1}.png"
        writer = vtk.vtkPNGWriter()
        writer.SetFileName(str(out_path))
        writer.SetInputData(map_colors.GetOutput())
        writer.Write()

    return 0

if __name__ == "__main__":
    raise SystemExit(main())

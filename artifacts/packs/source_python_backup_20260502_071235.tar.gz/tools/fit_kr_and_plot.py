#!/usr/bin/env python3
"""
Fit radial thermal conductivity k_r to experimental temperature data
using 1D radial cylinder ODE model. Generates comparison plot.
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
import os

# ── Cell geometry & properties ────────────────────────────────────────────────
R = 0.0105        # m  (21/2 mm radius)
H = 0.070         # m  height
V_cell = np.pi * R**2 * H   # m³ full cell
rho   = 2837.7    # kg/m³  (from cellprops: 68.8g / V_cell)
Cp    = 903.9     # J/(kg·K) (from cellprops)
T_wall = 25.0     # °C  fixed outer wall

# ── Load experimental data ────────────────────────────────────────────────────
exp = pd.read_csv("/workspace/in/latest/experimental_time_temp_heat.csv")
exp = exp[exp["t_s"] <= 3000].reset_index(drop=True)
t_exp = exp["t_s"].values
Q_exp = exp["Q_GEN_W"].values
T_exp = exp["T_CELL_degC"].values

Q_interp = interp1d(t_exp, Q_exp, kind="linear", fill_value="extrapolate")

# ── ODE integrator ────────────────────────────────────────────────────────────
def simulate(kr):
    """1D lumped radial cylinder: dT/dt = Q/(rho*Cp*V) - (T - T_wall)/tau"""
    tau = rho * Cp * R**2 / (8 * kr)
    dt = 1.0          # 1 s time steps
    t_arr = np.arange(0, 3001, dt)
    T = np.zeros(len(t_arr))
    T[0] = T_wall
    for i in range(len(t_arr) - 1):
        Q = float(Q_interp(t_arr[i]))
        dTdt = Q / (rho * Cp * V_cell) - (T[i] - T_wall) / tau
        T[i+1] = T[i] + dt * dTdt
    return t_arr, T

# ── Grid search ───────────────────────────────────────────────────────────────
kr_values = np.concatenate([
    np.arange(0.010, 0.060, 0.001),
    np.arange(0.060, 0.200, 0.005),
    np.arange(0.200, 1.500, 0.050),
])

best_kr = None
best_rmse = 1e9
rmse_list = []

for kr in kr_values:
    t_sim, T_sim = simulate(kr)
    T_sim_at_exp = np.interp(t_exp, t_sim, T_sim)
    rmse = np.sqrt(np.mean((T_sim_at_exp - T_exp)**2))
    rmse_list.append(rmse)
    if rmse < best_rmse:
        best_rmse = rmse
        best_kr = kr

tau_best = rho * Cp * R**2 / (8 * best_kr)
t_best, T_best = simulate(best_kr)

# Also compute current sim (k_r = 1.4 W/(m·K))
t_cur, T_cur = simulate(1.4)

print(f"Optimal k_r  = {best_kr:.4f} W/(m·K)")
print(f"tau          = {tau_best:.1f} s  ({tau_best/60:.1f} min)")
print(f"RMSE         = {best_rmse:.4f} °C")
print(f"T_max sim    = {T_best.max():.2f} °C  (exp = {T_exp.max():.2f} °C)")
print(f"Current k_r  = 1.400 W/(m·K),  tau = {rho*Cp*R**2/(8*1.4):.1f} s")

# ── 4-panel figure ────────────────────────────────────────────────────────────
fig, axes = plt.subplots(2, 2, figsize=(13, 9))
fig.suptitle(
    f"Radial Thermal Conductivity Calibration — 2170 Jelly-Roll\n"
    f"R={R*1e3:.1f} mm, H={H*1e3:.0f} mm, ρ={rho:.0f} kg/m³, Cp={Cp:.0f} J/(kg·K)",
    fontsize=11
)

# Panel 1: experimental Q
ax = axes[0, 0]
ax.plot(t_exp/60, Q_exp, color="tab:orange", lw=1.2)
ax.set_xlabel("Time (min)")
ax.set_ylabel("Q_GEN (W)")
ax.set_title("Experimental heat generation")
ax.grid(True, alpha=0.3)

# Panel 2: temperature comparison
ax = axes[0, 1]
ax.plot(t_exp/60, T_exp, "k-", lw=1.5, label="Experimental")
ax.plot(t_best/60, T_best, "b--", lw=1.5,
        label=f"Fitted  k_r={best_kr:.3f} W/(m·K), τ={tau_best:.0f} s")
ax.plot(t_cur/60, T_cur, "r:", lw=1.5,
        label=f"Current k_r=1.400 W/(m·K), τ={rho*Cp*R**2/(8*1.4):.0f} s")
ax.axhline(T_wall, color="gray", ls="--", lw=0.8, label=f"Wall T = {T_wall}°C")
ax.set_xlabel("Time (min)")
ax.set_ylabel("Temperature (°C)")
ax.set_title("Temperature: experimental vs models")
ax.legend(fontsize=8)
ax.grid(True, alpha=0.3)

# Panel 3: RMSE vs k_r
ax = axes[1, 0]
ax.semilogy(kr_values, rmse_list, "k-", lw=1.2)
ax.axvline(best_kr, color="blue", ls="--", lw=1.2,
           label=f"Optimal k_r = {best_kr:.3f} W/(m·K)")
ax.axvline(1.4, color="red", ls=":", lw=1.2, label="Current k_r = 1.400 W/(m·K)")
ax.set_xlabel("k_r  (W/(m·K))")
ax.set_ylabel("RMSE (°C)")
ax.set_title("Fit quality vs radial conductivity")
ax.legend(fontsize=9)
ax.grid(True, alpha=0.3)

# Panel 4: residuals for best k_r
ax = axes[1, 1]
T_best_at_exp = np.interp(t_exp, t_best, T_best)
resid = T_best_at_exp - T_exp
ax.plot(t_exp/60, resid, color="tab:blue", lw=0.8)
ax.axhline(0, color="k", lw=0.8)
ax.set_xlabel("Time (min)")
ax.set_ylabel("Residual (°C)")
ax.set_title(f"Residuals — fitted model (RMSE = {best_rmse:.4f} °C)")
ax.grid(True, alpha=0.3)

plt.tight_layout()
out_path = "/workspace/artifacts/plots/kr_fit_experimental_20260426.pdf"
plt.savefig(out_path, bbox_inches="tight")
print(f"\nPlot saved: {out_path}")

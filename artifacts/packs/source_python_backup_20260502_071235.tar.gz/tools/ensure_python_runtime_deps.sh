#!/bin/bash
set -euo pipefail

root_dir="$(cd "$(dirname "$0")/.." && pwd)"
req_file="$root_dir/python/requirements-runtime.txt"

if [ ! -f "$req_file" ]; then
  echo "Missing runtime requirements file: $req_file" >&2
  exit 2
fi

if ! python3 - <<'PY'
import importlib
import sys

required = ["numpy", "pandas"]
missing = []
for name in required:
    try:
        importlib.import_module(name)
    except Exception:
        missing.append(name)

if missing:
    print("missing:" + ",".join(missing))
    sys.exit(1)
PY
then
  python3 -m pip install -r "$req_file"
fi

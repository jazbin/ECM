#!/bin/bash
set -euo pipefail

root_dir="$(cd "$(dirname "$0")/.." && pwd)"
base_case="$root_dir/cases/smoke_writeTime_ecmQdot"
stamp="$(date -u +%Y%m%d_%H%M%S)"
run_root="$root_dir/artifacts/runtime/restart_equivalence_$stamp"
cont_case="$run_root/continuous"
restart_case="$run_root/restarted"
log_dir="$root_dir/artifacts/logs"

mkdir -p "$run_root" "$log_dir"

if [ -f /opt/openfoam/etc/bashrc ]; then
  set +e
  set +u
  # shellcheck disable=SC1091
  source /opt/openfoam/etc/bashrc
  set -u
  set -e
fi

"$root_dir/tools/ensure_python_runtime_deps.sh"

if [ -z "${FOAM_USER_APPBIN:-}" ] && [ -d /workspace/.openfoam/bin ]; then
  export FOAM_USER_APPBIN=/workspace/.openfoam/bin
fi
if [ -z "${FOAM_USER_LIBBIN:-}" ] && [ -d /workspace/.openfoam/lib ]; then
  export FOAM_USER_LIBBIN=/workspace/.openfoam/lib
fi
if [ -n "${FOAM_USER_APPBIN:-}" ]; then
  export PATH="$FOAM_USER_APPBIN:$PATH"
fi
if [ -n "${FOAM_USER_LIBBIN:-}" ]; then
  export LD_LIBRARY_PATH="$FOAM_USER_LIBBIN:${LD_LIBRARY_PATH:-}"
fi

setup_case() {
  local case_dir="$1"
  mkdir -p "$case_dir"
  ln -s "$base_case/0" "$case_dir/0"
  ln -s "$base_case/constant" "$case_dir/constant"
  cp -a "$base_case/system" "$case_dir/system"
  mkdir -p "$case_dir/ecm"
}

configure_case() {
  local case_dir="$1"
  local start_from="$2"
  local end_time="$3"
  local write_interval="$4"
  foamDictionary -entry startFrom -set "$start_from" "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry endTime -set "$end_time" "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry deltaT -set 0.015625 "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry adjustTimeStep -set no "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry writeControl -set runTime "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry writeInterval -set "$write_interval" "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry purgeWrite -set 0 "$case_dir/system/controlDict" >/dev/null
  foamDictionary \
    -entry 'functions/ecmCoupling/command' \
    -set "\"python3 $root_dir/python/ecm_coupling_wrapper.py --input ecm/ecm_in.json --output ecm/ecm_out.json --state ecm/ecm_state.json --backend ecm-step --ecm-call-every-n-steps 5 --vt-min-v -100 --pipe-mode\"" \
    "$case_dir/system/controlDict" >/dev/null
}

latest_time_dir() {
  local case_dir="$1"
  find "$case_dir" -maxdepth 1 -mindepth 1 -type d \
    -regextype posix-extended \
    -regex ".*/[0-9]+(\\.[0-9]+)?" \
    | sed 's#.*/##' | sort -g | tail -n 1
}

run_solver() {
  local case_dir="$1"
  local log_file="$2"
  (
    cd "$case_dir"
    chtMultiRegionSolidFoam -case "$case_dir" >"$log_file" 2>&1
  )
}

setup_case "$cont_case"
setup_case "$restart_case"

configure_case "$cont_case" startTime 0.25 0.125
configure_case "$restart_case" startTime 0.125 0.125

cont_log="$log_dir/restart_equivalence_continuous_$stamp.log"
restart_part1_log="$log_dir/restart_equivalence_restart_part1_$stamp.log"
restart_part2_log="$log_dir/restart_equivalence_restart_part2_$stamp.log"

run_solver "$cont_case" "$cont_log"
run_solver "$restart_case" "$restart_part1_log"

configure_case "$restart_case" latestTime 0.25 0.125
run_solver "$restart_case" "$restart_part2_log"

cont_time="$(latest_time_dir "$cont_case")"
restart_time="$(latest_time_dir "$restart_case")"

if [ -z "$cont_time" ] || [ -z "$restart_time" ]; then
  echo "Failed to determine latest time directories." >&2
  exit 10
fi

checkpoint_file="$restart_case/ecm/restartCheckpoints/0.125/coupler_state.dat"
if [ ! -f "$checkpoint_file" ]; then
  echo "Missing restart checkpoint file: $checkpoint_file" >&2
  exit 11
fi

compare_file() {
  local left="$1"
  local right="$2"
  if ! cmp -s "$left" "$right"; then
    echo "Mismatch: $left vs $right" >&2
    return 1
  fi
}

compare_file "$cont_case/ecm/ecm_state.json" "$restart_case/ecm/ecm_state.json"
compare_file "$cont_case/ecm/ecm_last_good.bin" "$restart_case/ecm/ecm_last_good.bin"
compare_file "$cont_case/$cont_time/jellyRoll/ecmQdot" "$restart_case/$restart_time/jellyRoll/ecmQdot"

python3 - <<PY
import json
from pathlib import Path
cont = Path("$cont_case/ecm/ecm_state.json")
rest = Path("$restart_case/ecm/ecm_state.json")
cont_data = json.loads(cont.read_text())
rest_data = json.loads(rest.read_text())
assert cont_data == rest_data, "final ecm_state.json differs"
print("restart_equivalence_ok")
print(f"latest_time={Path('$cont_time')}")
print(f"final_step_id={cont_data['last_step_id']}")
print(f"final_time_s={cont_data['last_time_s']}")
PY

echo "Continuous log: $cont_log"
echo "Restart part1 log: $restart_part1_log"
echo "Restart part2 log: $restart_part2_log"
echo "Run root: $run_root"

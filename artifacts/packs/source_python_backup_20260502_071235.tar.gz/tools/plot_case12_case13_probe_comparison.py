#!/usr/bin/env python3
"""Plot case12 and case13 probe temperatures against the common reference."""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


BASE = Path("/workspace/in/latest")
REF_CSV = BASE / "case12/validation_probe_data.csv"
OUT_DIR = Path("/workspace/artifacts/plots")
STAMP = "20260429"

PROBES = [
    ("T1", BASE / "case12/postProcessing/probeT1/shell_rotated/0/T", 0),
    ("T2", BASE / "case12/postProcessing/probeLocations/jellyRoll_rotated/0/T", 1),
    ("T3", BASE / "case12/postProcessing/probeLocations/jellyRoll_rotated/0/T", 2),
    ("T4", BASE / "case12/postProcessing/probeLocations/jellyRoll_rotated/0/T", 3),
    ("T5", BASE / "case12/postProcessing/probeLocations/jellyRoll_rotated/0/T", 4),
    ("T6", BASE / "case12/postProcessing/probeT6/cap_rotated/0/T", 0),
]

CASE_PATHS = {
    "case12": {
        "T1": BASE / "case12/postProcessing/probeT1/shell_rotated/0/T",
        "T2": BASE / "case12/postProcessing/probeLocations/jellyRoll_rotated/0/T",
        "T3": BASE / "case12/postProcessing/probeLocations/jellyRoll_rotated/0/T",
        "T4": BASE / "case12/postProcessing/probeLocations/jellyRoll_rotated/0/T",
        "T5": BASE / "case12/postProcessing/probeLocations/jellyRoll_rotated/0/T",
        "T6": BASE / "case12/postProcessing/probeT6/cap_rotated/0/T",
    },
    "case13": {
        "T1": BASE / "case13/postProcessing/probeT1/shell_rotated/0/T",
        "T2": BASE / "case13/postProcessing/probeLocations/jellyRoll_rotated/0/T",
        "T3": BASE / "case13/postProcessing/probeLocations/jellyRoll_rotated/0/T",
        "T4": BASE / "case13/postProcessing/probeLocations/jellyRoll_rotated/0/T",
        "T5": BASE / "case13/postProcessing/probeLocations/jellyRoll_rotated/0/T",
        "T6": BASE / "case13/postProcessing/probeT6/cap_rotated/0/T",
    },
}

PROBE_COLS = {"T1": 0, "T2": 0, "T3": 1, "T4": 2, "T5": 3, "T6": 0}
PROBE_COLORS = {
    "T1": "#1f77b4",
    "T2": "#ff7f0e",
    "T3": "#2ca02c",
    "T4": "#d62728",
    "T5": "#9467bd",
    "T6": "#8c564b",
}
CASE_STYLES = {
    "reference": {"linestyle": "-", "linewidth": 2.0, "alpha": 0.9},
    "case12": {"linestyle": "--", "linewidth": 1.8, "alpha": 0.95},
    "case13": {"linestyle": ":", "linewidth": 2.2, "alpha": 0.95},
}


def load_probe_file(path: Path) -> tuple[np.ndarray, list[np.ndarray]]:
    times = []
    cols: list[list[float]] = []
    with path.open() as handle:
        n_cols = None
        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            vals = line.split()
            if n_cols is None:
                n_cols = len(vals) - 1
                cols = [[] for _ in range(n_cols)]
            times.append(float(vals[0]))
            for idx in range(n_cols):
                cols[idx].append(float(vals[idx + 1]))
    return np.array(times), [np.array(col) for col in cols]


def load_reference(path: Path) -> dict[str, np.ndarray]:
    rows = list(csv.DictReader(path.open()))
    out: dict[str, np.ndarray] = {"t_s": np.array([float(r["t_s"]) for r in rows])}
    for probe, *_ in PROBES:
        out[probe] = np.array([float(r[probe]) for r in rows])
    return out


def load_case_probe(case_name: str, probe: str) -> tuple[np.ndarray, np.ndarray]:
    path = CASE_PATHS[case_name][probe]
    time_s, cols = load_probe_file(path)
    temp_c = cols[PROBE_COLS[probe]] - 273.15
    return time_s, temp_c


def build_overlay(reference: dict[str, np.ndarray]) -> Path:
    fig, ax = plt.subplots(figsize=(15, 8), dpi=160)

    for probe, *_ in PROBES:
        color = PROBE_COLORS[probe]
        ax.plot(
            reference["t_s"],
            reference[probe],
            color=color,
            label=f"{probe} reference",
            **CASE_STYLES["reference"],
        )
        for case_name in ("case12", "case13"):
            time_s, temp_c = load_case_probe(case_name, probe)
            ax.plot(
                time_s,
                temp_c,
                color=color,
                label=f"{probe} {case_name} CFD",
                **CASE_STYLES[case_name],
            )

    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Temperature [C]")
    ax.set_title("Probe Comparison vs Reference: corrected case12 and case13")
    ax.set_xlim(0, 400)
    ax.grid(True, alpha=0.25)
    ax.legend(ncol=3, fontsize=9, frameon=True)
    fig.tight_layout()

    out_path = OUT_DIR / f"case12_case13_vs_client_probe_overlay_singleplot_{STAMP}.png"
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return out_path


def build_delta(reference: dict[str, np.ndarray]) -> Path:
    fig, ax = plt.subplots(figsize=(15, 8), dpi=160)

    ref_t = reference["t_s"]
    for probe, *_ in PROBES:
        color = PROBE_COLORS[probe]
        for case_name in ("case12", "case13"):
            time_s, temp_c = load_case_probe(case_name, probe)
            interp_c = np.interp(ref_t, time_s, temp_c)
            delta_c = interp_c - reference[probe]
            ax.plot(
                ref_t,
                delta_c,
                color=color,
                label=f"{probe} {case_name} ΔT",
                **CASE_STYLES[case_name],
            )

    ax.axhline(0.0, color="black", linewidth=1.0, alpha=0.6)
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Delta T = CFD - reference [C]")
    ax.set_title("Probe Delta-T vs Reference: corrected case12 and case13")
    ax.set_xlim(0, 400)
    ax.grid(True, alpha=0.25)
    ax.legend(ncol=3, fontsize=9, frameon=True)
    fig.tight_layout()

    out_path = OUT_DIR / f"case12_case13_vs_client_probe_deltaT_singleplot_{STAMP}.png"
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return out_path


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    reference = load_reference(REF_CSV)
    overlay = build_overlay(reference)
    delta = build_delta(reference)
    print(overlay)
    print(delta)


if __name__ == "__main__":
    main()

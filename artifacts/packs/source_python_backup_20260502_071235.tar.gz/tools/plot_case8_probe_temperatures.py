#!/usr/bin/env python3
"""Axial probe temperature time series — case8 / case10 / case11 vs client reference."""

from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages

BASE     = Path("/workspace/in/latest")
VAL_PATH = BASE / "case8/validation_probe_data.csv"
OUT      = Path("/workspace/artifacts/reports/case8_probe_temperatures.pdf")

PROBES = [
    # (label, jr_col, shell_file, cap_file)
    ("T1  r=0, z=0.000 m", None, "probeT1/shell_rotated/400/T",           0),
    ("T2  r=0, z=0.014 m", 1,    "probeLocations/jellyRoll_rotated/400/T", None),
    ("T3  r=0, z=0.028 m", 2,    "probeLocations/jellyRoll_rotated/400/T", None),
    ("T4  r=0, z=0.042 m", 3,    "probeLocations/jellyRoll_rotated/400/T", None),
    ("T5  r=0, z=0.056 m", 4,    "probeLocations/jellyRoll_rotated/400/T", None),
    ("T6  r=0, z=0.070 m", None, "probeT6/cap_rotated/400/T",              0),
]

VAL_COLS = ["T1", "T2", "T3", "T4", "T5", "T6"]
COLORS   = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b"]
MARKERS  = ["o", "s", "^", "D", "v", "P"]


def load_probe_file(path: Path):
    times, cols = [], []
    with open(path) as f:
        n_cols = None
        for line in f:
            line = line.strip()
            if line.startswith("#") or not line:
                continue
            vals = line.split()
            if n_cols is None:
                n_cols = len(vals) - 1
                cols = [[] for _ in range(n_cols)]
            times.append(float(vals[0]))
            for i in range(n_cols):
                cols[i].append(float(vals[i + 1]))
    return np.array(times), [np.array(c) for c in cols]


def load_validation(path: Path):
    rows = list(csv.DictReader(open(path)))
    out = {"t_s": np.array([float(r["t_s"]) for r in rows])}
    for col in VAL_COLS:
        out[col] = np.array([float(r[col]) for r in rows])
    return out


def get_probe(case_dir: Path, rel_path: str, col):
    cache = {}
    p = case_dir / "postProcessing" / rel_path
    if p not in cache:
        cache[p] = load_probe_file(p)
    t, cols = load_probe_file(p)
    return t, cols[col] - 273.15


def main():
    val = load_validation(VAL_PATH)

    fig, ax = plt.subplots(figsize=(12, 6.5), dpi=150)

    for i, (label, jr_col, rel_path, fixed_col) in enumerate(PROBES):
        col   = jr_col if jr_col is not None else fixed_col
        color = COLORS[i]
        marker = MARKERS[i]

        # case8 dt=0.01s
        t8, T8 = get_probe(BASE / "case8", rel_path, col)
        ax.plot(t8, T8, color=color, lw=2.0, ls="-")

        # client reference (open markers)
        vt = val["t_s"]
        vT = val[VAL_COLS[i]]
        step = max(1, len(vt) // 20)
        ax.plot(vt, vT, color=color, ls="--", lw=1.5, alpha=0.7)
        ax.plot(vt[::step], vT[::step],
                color=color, ls="none",
                marker=marker, ms=5, mew=1.2, mfc="none")

    # Proxy handles for legend
    from matplotlib.lines import Line2D
    legend_probes = [
        Line2D([0], [0], color=COLORS[i], lw=2)
        for i in range(len(PROBES))
    ]
    legend_styles = [
        Line2D([0], [0], color="black", lw=2, ls="-",  label="Case 8 — CFD  (Δt = 0.01 s)"),
        Line2D([0], [0], color="black", lw=1.5, ls="--", marker="o", ms=5, mew=1.2, mfc="none",
               label="Client reference"),
    ]

    leg1 = ax.legend(legend_probes, [p[0] for p in PROBES],
                     fontsize=9, frameon=True, loc="upper left",
                     title="Probe", title_fontsize=9)
    ax.add_artist(leg1)
    ax.legend(handles=legend_styles, fontsize=9, frameon=True,
              loc="center left", bbox_to_anchor=(0.0, 0.52))

    ax.set_xlabel("Time [s]", fontsize=13)
    ax.set_ylabel("Temperature [°C]", fontsize=13)
    ax.set_title(
        "Axial temperature probes (r = 0) — 20 W constant heat · fixedValue 25 °C walls · T₀ = 25 °C\n"
        "Case 8: heat in jellyRoll only · fixedValue 25°C walls · Δt = 0.01 s",
        fontsize=12, fontweight="bold",
    )
    ax.grid(True, alpha=0.3)
    ax.set_xlim(0, 400)
    ax.tick_params(labelsize=11)

    fig.tight_layout()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with PdfPages(OUT) as pdf:
        pdf.savefig(fig, bbox_inches="tight")
        pdf.savefig(_make_params_page(), bbox_inches="tight")
    plt.close(fig)
    print(f"Saved: {OUT}")


def _make_params_page():
    fig, ax = plt.subplots(figsize=(11, 8.5), dpi=150)
    ax.axis("off")

    title = "Case 8 — Simulation Parameters"
    fig.text(0.5, 0.97, title, ha="center", va="top", fontsize=14, fontweight="bold")

    sections = [
        ("Solver & Numerics", [
            ("Solver",          "chtMultiRegionSolidFoam  (solids-only CHT)"),
            ("End time",        "400 s"),
            ("Δt",              "0.01 s  (fixed)"),
            ("Write interval",  "10 s"),
            ("Initial T",       "25 °C  (uniform, all regions)"),
        ]),
        ("Boundary Conditions", [
            ("Shell outer wall",   "fixedValue  T = 25 °C"),
            ("Cap outer wall",     "fixedValue  T = 25 °C"),
            ("All interfaces",     "turbulentTemperatureRadCoupledMixed  (conjugate)"),
        ]),
        ("Interface Contact Resistance", [
            ("JR ↔ shell  (radial side)",  "perfect contact  (no thicknessLayers)"),
            ("JR ↔ shell  (bottom face)",  "t = 6×10⁻⁷ m,  κ = 1 W/m·K  →  R ≈ 0.002 K/W"),
            ("JR ↔ cap    (top face)",     "perfect contact  (no thicknessLayers)"),
            ("Shell ↔ cap",                "perfect contact  (no thicknessLayers)"),
        ]),
        ("Heat Source", [
            ("Applied to",   "jellyRoll only"),
            ("Mode",         "scalarSemiImplicitSource,  volumeMode absolute"),
            ("Power",        "20 W  (constant, explicit)"),
            ("Shell / cap",  "no heat source"),
        ]),
        ("JellyRoll Thermal Properties", [
            ("ρ",            "2660.7 kg/m³"),
            ("Cp",           "tabulated: 835.6 J/(kg·K) @ 250 K → 1585.6 J/(kg·K) @ 500 K"),
            ("κ  (r, θ, z)", "1.4 · 1.4 · 29  W/(m·K)  — anisotropic, cylindrical coords"),
            ("Transport",    "tabulatedAnIso  /  hTabulated  /  icoPolynomial"),
        ]),
        ("Shell Thermal Properties", [
            ("ρ",    "8000 kg/m³"),
            ("Cp",   "500 J/(kg·K)"),
            ("κ",    "16 W/(m·K)  (isotropic)"),
            ("Material", "Steel"),
        ]),
        ("Cap Thermal Properties", [
            ("ρ",            "1447.2 kg/m³"),
            ("Cp",           "500 J/(kg·K)"),
            ("κ  (r, θ, z)", "0.01 · 0.01 · 0.1  W/(m·K)  — anisotropic"),
        ]),
    ]

    y = 0.93
    x_label = 0.04
    x_value = 0.38
    dy_section = 0.033
    dy_row = 0.026

    for section_title, rows in sections:
        ax.text(x_label, y, section_title, transform=ax.transAxes,
                fontsize=10, fontweight="bold", color="#2c3e50")
        y -= dy_section * 0.7
        ax.plot([0.03, 0.97], [y, y], color="#aaaaaa", lw=0.6,
                transform=ax.transAxes)
        y -= dy_section * 0.35
        for label, value in rows:
            ax.text(x_label, y, label, transform=ax.transAxes,
                    fontsize=8.5, color="#555555")
            ax.text(x_value, y, value, transform=ax.transAxes,
                    fontsize=8.5, color="#111111")
            y -= dy_row
        y -= dy_section * 0.3

    return fig


if __name__ == "__main__":
    main()

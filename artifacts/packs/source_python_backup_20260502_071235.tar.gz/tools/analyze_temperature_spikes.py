#!/usr/bin/env python3
from __future__ import annotations

import argparse
import math
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def read_scalar_field(path: Path) -> list[float]:
    text = path.read_text(encoding="utf-8", errors="replace")
    marker = "internalField   nonuniform List<scalar>"
    i = text.find(marker)
    if i < 0:
        raise RuntimeError(f"nonuniform scalar internalField not found in {path}")
    rest = text[i + len(marker):]
    lines = [ln.strip() for ln in rest.splitlines() if ln.strip()]
    n = int(lines[0])
    if lines[1] != "(":
        raise RuntimeError(f"unexpected field format in {path}")
    return [float(x) for x in lines[2:2+n]]


def read_vector_field(path: Path) -> list[tuple[float, float, float]]:
    text = path.read_text(encoding="utf-8", errors="replace")
    marker = "internalField   nonuniform List<vector>"
    i = text.find(marker)
    if i < 0:
        raise RuntimeError(f"nonuniform vector internalField not found in {path}")
    rest = text[i + len(marker):]
    lines = [ln.strip() for ln in rest.splitlines() if ln.strip()]
    n = int(lines[0])
    if lines[1] != "(":
        raise RuntimeError(f"unexpected field format in {path}")
    out: list[tuple[float, float, float]] = []
    for s in lines[2:2+n]:
        xyz = tuple(float(x) for x in s.strip("()").split())
        out.append(xyz)
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--case-dir", required=True)
    ap.add_argument("--time", required=True)
    ap.add_argument("--region", default="jellyRoll")
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--n-extreme", type=int, default=200)
    args = ap.parse_args()

    region_dir = Path(args.case_dir) / args.time / args.region
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    T = read_scalar_field(region_dir / "T")
    C = read_vector_field(region_dir / "C")
    n = len(T)
    if len(C) != n:
        raise RuntimeError("T/C size mismatch")

    rows = []
    for i, (t, c) in enumerate(zip(T, C)):
        x, y, z = c
        rows.append(
            {
                "cell_id": i,
                "T": t,
                "x": x,
                "y": y,
                "z": z,
                "r": math.hypot(x, y),
            }
        )

    df = pd.DataFrame(rows)
    n_ext = min(args.n_extreme, len(df))
    hottest = df.nlargest(n_ext, "T").copy()
    coldest = df.nsmallest(n_ext, "T").copy()

    summary = pd.DataFrame(
        [
            {"metric": "n_cells", "value": float(len(df))},
            {"metric": "T_min", "value": df["T"].min()},
            {"metric": "T_p001", "value": df["T"].quantile(0.001)},
            {"metric": "T_p01", "value": df["T"].quantile(0.01)},
            {"metric": "T_p50", "value": df["T"].quantile(0.50)},
            {"metric": "T_p99", "value": df["T"].quantile(0.99)},
            {"metric": "T_p999", "value": df["T"].quantile(0.999)},
            {"metric": "T_max", "value": df["T"].max()},
            {"metric": "count_T_gt_350", "value": float((df["T"] > 350.0).sum())},
            {"metric": "count_T_gt_400", "value": float((df["T"] > 400.0).sum())},
            {"metric": "count_T_lt_260", "value": float((df["T"] < 260.0).sum())},
        ]
    )
    summary.to_csv(out_dir / "temperature_spike_summary.csv", index=False)
    hottest.to_csv(out_dir / "hottest_cells.csv", index=False)
    coldest.to_csv(out_dir / "coldest_cells.csv", index=False)

    fig, axes = plt.subplots(2, 1, figsize=(10, 10), constrained_layout=True)
    axes[0].hist(df["T"], bins=200, color="#4c78a8")
    axes[0].set_xlabel("Temperature [K]")
    axes[0].set_ylabel("Cell count")
    axes[0].set_title(f"{args.region} temperature distribution at t={args.time}")
    axes[0].grid(True, alpha=0.3)

    axes[1].scatter(df["z"], df["x"], s=0.2, c="#d9d9d9", alpha=0.15, label="all cells")
    axes[1].scatter(hottest["z"], hottest["x"], s=10, c="#d62728", label=f"hottest {n_ext}")
    axes[1].scatter(coldest["z"], coldest["x"], s=10, c="#1f77b4", label=f"coldest {n_ext}")
    axes[1].set_xlabel("z [m]")
    axes[1].set_ylabel("x [m]")
    axes[1].set_title("Extreme-cell x-z locations")
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)

    fig.savefig(out_dir / "temperature_spike_diagnostics.png", dpi=180)
    plt.close(fig)


if __name__ == "__main__":
    main()

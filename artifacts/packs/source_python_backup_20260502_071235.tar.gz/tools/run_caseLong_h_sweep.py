#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import json
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


TIME_DIR_RE = re.compile(r"^\d+(?:\.\d+)?$")


def replace_one(pattern: str, repl: str, text: str, path: Path) -> str:
    updated, count = re.subn(pattern, repl, text, count=1, flags=re.MULTILINE)
    if count != 1:
        raise RuntimeError(f"Expected one match for {pattern!r} in {path}")
    return updated


def patch_file(path: Path, replacements: list[tuple[str, str]]) -> None:
    text = path.read_text(encoding="utf-8")
    for pattern, repl in replacements:
        text = replace_one(pattern, repl, text, path)
    path.write_text(text, encoding="utf-8")


def remove_time_dirs(case_dir: Path) -> None:
    for child in case_dir.iterdir():
        if child.is_dir() and TIME_DIR_RE.fullmatch(child.name):
            shutil.rmtree(child)


def create_work_case(base_case: Path, work_case: Path) -> None:
    if work_case.exists():
        shutil.rmtree(work_case)
    work_case.mkdir(parents=True)

    shutil.copy2(base_case / "Allrun", work_case / "Allrun")
    shutil.copy2(base_case / "monitor.py", work_case / "monitor.py")
    shutil.copy2(base_case / "validation_probe_data.csv", work_case / "validation_probe_data.csv")
    shutil.copytree(base_case / "system", work_case / "system")
    shutil.copytree(base_case / "initBCs", work_case / "initBCs")

    # Share the heavy static mesh/material tree instead of copying it.
    (work_case / "constant").symlink_to((base_case / "constant").resolve())
    (work_case / "ecm").mkdir()
    (work_case / "logs").mkdir()


def latest_log(log_dir: Path) -> Path:
    logs = sorted(log_dir.glob("run_*.log"))
    if not logs:
        raise FileNotFoundError(f"No run logs found in {log_dir}")
    return logs[-1]


def write_log_tail(log_path: Path, out_path: Path, n_lines: int = 200) -> None:
    lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
    tail = lines[-n_lines:]
    out_path.write_text("\n".join(tail) + ("\n" if tail else ""), encoding="utf-8")


def load_validation(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    t_s: list[float] = []
    q_w: list[float] = []
    t_c: list[float] = []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            t_s.append(float(row["t_ss"]))
            q_w.append(float(row["Q_cell_W"]))
            t_c.append(float(row["T_cell_K"]) - 273.15)
    return np.array(t_s), np.array(q_w), np.array(t_c)


def load_summary(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    t_s: list[float] = []
    q_w: list[float] = []
    t_c: list[float] = []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            t_s.append(float(row["time_s"]))
            q_w.append(float(row["Q_GEN_W"]))
            t_c.append(float(row["T_feedback_degC"]))
    return np.array(t_s), np.array(q_w), np.array(t_c)


@dataclass
class Metrics:
    h_w_m2k: float
    t_end_s: float
    n_points: int
    temp_rmse_c: float
    temp_bias_c: float
    temp_end_error_c: float
    heat_rmse_w: float
    heat_bias_w: float
    heat_end_error_w: float


def analyze_run(summary_csv: Path, validation_csv: Path, out_dir: Path, h_value: float, tmax: float) -> Metrics:
    out_dir.mkdir(parents=True, exist_ok=True)
    t_s, q_w, t_c = load_summary(summary_csv)
    val_t, val_q, val_tc = load_validation(validation_csv)

    s_mask = t_s <= tmax + 1.0e-12
    v_mask = val_t <= tmax + 1.0e-12
    t_s = t_s[s_mask]
    q_w = q_w[s_mask]
    t_c = t_c[s_mask]
    val_t = val_t[v_mask]
    val_q = val_q[v_mask]
    val_tc = val_tc[v_mask]

    q_ref = np.interp(t_s, val_t, val_q)
    t_ref = np.interp(t_s, val_t, val_tc)
    dq = q_w - q_ref
    dt = t_c - t_ref

    plt.style.use("seaborn-v0_8-whitegrid")

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(t_s, t_c, color="#005f73", linewidth=1.8, label=f"h={h_value:g} T feedback")
    ax.plot(val_t, val_tc, color="#bb3e03", linewidth=1.8, linestyle="--", label="Validation T cell")
    ax.set_title("ECM Feedback Temperature vs Validation")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Temperature [C]")
    ax.set_xlim(0.0, tmax)
    ax.legend(frameon=True)
    fig.tight_layout()
    fig.savefig(out_dir / "temperature_overlay.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(t_s, q_w, color="#0a9396", linewidth=1.8, label=f"h={h_value:g} Q_GEN")
    ax.plot(val_t, val_q, color="#ee9b00", linewidth=1.8, linestyle="--", label="Validation Q cell")
    ax.set_title("ECM Heat vs Validation")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Heat [W]")
    ax.set_xlim(0.0, tmax)
    ax.legend(frameon=True)
    fig.tight_layout()
    fig.savefig(out_dir / "heat_overlay.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(t_s, dt, color="#005f73", linewidth=1.8, label="T feedback - Validation")
    ax.axhline(0.0, color="#111111", linewidth=1.0, linestyle="--", alpha=0.85)
    ax.set_title("Temperature Difference")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Temperature Difference [C]")
    ax.set_xlim(0.0, tmax)
    ax.legend(frameon=True)
    fig.tight_layout()
    fig.savefig(out_dir / "temperature_diff.png", dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(t_s, dq, color="#0a9396", linewidth=1.8, label="Q_GEN - Validation")
    ax.axhline(0.0, color="#111111", linewidth=1.0, linestyle="--", alpha=0.85)
    ax.set_title("Heat Difference")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Heat Difference [W]")
    ax.set_xlim(0.0, tmax)
    ax.legend(frameon=True)
    fig.tight_layout()
    fig.savefig(out_dir / "heat_diff.png", dpi=180)
    plt.close(fig)

    metrics = Metrics(
        h_w_m2k=h_value,
        t_end_s=float(t_s[-1]),
        n_points=int(t_s.size),
        temp_rmse_c=float(np.sqrt(np.mean(dt**2))),
        temp_bias_c=float(np.mean(dt)),
        temp_end_error_c=float(dt[-1]),
        heat_rmse_w=float(np.sqrt(np.mean(dq**2))),
        heat_bias_w=float(np.mean(dq)),
        heat_end_error_w=float(dq[-1]),
    )

    (out_dir / "metrics.json").write_text(json.dumps(metrics.__dict__, indent=2) + "\n", encoding="utf-8")
    return metrics


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a local sequential h sweep for rev4/caseLong.")
    parser.add_argument("--base-case", default="/workspace/rev4/caseLong")
    parser.add_argument("--work-case", default="/workspace/rev4/caseLong_hSweepWork")
    parser.add_argument("--validation-csv", default="/workspace/projectConstraintsParameters/validationData.csv")
    parser.add_argument("--output-root", default=None)
    parser.add_argument("--end-time", type=float, default=2000.0)
    parser.add_argument("--delta-t", type=float, default=0.05)
    parser.add_argument("--write-interval", type=float, default=3000.0)
    parser.add_argument("--h-values", nargs="+", type=float, default=[10.0, 12.5, 15.0, 17.5, 20.0, 25.0])
    args = parser.parse_args()

    repo = Path("/workspace")
    base_case = Path(args.base_case).resolve()
    work_case = Path(args.work_case).resolve()
    validation_csv = Path(args.validation_csv).resolve()

    if args.output_root is None:
        stamp = subprocess.check_output(["date", "-u", "+%Y%m%d_%H%M%S"], text=True).strip()
        output_root = repo / "artifacts" / "h_sweep" / f"caseLong_h_sweep_{stamp}"
    else:
        output_root = Path(args.output_root).resolve()
    output_root.mkdir(parents=True, exist_ok=True)

    create_work_case(base_case, work_case)

    metrics_rows: list[Metrics] = []
    for h_value in args.h_values:
        print(f"=== Running h={h_value:g} W/m^2/K ===", flush=True)

        patch_file(
            work_case / "system" / "controlDict",
            [
                (r"(^\s*endTime\s+)([^;]+);", rf"\g<1>{args.end_time:g};"),
                (r"(^\s*deltaT\s+)([^;]+);", rf"\g<1>{args.delta_t:g};"),
                (r"(^\s*writeInterval\s+)([^;]+);", rf"\g<1>{args.write_interval:g};"),
            ],
        )
        for rel in ["initBCs/shell_rotated/T", "initBCs/cap_rotated/T"]:
            patch_file(
                work_case / rel,
                [(r"(^\s*h\s+uniform\s+)([^;]+);", rf"\g<1>{h_value:g};")],
            )

        subprocess.run(
            ["./Allrun"],
            cwd=work_case,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.STDOUT,
        )

        run_dir = output_root / f"h_{str(h_value).replace('.', 'p')}"
        run_dir.mkdir(parents=True, exist_ok=True)

        summary_src = work_case / "ecm" / "ecm_wrapper_summary.csv"
        summary_dst = run_dir / "ecm_wrapper_summary.csv"
        shutil.copy2(summary_src, summary_dst)

        log_src = latest_log(work_case / "logs")
        write_log_tail(log_src, run_dir / "run_log_tail.txt")

        metrics = analyze_run(summary_dst, validation_csv, run_dir / "analysis", h_value, args.end_time)
        metrics_rows.append(metrics)

        # Keep the work case small between runs.
        remove_time_dirs(work_case)
        shutil.rmtree(work_case / "postProcessing", ignore_errors=True)
        shutil.rmtree(work_case / "logs", ignore_errors=True)
        shutil.rmtree(work_case / "ecm", ignore_errors=True)
        (work_case / "logs").mkdir()
        (work_case / "ecm").mkdir()

    metrics_rows.sort(key=lambda m: (abs(m.temp_rmse_c), abs(m.temp_bias_c), abs(m.temp_end_error_c)))
    metrics_csv = output_root / "sweep_metrics.csv"
    with metrics_csv.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(Metrics.__annotations__.keys()))
        writer.writeheader()
        for row in metrics_rows:
            writer.writerow(row.__dict__)

    lines = [
        "# caseLong h sweep ranking",
        "",
        "| h [W/m^2/K] | temp RMSE [C] | temp bias [C] | temp end err [C] | heat RMSE [W] | heat bias [W] | heat end err [W] |",
        "| ---: | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for row in metrics_rows:
        lines.append(
            f"| {row.h_w_m2k:.3f} | {row.temp_rmse_c:.6f} | {row.temp_bias_c:.6f} | {row.temp_end_error_c:.6f} | {row.heat_rmse_w:.6f} | {row.heat_bias_w:.6f} | {row.heat_end_error_w:.6f} |"
        )
    (output_root / "sweep_ranking.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    print(f"Sweep complete: {output_root}", flush=True)


if __name__ == "__main__":
    main()

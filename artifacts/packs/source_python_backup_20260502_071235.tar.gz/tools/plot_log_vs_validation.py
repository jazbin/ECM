#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


TIME_RE = re.compile(r"^Time = ([0-9eE+\-.]+)")
MINMAX_RE = re.compile(r"^Min/max T:([0-9eE+\-.]+) ([0-9eE+\-.]+)")
QSUM_RE = re.compile(r"^Q_sum_check ([0-9eE+\-.]+) W")
MEAN_HEADER_RE = re.compile(r"^volFieldValue jellyRollMeanT write:")
MEAN_VALUE_RE = re.compile(r"volAverage\(jellyRoll_rotated\) of T = ([0-9eE+\-.]+)")


def load_validation(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    t_s: list[float] = []
    q_w: list[float] = []
    t_k: list[float] = []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            t_s.append(float(row["t_ss"]))
            q_w.append(float(row["Q_cell_W"]))
            t_k.append(float(row["T_cell_K"]))
    return np.array(t_s), np.array(q_w), np.array(t_k)


def parse_log(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    max_times: list[float] = []
    max_t_k: list[float] = []
    q_times: list[float] = []
    q_w: list[float] = []
    mean_times: list[float] = []
    mean_t_k: list[float] = []

    current_time: float | None = None
    expect_jelly_minmax = False
    expect_mean_value = False

    with path.open(encoding="utf-8", errors="replace") as f:
        for raw in f:
            line = raw.strip()

            m = TIME_RE.match(line)
            if m:
                current_time = float(m.group(1))
                expect_jelly_minmax = True
                continue

            if expect_jelly_minmax:
                m = MINMAX_RE.match(line)
                if m and current_time is not None:
                    max_times.append(current_time)
                    max_t_k.append(float(m.group(2)))
                    expect_jelly_minmax = False
                    continue

            m = QSUM_RE.match(line)
            if m and current_time is not None:
                q_times.append(current_time)
                q_w.append(float(m.group(1)))
                continue

            if MEAN_HEADER_RE.match(line):
                expect_mean_value = True
                continue

            if expect_mean_value:
                m = MEAN_VALUE_RE.search(line)
                if m and current_time is not None:
                    mean_times.append(current_time)
                    mean_t_k.append(float(m.group(1)))
                    expect_mean_value = False
                    continue

    return (
        np.array(max_times),
        np.array(max_t_k),
        np.array(q_times),
        np.array(q_w),
        np.array(mean_times),
        np.array(mean_t_k),
    )


def c_to_k_delta(x_k: np.ndarray) -> np.ndarray:
    return x_k - 273.15


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare log-derived heat and jelly-roll temperature to validation data.")
    parser.add_argument("--log", required=True)
    parser.add_argument("--validation", required=True)
    parser.add_argument("--stamp", required=True)
    args = parser.parse_args()

    log_path = Path(args.log).resolve()
    val_path = Path(args.validation).resolve()
    out_dir = Path("/workspace/artifacts/plots")
    out_dir.mkdir(parents=True, exist_ok=True)

    val_t, val_q, val_tk = load_validation(val_path)
    max_t, max_tk, q_t, q_w, mean_t, mean_tk = parse_log(log_path)
    log_end_time = 0.0
    for series in (max_t, q_t, mean_t):
        if series.size:
            log_end_time = max(log_end_time, float(series.max()))
    if log_end_time <= 0.0:
        raise RuntimeError("No time history could be parsed from the log.")

    val_mask = val_t <= (log_end_time + 1.0e-12)
    val_t_plot = val_t[val_mask]
    val_q_plot = val_q[val_mask]
    val_tk_plot = val_tk[val_mask]

    plt.style.use("seaborn-v0_8-whitegrid")

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(val_t_plot, c_to_k_delta(val_tk_plot), color="#111111", linewidth=2.0, label="Validation T_cell")
    if mean_t.size:
        ax.plot(mean_t, c_to_k_delta(mean_tk), color="#005f73", linewidth=2.0, label="Log jellyRollMeanT")
    ax.plot(max_t, c_to_k_delta(max_tk), color="#bb3e03", linewidth=1.3, alpha=0.85, label="Log jellyRoll Tmax")
    ax.set_title("Log vs Validation: Jelly-Roll Temperature")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Temperature [C]")
    ax.set_xlim(0.0, log_end_time)
    ax.legend(frameon=True)
    fig.tight_layout()
    temp_png = out_dir / f"log_vs_validation_temperature_{args.stamp}.png"
    fig.savefig(temp_png, dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(q_t, q_w, color="#0a9396", linewidth=1.5, label="Log Q_sum_check", zorder=2)
    ax.plot(
        val_t_plot,
        val_q_plot,
        color="#111111",
        linewidth=2.0,
        linestyle="--",
        label="Validation Q_cell_W",
        zorder=3,
    )
    ax.set_title("Log vs Validation: Heat")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Heat [W]")
    ax.set_xlim(0.0, log_end_time)
    ax.legend(frameon=True)
    fig.tight_layout()
    heat_png = out_dir / f"log_vs_validation_heat_{args.stamp}.png"
    fig.savefig(heat_png, dpi=180)
    plt.close(fig)

    fig, axes = plt.subplots(2, 1, figsize=(11, 8.5), sharex=True)
    axes[0].plot(val_t_plot, c_to_k_delta(val_tk_plot), color="#111111", linewidth=2.0, label="Validation T_cell")
    if mean_t.size:
        axes[0].plot(mean_t, c_to_k_delta(mean_tk), color="#005f73", linewidth=2.0, label="Log jellyRollMeanT")
    axes[0].plot(max_t, c_to_k_delta(max_tk), color="#bb3e03", linewidth=1.2, alpha=0.85, label="Log jellyRoll Tmax")
    axes[0].set_ylabel("Temperature [C]")
    axes[0].set_title("Log vs Validation")
    axes[0].legend(frameon=True)

    axes[1].plot(q_t, q_w, color="#0a9396", linewidth=1.5, label="Log Q_sum_check", zorder=2)
    axes[1].plot(
        val_t_plot,
        val_q_plot,
        color="#111111",
        linewidth=2.0,
        linestyle="--",
        label="Validation Q_cell_W",
        zorder=3,
    )
    axes[1].set_xlabel("Time [s]")
    axes[1].set_ylabel("Heat [W]")
    axes[1].legend(frameon=True)
    axes[1].set_xlim(0.0, log_end_time)
    fig.tight_layout()
    combo_png = out_dir / f"log_vs_validation_combined_{args.stamp}.png"
    fig.savefig(combo_png, dpi=180)
    plt.close(fig)

    val_q_at_qt = np.interp(q_t, val_t_plot, val_q_plot) if q_t.size else np.array([])
    q_diff = q_w - val_q_at_qt if q_t.size else np.array([])

    val_tk_at_maxt = np.interp(max_t, val_t_plot, val_tk_plot) if max_t.size else np.array([])
    max_t_diff_k = max_tk - val_tk_at_maxt if max_t.size else np.array([])

    val_tk_at_meant = np.interp(mean_t, val_t_plot, val_tk_plot) if mean_t.size else np.array([])
    mean_t_diff_k = mean_tk - val_tk_at_meant if mean_t.size else np.array([])

    fig, ax = plt.subplots(figsize=(11, 5.5))
    if mean_t.size:
        ax.plot(mean_t, mean_t_diff_k, color="#005f73", linewidth=2.0, label="jellyRollMeanT - Validation")
    ax.plot(max_t, max_t_diff_k, color="#bb3e03", linewidth=1.5, label="Tmax - Validation")
    ax.axhline(0.0, color="#111111", linewidth=1.0, linestyle="--", alpha=0.8)
    ax.set_title("Temperature Difference: Log - Validation")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Temperature Difference [K]")
    ax.set_xlim(0.0, log_end_time)
    ax.legend(frameon=True)
    fig.tight_layout()
    temp_diff_png = out_dir / f"log_vs_validation_temperature_diff_{args.stamp}.png"
    fig.savefig(temp_diff_png, dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    ax.plot(q_t, q_diff, color="#0a9396", linewidth=1.6, label="Q_sum_check - Validation")
    ax.axhline(0.0, color="#111111", linewidth=1.0, linestyle="--", alpha=0.8)
    ax.set_title("Heat Difference: Log - Validation")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Heat Difference [W]")
    ax.set_xlim(0.0, log_end_time)
    ax.legend(frameon=True)
    fig.tight_layout()
    heat_diff_png = out_dir / f"log_vs_validation_heat_diff_{args.stamp}.png"
    fig.savefig(heat_diff_png, dpi=180)
    plt.close(fig)

    print(temp_png)
    print(heat_png)
    print(combo_png)
    print(temp_diff_png)
    print(heat_diff_png)


if __name__ == "__main__":
    main()

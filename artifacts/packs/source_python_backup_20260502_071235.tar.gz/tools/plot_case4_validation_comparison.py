#!/usr/bin/env python3
"""Multi-case comparison: validation + case2 + case3 + case4 in one plot.

Data sources:
  CFD temperature : EnergyDebug jellyRoll_rotated TAvgAfter  [K -> degC]
  CFD heat        : Q_sum_check  [W]
  Experiment      : in/latest/experimental_time_temp_heat.csv  (t_s, Q_GEN_W, T_CELL_degC)
  Time alignment  : direct  (CFD time_s == experimental t_s, no offset)
"""

from __future__ import annotations

import re
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.ticker import MultipleLocator

VAL_PATH = Path("/workspace/in/latest/experimental_time_temp_heat.csv")
OUT_PATH = Path("/workspace/artifacts/reports/validation_vs_allcases_CFD_comparison.pdf")

CASES = {
    "Case 2 — fixedValue 298.15 K": {
        "log": Path("/workspace/in/latest/case2/logs/run_20260427_123648.log"),
        "color": "#1f77b4",
        "ls": "--",
        "lw": 1.8,
    },
    "Case 3 — h = 142 W/m\u00b2K": {
        "log": Path("/workspace/in/latest/case3/logs/run_20260427_140604.log"),
        "color": "#ff7f0e",
        "ls": "--",
        "lw": 1.8,
    },
    "Case 4 — h = 160 W/m\u00b2K": {
        "log": Path("/workspace/in/latest/case4/logs/run_20260427_155223.log"),
        "color": "#2ca02c",
        "ls": "--",
        "lw": 1.8,
    },
    "Case 5 — h = 380 W/m\u00b2K": {
        "log": Path("/workspace/in/latest/case5/logs/run_20260427_161207.log"),
        "color": "#9467bd",
        "ls": "--",
        "lw": 1.8,
    },
    "Case 6 — h=380, dt=0.01 s": {
        "log": Path("/workspace/in/latest/case6/logs/run_20260427_172958.log"),
        "color": "#d62728",
        "ls": ":",
        "lw": 1.8,
    },
    "Case 7 — h=380, dt=0.01 s, ECM every step": {
        "log": Path("/workspace/in/latest/case7/logs/run_20260427_194921.log"),
        "color": "#8c564b",
        "ls": "--",
        "lw": 1.8,
    },
}

ENERGY_RE = re.compile(
    r"EnergyDebug region jellyRoll_rotated time ([\d.eE+\-]+)"
    r".*?TAvgAfter ([\d.eE+\-]+)"
)
TIME_RE = re.compile(r"^Time = ([\d.eE+\-]+)")
Q_RE    = re.compile(r"Q_sum_check ([\d.eE+\-]+) W")


def parse_log(log_path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Return (t_T, T_degC, t_Q, Q_W)."""
    text = log_path.read_text(errors="ignore")

    t_rows, T_rows = [], []
    for m in ENERGY_RE.finditer(text):
        t_rows.append(float(m.group(1)))
        T_rows.append(float(m.group(2)) - 273.15)

    q_times, q_vals = [], []
    cur_t = None
    for line in text.splitlines():
        mt = TIME_RE.match(line)
        if mt:
            cur_t = float(mt.group(1))
        if cur_t is not None:
            mq = Q_RE.search(line)
            if mq:
                q_times.append(cur_t)
                q_vals.append(float(mq.group(1)))
                cur_t = None

    # deduplicate on time
    seen = {}
    for t, T in zip(t_rows, T_rows):
        seen.setdefault(t, T)
    t_arr = np.array(sorted(seen))
    T_arr = np.array([seen[t] for t in t_arr])

    seen_q = {}
    for t, q in zip(q_times, q_vals):
        seen_q.setdefault(t, q)
    tq_arr = np.array(sorted(seen_q))
    Q_arr  = np.array([seen_q[t] for t in tq_arr])

    return t_arr, T_arr, tq_arr, Q_arr


def load_validation(val_path: Path):
    import csv
    rows = list(csv.DictReader(val_path.open()))
    t   = np.array([float(r["t_s"])      for r in rows])
    Q   = np.array([float(r["Q_GEN_W"])  for r in rows])
    T   = np.array([float(r["T_CELL_degC"]) for r in rows])
    return t, T, Q


def make_plot(cases_data: dict, val_t, val_T, val_Q, out_path: Path) -> None:
    fig, axes = plt.subplots(
        2, 1, figsize=(13, 9), dpi=150,
        gridspec_kw={"hspace": 0.38},
    )

    S2MIN = 1.0 / 60.0          # seconds -> minutes
    TAMB  = 25.0

    ax_q, ax_T = axes

    # ── Heat panel ────────────────────────────────────────────────────────────
    ax_q.plot(val_t * S2MIN, val_Q,
              color="black", lw=2.4, ls="-", label="Validation (experiment)", zorder=5)

    for label, d in cases_data.items():
        tq, Q = d["tq"], d["Q"]
        # subsample for cleaner lines
        idx = np.arange(0, len(tq), max(1, len(tq)//2000))
        ax_q.plot(tq[idx] * S2MIN, Q[idx],
                  color=d["color"], lw=d["lw"], ls=d["ls"], label=label, zorder=4)

    ax_q.set_ylabel("Heat generation Q [W]", fontsize=13)
    ax_q.set_title("Cell heat generation", fontsize=14, fontweight="bold", pad=8)
    ax_q.legend(fontsize=10, frameon=True, loc="upper left")
    ax_q.grid(True, alpha=0.3)
    ax_q.set_xlim(left=0)
    ax_q.yaxis.set_minor_locator(MultipleLocator(0.5))
    ax_q.tick_params(labelsize=11)

    # ── Temperature panel ─────────────────────────────────────────────────────
    ax_T.axhline(TAMB, color="gray", lw=1.2, ls=":", label=f"Ambient {TAMB:.0f} \u00b0C", zorder=2)
    ax_T.plot(val_t * S2MIN, val_T,
              color="black", lw=2.4, ls="-", label="Validation (experiment)", zorder=5)

    for label, d in cases_data.items():
        tT, T = d["tT"], d["T"]
        idx = np.arange(0, len(tT), max(1, len(tT)//3000))
        ax_T.plot(tT[idx] * S2MIN, T[idx],
                  color=d["color"], lw=d["lw"], ls=d["ls"], label=label, zorder=4)

    # ΔT annotations — staggered x positions to avoid overlap
    t_common_end = min(d["tT"][-1] for d in cases_data.values())
    t_end_min = t_common_end * S2MIN
    n_cases = len(cases_data)
    x_offsets = [-(n_cases - 1 - i) * 1.5 for i in range(n_cases)]
    for (label, d), x_off in zip(cases_data.items(), x_offsets):
        tT, T = d["tT"], d["T"]
        t_ann = t_common_end + x_off / S2MIN
        T_cfd = float(np.interp(t_ann, tT, T))
        T_val = float(np.interp(t_ann, val_t, val_T))
        dT = T_cfd - T_val
        t_ann_min = t_ann * S2MIN
        mid_T = (T_cfd + T_val) / 2.0
        ax_T.annotate(
            "",
            xy=(t_ann_min, T_val),
            xytext=(t_ann_min, T_cfd),
            arrowprops=dict(arrowstyle="<->", color=d["color"], lw=1.5),
        )
        ax_T.text(
            t_ann_min + 0.25, mid_T,
            f"\u0394T={dT:+.1f}\u00b0C",
            fontsize=9, color=d["color"], va="center",
        )

    ax_T.set_xlabel("Time [min]", fontsize=13)
    ax_T.set_ylabel("Cell temperature [\u00b0C]", fontsize=13)
    ax_T.set_title("Volume-averaged jelly-roll temperature", fontsize=14, fontweight="bold", pad=8)
    ax_T.legend(fontsize=10, frameon=True, loc="upper left")
    ax_T.grid(True, alpha=0.3)
    ax_T.set_xlim(left=0)
    ax_T.tick_params(labelsize=11)

    # shared x-label on heat panel
    ax_q.set_xlabel("")
    ax_q.tick_params(labelbottom=False)

    fig.suptitle(
        "2170 Battery Cell — Validation vs CFD Cases (h sweep)\n"
        "NCA chemistry \u00b7 Dynamic discharge profile \u00b7 T\u1d00\u1d0d\u0299 = 25 \u00b0C",
        fontsize=14, y=0.98,
    )

    # ── Difference page ───────────────────────────────────────────────────────
    fig2, axes2 = plt.subplots(
        2, 1, figsize=(13, 9), dpi=150,
        gridspec_kw={"hspace": 0.38},
    )
    ax_dq, ax_dT = axes2

    ax_dq.axhline(0, color="black", lw=1.2, ls="-", zorder=3)
    ax_dT.axhline(0, color="black", lw=1.2, ls="-", zorder=3)

    for label, d in cases_data.items():
        # heat difference
        tq, Q = d["tq"], d["Q"]
        t_min = min(tq[-1], val_t[-1])
        t_common = np.linspace(0, t_min, 4000)
        dQ = np.interp(t_common, tq, Q) - np.interp(t_common, val_t, val_Q)
        ax_dq.plot(t_common * S2MIN, dQ,
                   color=d["color"], lw=d["lw"], ls=d["ls"], label=label)

        # temperature difference
        tT, T = d["tT"], d["T"]
        t_min_T = min(tT[-1], val_t[-1])
        t_common_T = np.linspace(0, t_min_T, 4000)
        dT = np.interp(t_common_T, tT, T) - np.interp(t_common_T, val_t, val_T)
        ax_dT.plot(t_common_T * S2MIN, dT,
                   color=d["color"], lw=d["lw"], ls=d["ls"], label=label)

    ax_dq.set_ylabel("ΔQ = CFD − Experiment [W]", fontsize=13)
    ax_dq.set_title("Heat generation difference (CFD − experiment)", fontsize=14, fontweight="bold", pad=8)
    ax_dq.legend(fontsize=10, frameon=True, loc="upper left")
    ax_dq.grid(True, alpha=0.3)
    ax_dq.set_xlim(left=0)
    ax_dq.tick_params(labelsize=11)
    ax_dq.tick_params(labelbottom=False)

    ax_dT.set_xlabel("Time [min]", fontsize=13)
    ax_dT.set_ylabel("ΔT = CFD − Experiment [°C]", fontsize=13)
    ax_dT.set_title("Temperature difference (CFD − experiment)", fontsize=14, fontweight="bold", pad=8)
    ax_dT.legend(fontsize=10, frameon=True, loc="upper left")
    ax_dT.grid(True, alpha=0.3)
    ax_dT.set_xlim(left=0)
    ax_dT.tick_params(labelsize=11)

    fig2.suptitle(
        "2170 Battery Cell — CFD vs Experiment: Residuals\n"
        "NCA chemistry \u00b7 Dynamic discharge profile \u00b7 T\u1d00\u1d0d\u0299 = 25 \u00b0C",
        fontsize=14, y=0.98,
    )

    out_path.parent.mkdir(parents=True, exist_ok=True)
    with PdfPages(out_path) as pdf:
        pdf.savefig(fig, bbox_inches="tight")
        pdf.savefig(fig2, bbox_inches="tight")
    plt.close(fig)
    plt.close(fig2)
    print(f"Saved: {out_path}")


def main() -> None:
    val_t, val_T, val_Q = load_validation(VAL_PATH)

    cases_data = {}
    for label, cfg in CASES.items():
        tT, T, tq, Q = parse_log(cfg["log"])
        cases_data[label] = {
            "tT": tT, "T": T, "tq": tq, "Q": Q,
            "color": cfg["color"], "ls": cfg["ls"], "lw": cfg["lw"],
        }
        print(f"{label}: T range {T.min():.1f}–{T.max():.1f} °C, "
              f"Q range {Q.min():.2f}–{Q.max():.2f} W, "
              f"t_end={tT[-1]:.0f} s")

    make_plot(cases_data, val_t, val_T, val_Q, OUT_PATH)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Run a corrected-case13 power-ramp study with probe-only output."""

from __future__ import annotations

import csv
import shutil
import subprocess
from datetime import datetime, UTC
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/workspace")
BASE_CASE = ROOT / "in/latest/case13"
RUNTIME_ROOT = ROOT / "artifacts/runtime/t6_ramp_20260429"
PLOTS_DIR = ROOT / "artifacts/plots"
REF_CSV = ROOT / "in/latest/case12/validation_probe_data.csv"
STAMP = "20260429"

CASES = [
    ("baseline_step", None),
    ("ramp10s", 10.0),
    ("ramp30s", 30.0),
    ("ramp50s", 50.0),
]

CASE_LABELS = {
    "baseline_step": "case13 step",
    "ramp10s": "10 s ramp",
    "ramp30s": "30 s ramp",
    "ramp50s": "50 s ramp",
}

CASE_COLORS = {
    "baseline_step": "#1f77b4",
    "ramp10s": "#ff7f0e",
    "ramp30s": "#2ca02c",
    "ramp50s": "#d62728",
}

PROBE_FILES = {
    "T1": ("probeT1/shell_rotated/0/T", 0),
    "T2": ("probeLocations/jellyRoll_rotated/0/T", 0),
    "T3": ("probeLocations/jellyRoll_rotated/0/T", 1),
    "T4": ("probeLocations/jellyRoll_rotated/0/T", 2),
    "T5": ("probeLocations/jellyRoll_rotated/0/T", 3),
    "T6": ("probeT6/cap_rotated/0/T", 0),
}


def run(cmd: list[str], cwd: Path) -> str:
    proc = subprocess.run(
        cmd,
        cwd=cwd,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"Command failed in {cwd}: {' '.join(cmd)}\n{proc.stdout}")
    return proc.stdout


def keep_only_zero(case_dir: Path) -> None:
    for child in case_dir.iterdir():
        if not child.is_dir() or child.name == "0":
            continue
        try:
            float(child.name)
        except ValueError:
            continue
        shutil.rmtree(child)


def write_control_dict(path: Path) -> None:
    text = path.read_text()
    text = text.replace("startFrom       latestTime;", "startFrom       startTime;")
    text = text.replace("writeInterval   10;", "writeInterval   1000000;")
    path.write_text(text)


def power_scale_block(ramp_s: float | None) -> str:
    if ramp_s is None:
        return ""
    return (
        "        powerScale      table\n"
        "        (\n"
        "            (0 0)\n"
        f"            ({ramp_s:g} 1)\n"
        "            (400 1)\n"
        "        );\n"
    )


def fvoptions_text(location: str, total_power_w: float, frac: float, ramp_s: float | None) -> str:
    return f"""/*--------------------------------*- C++ -*----------------------------------*\\
| =========                 |                                                 |
| \\\\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox           |
|  \\\\    /   O peration     | Version:  2506                                  |
|   \\\\  /    A nd           | Website:  www.openfoam.com                      |
|    \\\\/     M anipulation  |                                                 |
\\*---------------------------------------------------------------------------*/
FoamFile
{{
    version     2.0;
    format      ascii;
    class       dictionary;
    object      fvOptions;
}}
// * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * //

constantHeatSource
{{
    type            uniformPowerHeatSource;
    active          yes;
    libs            ( "libecmFvOptions.so" );

    uniformPowerHeatSourceCoeffs
    {{
        selectionMode   all;
        fields          (h);
        totalPower      {total_power_w:.8f};
        domainFraction  {frac:.8f};
{power_scale_block(ramp_s)}    }}
}}

limitTemperature
{{
    type            limitTemperature;
    active          yes;
    selectionMode   all;
    min             250.0;
    max             500.0;
}}

// ************************************************************************* //
"""


def setup_case(case_name: str, ramp_s: float | None) -> Path:
    case_dir = RUNTIME_ROOT / case_name
    if case_dir.exists():
        shutil.rmtree(case_dir)
    shutil.copytree(BASE_CASE, case_dir, ignore=shutil.ignore_patterns("*.sock"))
    shutil.rmtree(case_dir / "postProcessing", ignore_errors=True)
    shutil.rmtree(case_dir / "logs", ignore_errors=True)
    keep_only_zero(case_dir)
    write_control_dict(case_dir / "system/controlDict")
    (case_dir / "system/jellyRoll_rotated/fvOptions").write_text(
        fvoptions_text("jellyRoll_rotated", 20.0, 0.966, ramp_s)
    )
    (case_dir / "system/cap_rotated/fvOptions").write_text(
        fvoptions_text("cap_rotated", 20.0, 0.033998, ramp_s)
    )
    return case_dir


def load_probe_file(path: Path) -> tuple[np.ndarray, list[np.ndarray]]:
    times = []
    cols: list[list[float]] = []
    with path.open() as handle:
        n_cols = None
        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            vals = line.split()
            if n_cols is None:
                n_cols = len(vals) - 1
                cols = [[] for _ in range(n_cols)]
            times.append(float(vals[0]))
            for idx in range(n_cols):
                cols[idx].append(float(vals[idx + 1]))
    return np.array(times), [np.array(col) for col in cols]


def load_reference() -> dict[str, np.ndarray]:
    rows = list(csv.DictReader(REF_CSV.open()))
    out: dict[str, np.ndarray] = {"t_s": np.array([float(r["t_s"]) for r in rows])}
    for probe in PROBE_FILES:
        out[probe] = np.array([float(r[probe]) for r in rows])
    return out


def load_case_probe(case_name: str, probe: str) -> tuple[np.ndarray, np.ndarray]:
    rel_path, col = PROBE_FILES[probe]
    time_s, cols = load_probe_file(RUNTIME_ROOT / case_name / "postProcessing" / rel_path)
    return time_s, cols[col] - 273.15


def initial_slope(time_s: np.ndarray, temp_c: np.ndarray, window_s: float = 5.0) -> float:
    mask = time_s <= window_s
    if np.count_nonzero(mask) < 2:
        return float("nan")
    coeffs = np.polyfit(time_s[mask], temp_c[mask], 1)
    return float(coeffs[0])


def write_summary(reference: dict[str, np.ndarray]) -> Path:
    rows: list[dict[str, float | str]] = []
    for case_name, ramp_s in CASES:
        row: dict[str, float | str] = {
            "case": case_name,
            "label": CASE_LABELS[case_name],
            "ramp_s": "" if ramp_s is None else ramp_s,
        }
        rmses = []
        for probe in PROBE_FILES:
            time_s, temp_c = load_case_probe(case_name, probe)
            interp = np.interp(reference["t_s"], time_s, temp_c)
            err = interp - reference[probe]
            rmse = float(np.sqrt(np.mean(err**2)))
            row[f"{probe}_rmse_C"] = rmse
            row[f"{probe}_final_C"] = float(temp_c[-1])
            row[f"{probe}_final_err_C"] = float(temp_c[-1] - reference[probe][-1])
            rmses.append(rmse)
            if probe == "T6":
                row["T6_initial_slope_C_per_s"] = initial_slope(time_s, temp_c)
        row["mean_rmse_C"] = float(np.mean(rmses))
        row["mean_rmse_T1_T5_C"] = float(np.mean([row[f"T{i}_rmse_C"] for i in range(1, 6)]))
        rows.append(row)

    out_path = PLOTS_DIR / f"t6_ramp_summary_{STAMP}.csv"
    with out_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    return out_path


def plot_t6(reference: dict[str, np.ndarray]) -> tuple[Path, Path]:
    fig, ax = plt.subplots(figsize=(13, 7), dpi=160)
    ax.plot(reference["t_s"], reference["T6"], color="black", linewidth=2.5, label="T6 reference")
    for case_name, _ in CASES:
        time_s, temp_c = load_case_probe(case_name, "T6")
        ax.plot(time_s, temp_c, color=CASE_COLORS[case_name], linewidth=2.0, label=f"T6 {CASE_LABELS[case_name]}")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("T6 temperature [C]")
    ax.set_title("T6 power-ramp study vs reference")
    ax.set_xlim(0, 400)
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=9, frameon=True)
    fig.tight_layout()
    overlay_path = PLOTS_DIR / f"t6_ramp_T6_overlay_{STAMP}.png"
    fig.savefig(overlay_path, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(13, 7), dpi=160)
    ax.axhline(0.0, color="black", linewidth=1.0, alpha=0.6)
    for case_name, _ in CASES:
        time_s, temp_c = load_case_probe(case_name, "T6")
        interp = np.interp(reference["t_s"], time_s, temp_c)
        delta = interp - reference["T6"]
        ax.plot(reference["t_s"], delta, color=CASE_COLORS[case_name], linewidth=2.0, label=f"T6 {CASE_LABELS[case_name]}")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("T6 delta = CFD - reference [C]")
    ax.set_title("T6 power-ramp delta vs reference")
    ax.set_xlim(0, 400)
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=9, frameon=True)
    fig.tight_layout()
    delta_path = PLOTS_DIR / f"t6_ramp_T6_delta_{STAMP}.png"
    fig.savefig(delta_path, bbox_inches="tight")
    plt.close(fig)
    return overlay_path, delta_path


def main() -> None:
    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    RUNTIME_ROOT.mkdir(parents=True, exist_ok=True)

    for case_name, ramp_s in CASES:
        case_dir = setup_case(case_name, ramp_s)
        run(["./Allrun"], cwd=case_dir)
        keep_only_zero(case_dir)

    reference = load_reference()
    summary_path = write_summary(reference)
    overlay_path, delta_path = plot_t6(reference)

    print(summary_path)
    print(overlay_path)
    print(delta_path)


if __name__ == "__main__":
    main()

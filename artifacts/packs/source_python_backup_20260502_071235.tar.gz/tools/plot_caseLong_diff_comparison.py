#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


TIME_RE = re.compile(r"^Time = ([0-9eE+\-.]+)")
MINMAX_RE = re.compile(r"^Min/max T:([0-9eE+\-.]+) ([0-9eE+\-.]+)")
QSUM_RE = re.compile(r"^Q_sum_check ([0-9eE+\-.]+) W")


def load_validation(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    t_s: list[float] = []
    q_w: list[float] = []
    t_k: list[float] = []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            t_s.append(float(row["t_ss"]))
            q_w.append(float(row["Q_cell_W"]))
            t_k.append(float(row["T_cell_K"]))
    return np.array(t_s), np.array(q_w), np.array(t_k)


def parse_log(path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    max_times: list[float] = []
    max_t_k: list[float] = []
    q_times: list[float] = []
    q_w: list[float] = []

    current_time: float | None = None
    expect_jelly_minmax = False

    with path.open(encoding="utf-8", errors="replace") as f:
        for raw in f:
            line = raw.strip()

            m = TIME_RE.match(line)
            if m:
                current_time = float(m.group(1))
                expect_jelly_minmax = True
                continue

            if expect_jelly_minmax:
                m = MINMAX_RE.match(line)
                if m and current_time is not None:
                    max_times.append(current_time)
                    max_t_k.append(float(m.group(2)))
                    expect_jelly_minmax = False
                    continue

            m = QSUM_RE.match(line)
            if m and current_time is not None:
                q_times.append(current_time)
                q_w.append(float(m.group(1)))
                continue

    return np.array(max_times), np.array(max_t_k), np.array(q_times), np.array(q_w)


def main() -> None:
    parser = argparse.ArgumentParser(description="Compare delta traces for two caseLong runs.")
    parser.add_argument("--previous-log", required=True)
    parser.add_argument("--current-log", required=True)
    parser.add_argument("--validation", required=True)
    parser.add_argument("--tmax", type=float, default=250.0)
    parser.add_argument("--stamp", required=True)
    args = parser.parse_args()

    prev_log = Path(args.previous_log).resolve()
    curr_log = Path(args.current_log).resolve()
    val_path = Path(args.validation).resolve()
    out_dir = Path("/workspace/artifacts/plots")
    out_dir.mkdir(parents=True, exist_ok=True)

    val_t, val_q, val_tk = load_validation(val_path)
    val_mask = val_t <= args.tmax + 1.0e-12
    val_t = val_t[val_mask]
    val_q = val_q[val_mask]
    val_tk = val_tk[val_mask]

    p_t, p_tk, p_qt, p_q = parse_log(prev_log)
    c_t, c_tk, c_qt, c_q = parse_log(curr_log)

    p_mask_t = p_t <= args.tmax + 1.0e-12
    p_mask_q = p_qt <= args.tmax + 1.0e-12
    c_mask_t = c_t <= args.tmax + 1.0e-12
    c_mask_q = c_qt <= args.tmax + 1.0e-12

    p_t = p_t[p_mask_t]
    p_tk = p_tk[p_mask_t]
    p_qt = p_qt[p_mask_q]
    p_q = p_q[p_mask_q]
    c_t = c_t[c_mask_t]
    c_tk = c_tk[c_mask_t]
    c_qt = c_qt[c_mask_q]
    c_q = c_q[c_mask_q]

    p_tdiff = p_tk - np.interp(p_t, val_t, val_tk) if p_t.size else np.array([])
    c_tdiff = c_tk - np.interp(c_t, val_t, val_tk) if c_t.size else np.array([])
    p_qdiff = p_q - np.interp(p_qt, val_t, val_q) if p_qt.size else np.array([])
    c_qdiff = c_q - np.interp(c_qt, val_t, val_q) if c_qt.size else np.array([])

    plt.style.use("seaborn-v0_8-whitegrid")

    fig, ax = plt.subplots(figsize=(11, 5.5))
    if p_t.size:
        ax.plot(p_t, p_tdiff, color="#bb3e03", linewidth=1.6, label="Previous run Tmax - Validation")
    if c_t.size:
        ax.plot(c_t, c_tdiff, color="#005f73", linewidth=1.8, label="Current run Tmax - Validation")
    ax.axhline(0.0, color="#111111", linewidth=1.0, linestyle="--", alpha=0.8)
    ax.set_title("Temperature Difference Comparison")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Temperature Difference [K]")
    ax.set_xlim(0.0, args.tmax)
    ax.legend(frameon=True)
    fig.tight_layout()
    temp_png = out_dir / f"caseLong_temperature_diff_comparison_{args.stamp}.png"
    fig.savefig(temp_png, dpi=180)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(11, 5.5))
    if p_qt.size:
        ax.plot(p_qt, p_qdiff, color="#ee9b00", linewidth=1.6, label="Previous run Heat - Validation")
    if c_qt.size:
        ax.plot(c_qt, c_qdiff, color="#0a9396", linewidth=1.8, label="Current run Heat - Validation")
    ax.axhline(0.0, color="#111111", linewidth=1.0, linestyle="--", alpha=0.8)
    ax.set_title("Heat Difference Comparison")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Heat Difference [W]")
    ax.set_xlim(0.0, args.tmax)
    ax.legend(frameon=True)
    fig.tight_layout()
    heat_png = out_dir / f"caseLong_heat_diff_comparison_{args.stamp}.png"
    fig.savefig(heat_png, dpi=180)
    plt.close(fig)

    print(temp_png)
    print(heat_png)


if __name__ == "__main__":
    main()

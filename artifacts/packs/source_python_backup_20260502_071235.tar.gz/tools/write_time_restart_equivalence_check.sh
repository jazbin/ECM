#!/bin/bash
set -euo pipefail

root_dir="$(cd "$(dirname "$0")/.." && pwd)"
base_case="$root_dir/cases/smoke_writeTime_ecmQdot"
stamp="$(date -u +%Y%m%d_%H%M%S)"
run_root="$root_dir/artifacts/runtime/write_time_restart_equivalence_$stamp"
full_case="$run_root/full_run"
restart_case="$run_root/restarted_from_middle"
log_dir="$root_dir/artifacts/logs"
stats_file="$run_root/comparison_stats.txt"

middle_time="0.78125"
final_time="1.5625"
delta_t="0.015625"
write_interval="$middle_time"

mkdir -p "$run_root" "$log_dir"

if [ -f /opt/openfoam/etc/bashrc ]; then
  set +e
  set +u
  # shellcheck disable=SC1091
  source /opt/openfoam/etc/bashrc
  set -u
  set -e
fi

"$root_dir/tools/ensure_python_runtime_deps.sh"

if [ -z "${FOAM_USER_APPBIN:-}" ] && [ -d /workspace/.openfoam/bin ]; then
  export FOAM_USER_APPBIN=/workspace/.openfoam/bin
fi
if [ -z "${FOAM_USER_LIBBIN:-}" ] && [ -d /workspace/.openfoam/lib ]; then
  export FOAM_USER_LIBBIN=/workspace/.openfoam/lib
fi
if [ -n "${FOAM_USER_APPBIN:-}" ]; then
  export PATH="$FOAM_USER_APPBIN:$PATH"
fi
if [ -n "${FOAM_USER_LIBBIN:-}" ]; then
  export LD_LIBRARY_PATH="$FOAM_USER_LIBBIN:${LD_LIBRARY_PATH:-}"
fi

setup_case() {
  local case_dir="$1"
  mkdir -p "$case_dir"
  ln -s "$base_case/0" "$case_dir/0"
  ln -s "$base_case/constant" "$case_dir/constant"
  cp -a "$base_case/system" "$case_dir/system"
  mkdir -p "$case_dir/ecm"
}

configure_case() {
  local case_dir="$1"
  local start_from="$2"
  local start_time="$3"
  foamDictionary -entry startFrom -set "$start_from" "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry startTime -set "$start_time" "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry endTime -set "$final_time" "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry deltaT -set "$delta_t" "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry adjustTimeStep -set no "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry writeControl -set runTime "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry writeInterval -set "$write_interval" "$case_dir/system/controlDict" >/dev/null
  foamDictionary -entry purgeWrite -set 0 "$case_dir/system/controlDict" >/dev/null
  foamDictionary \
    -entry 'functions/ecmCoupling/command' \
    -set "\"python3 $root_dir/python/ecm_coupling_wrapper.py --input ecm/ecm_in.json --output ecm/ecm_out.json --state ecm/ecm_state.json --backend ecm-step --ecm-call-every-n-steps 5 --vt-min-v -100 --pipe-mode\"" \
    "$case_dir/system/controlDict" >/dev/null
}

run_solver() {
  local case_dir="$1"
  local log_file="$2"
  (
    cd "$case_dir"
    chtMultiRegionSolidFoam -case "$case_dir" >"$log_file" 2>&1
  )
}

compare_file() {
  local left="$1"
  local right="$2"
  if ! cmp -s "$left" "$right"; then
    echo "Mismatch: $left vs $right" >&2
    return 1
  fi
}

compare_ecm_runtime_outputs() {
  python3 - <<PY
import json
import math
import pathlib
import struct

full_case = pathlib.Path("$full_case")
restart_case = pathlib.Path("$restart_case")
middle_time = "$middle_time"
final_time = "$final_time"
abs_tol = 1.0e-6
rel_tol = 1.0e-8

def assert_close(a, b, label):
    if not math.isclose(float(a), float(b), rel_tol=rel_tol, abs_tol=abs_tol):
        raise AssertionError(f"{label}: {a} != {b}")

def compare_json(a, b, prefix=""):
    if isinstance(a, dict) and isinstance(b, dict):
        if set(a) != set(b):
            raise AssertionError(f"{prefix} keys differ: {set(a)} != {set(b)}")
        for key in sorted(a):
            child = f"{prefix}.{key}" if prefix else str(key)
            compare_json(a[key], b[key], child)
        return
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            raise AssertionError(f"{prefix} list length differs: {len(a)} != {len(b)}")
        for i, (av, bv) in enumerate(zip(a, b)):
            compare_json(av, bv, f"{prefix}[{i}]")
        return
    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
        assert_close(a, b, prefix)
        return
    if a != b:
        raise AssertionError(f"{prefix}: {a!r} != {b!r}")

def parse_coupler_state(path):
    data = {}
    q = {}
    in_q_section = False
    with open(path, "r", encoding="utf-8") as f:
        for raw in f:
            parts = raw.strip().split()
            if not parts:
                continue
            key = parts[0]
            if key == "qByKeyCount":
                data[key] = int(parts[1])
                in_q_section = True
                continue
            if in_q_section and len(parts) == 2:
                q[int(parts[0])] = float(parts[1])
                continue
            if len(parts) == 2 and key in {"version", "lastReturnCode", "callStepCounter", "missingOutputCount", "degradedMode"}:
                data[key] = int(parts[1])
                continue
            if len(parts) == 2:
                data[key] = float(parts[1])
    if "qByKeyCount" in data:
        data["qByKey"] = q
    return data

def compare_coupler_state(left, right):
    a = parse_coupler_state(left)
    b = parse_coupler_state(right)
    if set(a) != set(b):
        raise AssertionError(f"coupler_state keys differ: {set(a)} != {set(b)}")
    for key in sorted(a):
        if key == "qByKey":
            if set(a[key]) != set(b[key]):
                raise AssertionError("coupler_state qByKey keys differ")
            for qkey in sorted(a[key]):
                assert_close(a[key][qkey], b[key][qkey], f"coupler_state qByKey[{qkey}]")
        elif key in {"version", "qByKeyCount"}:
            if int(a[key]) != int(b[key]):
                raise AssertionError(f"coupler_state {key}: {a[key]} != {b[key]}")
        else:
            assert_close(a[key], b[key], f"coupler_state {key}")

def parse_last_good(path):
    buf = path.read_bytes()
    header = struct.unpack("<8sIQddiI", buf[:44])
    magic = header[0]
    if not magic.startswith(b"ECMLAST"):
        raise AssertionError(f"{path}: invalid magic {magic!r}")
    version, step_id, time_value, q_sum, return_code, count = header[1:]
    recs = {}
    offset = 44
    for _ in range(count):
        key, q = struct.unpack("<id", buf[offset:offset+12])
        recs[key] = q
        offset += 12
    return {
        "version": version,
        "step_id": step_id,
        "time": time_value,
        "q_sum": q_sum,
        "return_code": return_code,
        "count": count,
        "records": recs,
    }

def compare_last_good(left, right):
    a = parse_last_good(pathlib.Path(left))
    b = parse_last_good(pathlib.Path(right))
    for key in ("version", "step_id", "return_code", "count"):
        if a[key] != b[key]:
            raise AssertionError(f"last_good {key}: {a[key]} != {b[key]}")
    for key in ("time", "q_sum"):
        assert_close(a[key], b[key], f"last_good {key}")
    if set(a["records"]) != set(b["records"]):
        raise AssertionError("last_good record keys differ")
    for qkey in sorted(a["records"]):
        assert_close(a["records"][qkey], b["records"][qkey], f"last_good records[{qkey}]")

full_state = json.loads((full_case / "ecm" / "ecm_state.json").read_text())
restart_state = json.loads((restart_case / "ecm" / "ecm_state.json").read_text())
compare_json(full_state, restart_state, "ecm_state")

full_history = json.loads((full_case / "ecm" / "writeTimeHistory.json").read_text())
restart_history = json.loads((restart_case / "ecm" / "writeTimeHistory.json").read_text())
compare_json(full_history, restart_history, "writeTimeHistory")

compare_coupler_state(
    full_case / "ecm" / "restartCheckpoints" / final_time / "coupler_state.dat",
    restart_case / "ecm" / "restartCheckpoints" / final_time / "coupler_state.dat",
)

compare_last_good(
    full_case / "ecm" / "ecm_last_good.bin",
    restart_case / "ecm" / "ecm_last_good.bin",
)

assert full_history["currentWriteTime"] == final_time
assert full_history["previousWriteTime"] == middle_time

print("write_time_restart_equivalence_ok")
print(f"middle_time={full_history['previousWriteTime']}")
print(f"final_time={full_history['currentWriteTime']}")
print(f"last_step_id={full_state['last_step_id']}")
print(f"last_time_s={full_state['last_time_s']}")
print(f"steps_since_last_ecm={full_state['steps_since_last_ecm']}")
print(f"state_abs_tol={abs_tol}")
print(f"state_rel_tol={rel_tol}")
PY
}

setup_case "$full_case"
configure_case "$full_case" startTime 0

full_log="$log_dir/write_time_restart_full_$stamp.log"
restart_log="$log_dir/write_time_restart_restart_$stamp.log"

run_solver "$full_case" "$full_log"

for path in \
  "$full_case/$middle_time" \
  "$full_case/$final_time" \
  "$full_case/ecm/restartCheckpoints/$middle_time/coupler_state.dat" \
  "$full_case/ecm/restartCheckpoints/$final_time/coupler_state.dat" \
  "$full_case/ecm/writeTimeHistory.json"
do
  if [ ! -e "$path" ]; then
    echo "Missing expected artifact after full run: $path" >&2
    exit 10
  fi
done

cp -a "$full_case" "$restart_case"
rm -rf "$restart_case/$final_time"
rm -rf "$restart_case/ecm/restartCheckpoints/$final_time"
rm -f "$restart_case/ecm/writeTimeHistory.json"

configure_case "$restart_case" latestTime 0
run_solver "$restart_case" "$restart_log"

for path in \
  "$restart_case/$final_time" \
  "$restart_case/ecm/restartCheckpoints/$final_time/coupler_state.dat" \
  "$restart_case/ecm/writeTimeHistory.json"
do
  if [ ! -e "$path" ]; then
    echo "Missing expected artifact after restart run: $path" >&2
    exit 11
  fi
done

compare_file "$full_case/$final_time/jellyRoll/ecmQdot" "$restart_case/$final_time/jellyRoll/ecmQdot"
compare_ecm_runtime_outputs > "$stats_file"

echo "Full run log: $full_log"
echo "Restart run log: $restart_log"
echo "Stats: $stats_file"
echo "Run root: $run_root"

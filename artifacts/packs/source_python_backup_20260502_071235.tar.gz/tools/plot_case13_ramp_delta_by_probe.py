#!/usr/bin/env python3
"""Create one CFD-minus-reference delta plot per probe for the case13 ramp study."""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/workspace")
RUNTIME_ROOT = ROOT / "artifacts/runtime/t6_ramp_20260429"
PLOTS_DIR = ROOT / "artifacts/plots"
REF_CSV = ROOT / "in/latest/case12/validation_probe_data.csv"
STAMP = "20260429"

CASES = [
    "baseline_step",
    "ramp10s",
    "ramp30s",
    "ramp50s",
]

CASE_LABELS = {
    "baseline_step": "case13 step",
    "ramp10s": "10 s ramp",
    "ramp30s": "30 s ramp",
    "ramp50s": "50 s ramp",
}

CASE_COLORS = {
    "baseline_step": "#1f77b4",
    "ramp10s": "#ff7f0e",
    "ramp30s": "#2ca02c",
    "ramp50s": "#d62728",
}

PROBE_FILES = {
    "T1": ("probeT1/shell_rotated/0/T", 0),
    "T2": ("probeLocations/jellyRoll_rotated/0/T", 0),
    "T3": ("probeLocations/jellyRoll_rotated/0/T", 1),
    "T4": ("probeLocations/jellyRoll_rotated/0/T", 2),
    "T5": ("probeLocations/jellyRoll_rotated/0/T", 3),
    "T6": ("probeT6/cap_rotated/0/T", 0),
}


def load_probe_file(path: Path) -> tuple[np.ndarray, list[np.ndarray]]:
    times = []
    cols: list[list[float]] = []
    with path.open() as handle:
        n_cols = None
        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            vals = line.split()
            if n_cols is None:
                n_cols = len(vals) - 1
                cols = [[] for _ in range(n_cols)]
            times.append(float(vals[0]))
            for idx in range(n_cols):
                cols[idx].append(float(vals[idx + 1]))
    return np.array(times), [np.array(col) for col in cols]


def load_reference() -> dict[str, np.ndarray]:
    rows = list(csv.DictReader(REF_CSV.open()))
    out: dict[str, np.ndarray] = {"t_s": np.array([float(r["t_s"]) for r in rows])}
    for probe in PROBE_FILES:
        out[probe] = np.array([float(r[probe]) for r in rows])
    return out


def load_case_probe(case_name: str, probe: str) -> tuple[np.ndarray, np.ndarray]:
    rel_path, col = PROBE_FILES[probe]
    time_s, cols = load_probe_file(RUNTIME_ROOT / case_name / "postProcessing" / rel_path)
    return time_s, cols[col] - 273.15


def plot_probe_delta(reference: dict[str, np.ndarray], probe: str) -> Path:
    fig, ax = plt.subplots(figsize=(13, 7), dpi=160)
    ax.axhline(0.0, color="black", linewidth=1.0, alpha=0.6)
    for case_name in CASES:
        time_s, temp_c = load_case_probe(case_name, probe)
        interp = np.interp(reference["t_s"], time_s, temp_c)
        delta = interp - reference[probe]
        ax.plot(
            reference["t_s"],
            delta,
            color=CASE_COLORS[case_name],
            linewidth=2.0,
            label=f"{probe} {CASE_LABELS[case_name]}",
        )
    ax.set_xlabel("Time [s]")
    ax.set_ylabel(f"{probe} delta = CFD - reference [C]")
    ax.set_title(f"{probe} power-ramp delta vs reference")
    ax.set_xlim(0, 400)
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=9, frameon=True)
    fig.tight_layout()
    out_path = PLOTS_DIR / f"t6_ramp_{probe}_delta_{STAMP}.png"
    fig.savefig(out_path, bbox_inches="tight")
    plt.close(fig)
    return out_path


def main() -> None:
    PLOTS_DIR.mkdir(parents=True, exist_ok=True)
    reference = load_reference()
    for probe in PROBE_FILES:
        out = plot_probe_delta(reference, probe)
        print(out)


if __name__ == "__main__":
    main()

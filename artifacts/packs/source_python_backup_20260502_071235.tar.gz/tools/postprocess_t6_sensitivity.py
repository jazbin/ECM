#!/usr/bin/env python3
"""Post-process the 2026-04-29 T6 sensitivity sweep from probe histories only."""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


ROOT = Path("/workspace/artifacts/runtime/t6_sensitivity_20260429")
OUT_DIR = Path("/workspace/artifacts/plots")
REF_CSV = Path("/workspace/in/latest/case12/validation_probe_data.csv")
STAMP = "20260429"

CASE_ORDER = [
    "baseline",
    "capKz_x2",
    "capHeat_x2",
    "probeZ068",
    "capOuter_adiabatic",
]

CASE_LABELS = {
    "baseline": "case13 baseline",
    "capKz_x2": "cap kz x2",
    "capHeat_x2": "cap heat x2",
    "probeZ068": "T6 probe z=0.068 m",
    "capOuter_adiabatic": "cap outer adiabatic",
}

CASE_COLORS = {
    "baseline": "#1f77b4",
    "capKz_x2": "#2ca02c",
    "capHeat_x2": "#ff7f0e",
    "probeZ068": "#9467bd",
    "capOuter_adiabatic": "#d62728",
}

PROBE_FILES = {
    "T1": ("probeT1/shell_rotated/0/T", 0),
    "T2": ("probeLocations/jellyRoll_rotated/0/T", 0),
    "T3": ("probeLocations/jellyRoll_rotated/0/T", 1),
    "T4": ("probeLocations/jellyRoll_rotated/0/T", 2),
    "T5": ("probeLocations/jellyRoll_rotated/0/T", 3),
    "T6": ("probeT6/cap_rotated/0/T", 0),
}


def load_probe_file(path: Path) -> tuple[np.ndarray, list[np.ndarray]]:
    times = []
    cols: list[list[float]] = []
    with path.open() as handle:
        n_cols = None
        for line in handle:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            vals = line.split()
            if n_cols is None:
                n_cols = len(vals) - 1
                cols = [[] for _ in range(n_cols)]
            times.append(float(vals[0]))
            for idx in range(n_cols):
                cols[idx].append(float(vals[idx + 1]))
    return np.array(times), [np.array(col) for col in cols]


def load_reference(path: Path) -> dict[str, np.ndarray]:
    rows = list(csv.DictReader(path.open()))
    out: dict[str, np.ndarray] = {"t_s": np.array([float(r["t_s"]) for r in rows])}
    for probe in PROBE_FILES:
        out[probe] = np.array([float(r[probe]) for r in rows])
    return out


def load_case_probe(case_name: str, probe: str) -> tuple[np.ndarray, np.ndarray]:
    rel_path, col = PROBE_FILES[probe]
    time_s, cols = load_probe_file(ROOT / case_name / "postProcessing" / rel_path)
    temp_c = cols[col] - 273.15
    return time_s, temp_c


def summarize(reference: dict[str, np.ndarray]) -> list[dict[str, float | str]]:
    rows: list[dict[str, float | str]] = []
    for case_name in CASE_ORDER:
        row: dict[str, float | str] = {"case": case_name, "label": CASE_LABELS[case_name]}
        rmses = []
        for probe in PROBE_FILES:
            time_s, temp_c = load_case_probe(case_name, probe)
            interp = np.interp(reference["t_s"], time_s, temp_c)
            err = interp - reference[probe]
            rmse = float(np.sqrt(np.mean(err**2)))
            row[f"{probe}_rmse_C"] = rmse
            row[f"{probe}_final_C"] = float(temp_c[-1])
            row[f"{probe}_final_err_C"] = float(temp_c[-1] - reference[probe][-1])
            rmses.append(rmse)
        row["mean_rmse_C"] = float(np.mean(rmses))
        row["mean_rmse_T1_T5_C"] = float(np.mean([row[f"T{i}_rmse_C"] for i in range(1, 6)]))
        rows.append(row)
    return rows


def write_summary(rows: list[dict[str, float | str]]) -> Path:
    out_path = OUT_DIR / f"t6_sensitivity_summary_{STAMP}.csv"
    fieldnames = list(rows[0].keys())
    with out_path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    return out_path


def plot_t6(reference: dict[str, np.ndarray]) -> tuple[Path, Path]:
    fig, ax = plt.subplots(figsize=(13, 7), dpi=160)
    ax.plot(reference["t_s"], reference["T6"], color="black", linewidth=2.5, label="T6 reference")
    for case_name in CASE_ORDER:
        time_s, temp_c = load_case_probe(case_name, "T6")
        ax.plot(time_s, temp_c, color=CASE_COLORS[case_name], linewidth=2.0, label=f"T6 {CASE_LABELS[case_name]}")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("T6 temperature [C]")
    ax.set_title("T6 sensitivity sweep vs reference")
    ax.set_xlim(0, 400)
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=9, frameon=True)
    fig.tight_layout()
    t6_path = OUT_DIR / f"t6_sensitivity_T6_overlay_{STAMP}.png"
    fig.savefig(t6_path, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(13, 7), dpi=160)
    ax.axhline(0.0, color="black", linewidth=1.0, alpha=0.6)
    for case_name in CASE_ORDER:
        time_s, temp_c = load_case_probe(case_name, "T6")
        interp = np.interp(reference["t_s"], time_s, temp_c)
        delta = interp - reference["T6"]
        ax.plot(reference["t_s"], delta, color=CASE_COLORS[case_name], linewidth=2.0, label=f"T6 {CASE_LABELS[case_name]}")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("T6 delta = CFD - reference [C]")
    ax.set_title("T6 sensitivity sweep delta vs reference")
    ax.set_xlim(0, 400)
    ax.grid(True, alpha=0.25)
    ax.legend(fontsize=9, frameon=True)
    fig.tight_layout()
    dt_path = OUT_DIR / f"t6_sensitivity_T6_delta_{STAMP}.png"
    fig.savefig(dt_path, bbox_inches="tight")
    plt.close(fig)
    return t6_path, dt_path


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    reference = load_reference(REF_CSV)
    rows = summarize(reference)
    summary_path = write_summary(rows)
    t6_path, dt_path = plot_t6(reference)
    print(summary_path)
    print(t6_path)
    print(dt_path)


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Generate a lightweight SVG plot for restart-equivalence checks."""

from __future__ import annotations

import argparse
import csv
import math
import re
from pathlib import Path


TIME_RE = re.compile(r"^Time = ([0-9eE+\-.]+)")
QSUM_RE = re.compile(r"Q_sum_check ([0-9eE+\-.]+) W")


def parse_solver_series(log_paths: list[Path]) -> list[tuple[float, float]]:
    series: list[tuple[float, float]] = []
    seen_times: set[float] = set()
    current_time: float | None = None
    current_index: int | None = None

    for path in log_paths:
        for raw_line in path.read_text().splitlines():
            time_match = TIME_RE.match(raw_line.strip())
            if time_match:
                current_time = float(time_match.group(1))
                if current_time not in seen_times:
                    series.append((current_time, 0.0))
                    seen_times.add(current_time)
                    current_index = len(series) - 1
                else:
                    current_index = next(
                        (idx for idx, (time_value, _) in enumerate(series) if time_value == current_time),
                        None,
                    )
                continue

            qsum_match = QSUM_RE.search(raw_line)
            if qsum_match and current_time is not None and current_index is not None:
                series[current_index] = (current_time, float(qsum_match.group(1)))

    return sorted(series, key=lambda item: item[0])


def build_difference_series(
    reference: list[tuple[float, float]], candidate: list[tuple[float, float]]
) -> list[tuple[float, float]]:
    candidate_by_time = {time_value: q_value for time_value, q_value in candidate}
    diff_series: list[tuple[float, float]] = []
    for time_value, q_value in reference:
        if time_value in candidate_by_time:
            diff_series.append((time_value, q_value - candidate_by_time[time_value]))
    return diff_series


def polyline_points(
    series: list[tuple[float, float]],
    x_min: float,
    x_max: float,
    y_min: float,
    y_max: float,
    left: float,
    top: float,
    width: float,
    height: float,
) -> str:
    if not series:
        return ""

    def map_x(value: float) -> float:
        if math.isclose(x_max, x_min):
            return left + width / 2.0
        return left + (value - x_min) / (x_max - x_min) * width

    def map_y(value: float) -> float:
        if math.isclose(y_max, y_min):
            return top + height / 2.0
        return top + height - (value - y_min) / (y_max - y_min) * height

    return " ".join(f"{map_x(x):.3f},{map_y(y):.3f}" for x, y in series)


def format_tick(value: float) -> str:
    if abs(value) >= 1.0:
        return f"{value:.3f}".rstrip("0").rstrip(".")
    return f"{value:.3e}"


def unique_ticks(values: list[float], tol: float = 1e-15) -> list[float]:
    ticks: list[float] = []
    for value in values:
        if not any(abs(value - existing) <= tol for existing in ticks):
            ticks.append(value)
    return ticks


def write_summary_csv(
    output_path: Path,
    continuous: list[tuple[float, float]],
    restarted: list[tuple[float, float]],
    difference: list[tuple[float, float]],
) -> None:
    restarted_by_time = {time_value: q_value for time_value, q_value in restarted}
    diff_by_time = {time_value: diff_value for time_value, diff_value in difference}
    with output_path.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["time_s", "continuous_q_sum_w", "restarted_q_sum_w", "difference_w"])
        for time_value, continuous_q in continuous:
            writer.writerow(
                [
                    f"{time_value:.9f}",
                    f"{continuous_q:.9f}",
                    f"{restarted_by_time.get(time_value, float('nan')):.9f}",
                    f"{diff_by_time.get(time_value, float('nan')):.9f}",
                ]
            )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--continuous-log", required=True)
    parser.add_argument("--restart-part1-log", required=True)
    parser.add_argument("--restart-part2-log", required=True)
    parser.add_argument("--output-svg", required=True)
    parser.add_argument("--output-csv", required=True)
    parser.add_argument("--restart-time", type=float, default=0.125)
    args = parser.parse_args()

    continuous = parse_solver_series([Path(args.continuous_log)])
    restarted = parse_solver_series([Path(args.restart_part1_log), Path(args.restart_part2_log)])
    difference = build_difference_series(continuous, restarted)

    if not continuous or not restarted:
        raise SystemExit("missing parsed data from solver logs")

    write_summary_csv(Path(args.output_csv), continuous, restarted, difference)

    x_min = min(time_value for time_value, _ in continuous)
    x_max = max(time_value for time_value, _ in continuous)
    q_values = [q_value for _, q_value in continuous] + [q_value for _, q_value in restarted]
    q_min = min(q_values)
    q_max = max(q_values)
    if math.isclose(q_min, q_max):
        q_min -= 1.0
        q_max += 1.0

    diff_values = [diff_value for _, diff_value in difference]
    diff_abs_max = max((abs(value) for value in diff_values), default=0.0)
    diff_limit = max(1e-12, diff_abs_max * 1.2 if diff_abs_max > 0.0 else 1e-12)

    width = 1200
    height = 760
    margin_left = 90
    margin_right = 40
    panel_width = width - margin_left - margin_right
    top_panel_top = 110
    panel_height = 220
    panel_gap = 120
    bottom_panel_top = top_panel_top + panel_height + panel_gap

    top_poly_cont = polyline_points(
        continuous, x_min, x_max, q_min, q_max, margin_left, top_panel_top, panel_width, panel_height
    )
    top_poly_restart = polyline_points(
        restarted, x_min, x_max, q_min, q_max, margin_left, top_panel_top, panel_width, panel_height
    )
    diff_series = [(time_value, diff_value) for time_value, diff_value in difference]
    bottom_poly_diff = polyline_points(
        diff_series,
        x_min,
        x_max,
        -diff_limit,
        diff_limit,
        margin_left,
        bottom_panel_top,
        panel_width,
        panel_height,
    )

    def x_map(value: float) -> float:
        return margin_left + (value - x_min) / (x_max - x_min) * panel_width

    def y_map_top(value: float) -> float:
        return top_panel_top + panel_height - (value - q_min) / (q_max - q_min) * panel_height

    def y_map_bottom(value: float) -> float:
        return bottom_panel_top + panel_height - (value + diff_limit) / (2.0 * diff_limit) * panel_height

    restart_x = x_map(args.restart_time)
    zero_diff_y = bottom_panel_top + panel_height / 2.0
    x_ticks = [x_min + i * (x_max - x_min) / 4.0 for i in range(5)]
    top_y_ticks = unique_ticks([q_min, 0.0, q_max])
    bottom_y_ticks = unique_ticks([-diff_limit, 0.0, diff_limit])

    x_tick_svg = []
    for tick in x_ticks:
        tick_x = x_map(tick)
        x_tick_svg.append(
            f'<line x1="{tick_x:.3f}" y1="{top_panel_top + panel_height}" x2="{tick_x:.3f}" y2="{top_panel_top + panel_height + 8}" stroke="#7b8794" stroke-width="1"/>'
        )
        x_tick_svg.append(
            f'<line x1="{tick_x:.3f}" y1="{bottom_panel_top + panel_height}" x2="{tick_x:.3f}" y2="{bottom_panel_top + panel_height + 8}" stroke="#7b8794" stroke-width="1"/>'
        )
        x_tick_svg.append(
            f'<text x="{tick_x:.3f}" y="{top_panel_top + panel_height + 28}" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="13" fill="#52606d">{tick:.3f}</text>'
        )
        x_tick_svg.append(
            f'<text x="{tick_x:.3f}" y="{bottom_panel_top + panel_height + 28}" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="13" fill="#52606d">{tick:.3f}</text>'
        )

    top_y_tick_svg = []
    for tick in top_y_ticks:
        tick_y = y_map_top(tick)
        top_y_tick_svg.append(
            f'<line x1="{margin_left - 8}" y1="{tick_y:.3f}" x2="{margin_left}" y2="{tick_y:.3f}" stroke="#7b8794" stroke-width="1"/>'
        )
        top_y_tick_svg.append(
            f'<text x="{margin_left - 14}" y="{tick_y + 4:.3f}" text-anchor="end" font-family="Helvetica, Arial, sans-serif" font-size="13" fill="#52606d">{format_tick(tick)}</text>'
        )

    bottom_y_tick_svg = []
    for tick in bottom_y_ticks:
        tick_y = y_map_bottom(tick)
        bottom_y_tick_svg.append(
            f'<line x1="{margin_left - 8}" y1="{tick_y:.3f}" x2="{margin_left}" y2="{tick_y:.3f}" stroke="#7b8794" stroke-width="1"/>'
        )
        bottom_y_tick_svg.append(
            f'<text x="{margin_left - 14}" y="{tick_y + 4:.3f}" text-anchor="end" font-family="Helvetica, Arial, sans-serif" font-size="13" fill="#52606d">{format_tick(tick)}</text>'
        )

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 {width} {height}">
  <rect x="0" y="0" width="{width}" height="{height}" fill="#fbfaf5"/>
  <text x="{margin_left}" y="48" font-family="Helvetica, Arial, sans-serif" font-size="28" font-weight="700" fill="#1f2933">Restart Equivalence Check</text>
  <text x="{margin_left}" y="76" font-family="Helvetica, Arial, sans-serif" font-size="16" fill="#52606d">Continuous vs restarted quick CHT run, stitched from solver logs. Restart marker at t = {args.restart_time:.3f} s.</text>

  <text x="{margin_left}" y="{top_panel_top - 24}" font-family="Helvetica, Arial, sans-serif" font-size="18" font-weight="700" fill="#1f2933">Q_sum_check vs time</text>
  <rect x="{margin_left}" y="{top_panel_top}" width="{panel_width}" height="{panel_height}" fill="#ffffff" stroke="#cbd2d9" stroke-width="1.5"/>
  <line x1="{margin_left}" y1="{top_panel_top + panel_height}" x2="{margin_left + panel_width}" y2="{top_panel_top + panel_height}" stroke="#9aa5b1" stroke-width="1"/>
  <line x1="{margin_left}" y1="{top_panel_top}" x2="{margin_left}" y2="{top_panel_top + panel_height}" stroke="#9aa5b1" stroke-width="1"/>
  {' '.join(x_tick_svg)}
  {' '.join(top_y_tick_svg)}
  <polyline fill="none" stroke="#d64545" stroke-width="3" points="{top_poly_cont}"/>
  <polyline fill="none" stroke="#0f766e" stroke-width="2.5" stroke-dasharray="8 5" points="{top_poly_restart}"/>
  <line x1="{restart_x:.3f}" y1="{top_panel_top}" x2="{restart_x:.3f}" y2="{top_panel_top + panel_height}" stroke="#5b21b6" stroke-width="2" stroke-dasharray="6 6"/>
  <text x="{margin_left + panel_width / 2:.3f}" y="{top_panel_top + panel_height + 54}" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="14" fill="#52606d">time [s]</text>
  <text x="24" y="{top_panel_top + panel_height / 2:.3f}" transform="rotate(-90 24 {top_panel_top + panel_height / 2:.3f})" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="14" fill="#52606d">Q_sum_check [W]</text>

  <text x="{margin_left}" y="{bottom_panel_top - 24}" font-family="Helvetica, Arial, sans-serif" font-size="18" font-weight="700" fill="#1f2933">Difference: continuous - restarted</text>
  <rect x="{margin_left}" y="{bottom_panel_top}" width="{panel_width}" height="{panel_height}" fill="#ffffff" stroke="#cbd2d9" stroke-width="1.5"/>
  <line x1="{margin_left}" y1="{zero_diff_y:.3f}" x2="{margin_left + panel_width}" y2="{zero_diff_y:.3f}" stroke="#9aa5b1" stroke-width="1"/>
  <line x1="{margin_left}" y1="{bottom_panel_top}" x2="{margin_left}" y2="{bottom_panel_top + panel_height}" stroke="#9aa5b1" stroke-width="1"/>
  {' '.join(bottom_y_tick_svg)}
  <polyline fill="none" stroke="#1d4ed8" stroke-width="3" points="{bottom_poly_diff}"/>
  <line x1="{restart_x:.3f}" y1="{bottom_panel_top}" x2="{restart_x:.3f}" y2="{bottom_panel_top + panel_height}" stroke="#5b21b6" stroke-width="2" stroke-dasharray="6 6"/>
  <text x="{margin_left + panel_width / 2:.3f}" y="{bottom_panel_top + panel_height + 54}" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="14" fill="#52606d">time [s]</text>
  <text x="24" y="{bottom_panel_top + panel_height / 2:.3f}" transform="rotate(-90 24 {bottom_panel_top + panel_height / 2:.3f})" text-anchor="middle" font-family="Helvetica, Arial, sans-serif" font-size="14" fill="#52606d">difference [W]</text>

  <rect x="{margin_left}" y="{height - 84}" width="18" height="18" fill="#d64545"/>
  <text x="{margin_left + 28}" y="{height - 69}" font-family="Helvetica, Arial, sans-serif" font-size="15" fill="#1f2933">continuous</text>
  <rect x="{margin_left + 150}" y="{height - 84}" width="18" height="18" fill="#0f766e"/>
  <text x="{margin_left + 178}" y="{height - 69}" font-family="Helvetica, Arial, sans-serif" font-size="15" fill="#1f2933">restarted</text>
  <line x1="{margin_left + 312}" y1="{height - 75}" x2="{margin_left + 344}" y2="{height - 75}" stroke="#5b21b6" stroke-width="2" stroke-dasharray="6 6"/>
  <text x="{margin_left + 354}" y="{height - 69}" font-family="Helvetica, Arial, sans-serif" font-size="15" fill="#1f2933">restart time</text>

  <text x="{margin_left}" y="{height - 28}" font-family="Helvetica, Arial, sans-serif" font-size="15" fill="#52606d">max |difference| = {diff_abs_max:.3e} W; matching output files and final wrapper state already verified separately.</text>
</svg>
"""

    output_svg = Path(args.output_svg)
    output_svg.parent.mkdir(parents=True, exist_ok=True)
    output_svg.write_text(svg)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

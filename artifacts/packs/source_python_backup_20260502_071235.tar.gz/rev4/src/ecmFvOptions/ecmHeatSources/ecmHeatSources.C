/*---------------------------------------------------------------------------*\
  =========                 |
  \\      /  F ield         | OpenFOAM: The Open Source CFD Toolbox
   \\    /   O peration     |
    \\  /    A nd           | www.openfoam.com
     \\/     M anipulation  |
\*---------------------------------------------------------------------------*/

#include "ecmHeatSources.H"
#include "addToRunTimeSelectionTable.H"
#include "fvMatrices.H"
#include "volFields.H"
#include "Time.H"
#include <cctype>
#include <fstream>
#include <sstream>
#include <string>

namespace Foam
{
namespace fv
{
    defineTypeNameAndDebug(ecmHeatSource, 0);
    addToRunTimeSelectionTable(option, ecmHeatSource, dictionary);

    defineTypeNameAndDebug(uniformPowerHeatSource, 0);
    addToRunTimeSelectionTable(option, uniformPowerHeatSource, dictionary);
}
}


Foam::fv::ecmHeatSource::ecmHeatSource
(
    const word& name,
    const word& modelType,
    const dictionary& dict,
    const fvMesh& mesh
)
:
    cellSetOption(name, modelType, dict, mesh),
    qFieldName_("ecmQdot")
{
    if (isActive())
    {
        read(dict);
    }
}


bool Foam::fv::ecmHeatSource::read(const dictionary& dict)
{
    if (!cellSetOption::read(dict))
    {
        return false;
    }

    qFieldName_ = coeffs_.getOrDefault<word>("qField", "ecmQdot");
    fieldNames_ = coeffs_.getOrDefault<wordList>("fields", wordList(1, "h"));
    resetApplied();
    return true;
}


void Foam::fv::ecmHeatSource::addSupInternal
(
    fvMatrix<scalar>& eqn,
    const label fieldi
)
{
    if (!mesh_.foundObject<volScalarField>(qFieldName_))
    {
        return;
    }

    const volScalarField& qVol = mesh_.lookupObject<volScalarField>(qFieldName_);

    forAll(cells_, i)
    {
        const label celli = cells_[i];
        eqn.source()[celli] -= qVol[celli]*mesh_.V()[celli];
    }

    setApplied(fieldi);
}


void Foam::fv::ecmHeatSource::addSup
(
    fvMatrix<scalar>& eqn,
    const label fieldi
)
{
    addSupInternal(eqn, fieldi);
}


void Foam::fv::ecmHeatSource::addSup
(
    const volScalarField&,
    fvMatrix<scalar>& eqn,
    const label fieldi
)
{
    addSupInternal(eqn, fieldi);
}


Foam::fv::uniformPowerHeatSource::uniformPowerHeatSource
(
    const word& name,
    const word& modelType,
    const dictionary& dict,
    const fvMesh& mesh
)
:
    cellSetOption(name, modelType, dict, mesh),
    qdot_(0),
    totalPower_(0),
    domainFraction_(1),
    useFixedQdot_(false),
    totalPowerStateFile_(""),
    totalPowerJsonKey_(""),
    cachedDynamicTotalPower_(0),
    haveCachedDynamicTotalPower_(false),
    powerScale_(nullptr)
{
    if (isActive())
    {
        read(dict);
    }
}


bool Foam::fv::uniformPowerHeatSource::read(const dictionary& dict)
{
    if (!cellSetOption::read(dict))
    {
        return false;
    }

    fieldNames_ = coeffs_.getOrDefault<wordList>("fields", wordList(1, "h"));
    useFixedQdot_ = coeffs_.readIfPresent("qdot", qdot_);
    powerScale_.clear();

    if (!useFixedQdot_)
    {
        coeffs_.readEntry("totalPower", totalPower_);
        domainFraction_ = coeffs_.getOrDefault<scalar>("domainFraction", 1.0);
        totalPowerStateFile_ =
            coeffs_.getOrDefault<fileName>("totalPowerStateFile", fileName(""));
        totalPowerJsonKey_ =
            coeffs_.getOrDefault<word>("totalPowerJsonKey", word(""));
    }

    if (coeffs_.found("powerScale"))
    {
        powerScale_ = Function1<scalar>::New("powerScale", coeffs_);
    }

    resetApplied();
    return true;
}


Foam::scalar Foam::fv::uniformPowerHeatSource::dynamicTotalPower() const
{
    if (totalPowerStateFile_.empty() || totalPowerJsonKey_.empty())
    {
        return totalPower_;
    }

    std::ifstream is(totalPowerStateFile_.c_str());
    if (!is.good())
    {
        return haveCachedDynamicTotalPower_ ? cachedDynamicTotalPower_ : totalPower_;
    }

    std::ostringstream buffer;
    buffer << is.rdbuf();
    const std::string content = buffer.str();
    const std::string key = "\"" + std::string(totalPowerJsonKey_.c_str()) + "\"";
    const std::size_t keyPos = content.find(key);
    if (keyPos == std::string::npos)
    {
        return haveCachedDynamicTotalPower_ ? cachedDynamicTotalPower_ : totalPower_;
    }

    const std::size_t colonPos = content.find(':', keyPos + key.size());
    if (colonPos == std::string::npos)
    {
        return haveCachedDynamicTotalPower_ ? cachedDynamicTotalPower_ : totalPower_;
    }

    std::size_t start = colonPos + 1;
    while (start < content.size() && std::isspace(static_cast<unsigned char>(content[start])))
    {
        ++start;
    }

    std::size_t end = start;
    while
    (
        end < content.size()
     && (
            std::isdigit(static_cast<unsigned char>(content[end]))
         || content[end] == '+'
         || content[end] == '-'
         || content[end] == '.'
         || content[end] == 'e'
         || content[end] == 'E'
        )
    )
    {
        ++end;
    }

    if (end <= start)
    {
        return haveCachedDynamicTotalPower_ ? cachedDynamicTotalPower_ : totalPower_;
    }

    try
    {
        cachedDynamicTotalPower_ = std::stod(content.substr(start, end - start));
        haveCachedDynamicTotalPower_ = true;
    }
    catch (...)
    {
        return haveCachedDynamicTotalPower_ ? cachedDynamicTotalPower_ : totalPower_;
    }

    return cachedDynamicTotalPower_;
}


Foam::scalar Foam::fv::uniformPowerHeatSource::qdotValue() const
{
    const scalar scale =
        powerScale_.valid()
      ? powerScale_->value(mesh_.time().value())
      : scalar(1);

    if (useFixedQdot_)
    {
        return scale*qdot_;
    }

    const scalar totalPower = dynamicTotalPower();
    return V_ > SMALL ? scale*domainFraction_*totalPower/V_ : 0.0;
}


void Foam::fv::uniformPowerHeatSource::addSupInternal
(
    fvMatrix<scalar>& eqn,
    const label fieldi
)
{
    const scalar qdot = qdotValue();

    forAll(cells_, i)
    {
        const label celli = cells_[i];
        eqn.source()[celli] -= qdot*mesh_.V()[celli];
    }

    setApplied(fieldi);
}


void Foam::fv::uniformPowerHeatSource::addSup
(
    fvMatrix<scalar>& eqn,
    const label fieldi
)
{
    addSupInternal(eqn, fieldi);
}


void Foam::fv::uniformPowerHeatSource::addSup
(
    const volScalarField&,
    fvMatrix<scalar>& eqn,
    const label fieldi
)
{
    addSupInternal(eqn, fieldi);
}

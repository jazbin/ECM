# lumpedValidation ECM package

Self-contained OpenFOAM v2506 package for the wedge 2170 lumped ECM-coupled CHT case.

## Contents

- `Allwmake`: builds package-local libraries and solver into `lib/` and `bin/`
- `python/`: ECM wrapper, backend, daemon, binary-IO helpers, and lookup CSVs
- `src/`: C++ source for `ecmCoupler`, `ecmHeatSource`, patch field, and `chtMultiRegionSolidFoam`
- `case/`: ECM-enabled CHT case with validation CSV input and retained T1..T6 probes

## Build

```bash
source /opt/openfoam/etc/bashrc
./Allwmake
```

## Python dependencies

```bash
python3 -m pip install -r python/requirements.txt
```

## Run

```bash
./Allrun.sh
```

Or directly:

```bash
cd case
./Allrun
```

## Notes

- The packaged case starts from `t=0`, uses `deltaT = 0.01 s`, and reads electrical inputs from `case/constant/electrical_inputs_from_validation.csv`.
- `case/system/controlDict` calls the packaged wrapper through `python3 ../python/ecm_coupling_wrapper.py`.
- The case uses `ecmHeatSource` in the jelly-roll region and keeps the T1..T6 probe setup.
